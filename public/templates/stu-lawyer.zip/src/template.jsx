import React, { useMemo } from 'react';
import Navbar from './components/Navbar';
import Footer from './components/Footer';

import Hero from './sections/Hero';
import Achievements from './sections/Achievements';
import About from './sections/About';
import Skills from './sections/Skills';
import Projects from './sections/Projects';
import Services from './sections/Services';
import Experience from './sections/Experience';
import Education from './sections/Education';
import Testimonials from './sections/Testimonials';
import Contact from './sections/Contact';

import { normalizeData } from './utils/normalizeData';
import './styles/index.css';

export default function Template(props = {}) {
  // Support incoming props directly & synchronously from CampusCV editor
  const rawPropsData = props?.data || props?.portfolio || props?.profile || props || {};
  const data = useMemo(() => normalizeData(rawPropsData), [rawPropsData]);

  const rawAccent = data?.theme?.primaryColor || 
    data?.theme?.accentColor || 
    data?.themeColor || 
    data?.accentColor || 
    data?.primaryColor || 
    data?.color || 
    '';

  const fontFamily = data?.typography?.fontFamily || data?.fontPack || '';
  const fontSize = data?.typography?.fontSize || data?.baseFontSize || '';

  const dynamicStyles = {
    ...(rawAccent ? {
      '--campuscv-accent': rawAccent,
      '--cv-accent': rawAccent,
      '--primary': rawAccent,
      '--accent': rawAccent,
      '--brand': rawAccent,
      '--brand-gold': rawAccent
    } : {}),
    ...(fontFamily ? {
      '--campuscv-font-family': `${fontFamily}, sans-serif`,
      '--font-sans': `${fontFamily}, sans-serif`
    } : {}),
    ...(fontSize ? {
      '--campuscv-base-font-size': `${fontSize}px`
    } : {}),
    ...(data?.styleOverrides?.['template:root'] || {})
  };

  const isSectionVisible = (sectionName) => {
    const key = String(sectionName).toLowerCase();
    
    if (data?.deletedNodes?.[`section:${key}:root:section:0`] === true || data?.deletedNodes?.[key] === true) {
      return false;
    }
    if (data?.hiddenNodes?.[`section:${key}:root:section:0`] === true || data?.hiddenNodes?.[key] === true) {
      return false;
    }
    if (Array.isArray(data?.hiddenFields) && (data.hiddenFields.includes(`sections.${key}`) || data.hiddenFields.includes(key))) {
      return false;
    }

    if (data[`${key}.visible`] !== undefined) return Boolean(data[`${key}.visible`]);
    if (data[`${sectionName}.visible`] !== undefined) return Boolean(data[`${sectionName}.visible`]);
    if (data[`${key}Visible`] !== undefined) return Boolean(data[`${key}Visible`]);
    if (data[key] && typeof data[key] === 'object' && data[key].visible !== undefined) return Boolean(data[key].visible);

    // If explicit collection array is empty, hide section
    const collection = data[key] || data?.[sectionName] || data?.data?.[key];
    if (Array.isArray(collection) && collection.length === 0) {
      if (key === 'skills' && Array.isArray(data.tools) && data.tools.length > 0) return true;
      return false;
    }

    return true;
  };

  const sectionComponentMap = {
    hero: <Hero key="hero" data={data} />,
    achievements: <Achievements key="achievements" data={data} />,
    about: <About key="about" data={data} />,
    skills: <Skills key="skills" data={data} />,
    projects: <Projects key="projects" data={data} />,
    services: <Services key="services" data={data} />,
    experience: <Experience key="experience" data={data} />,
    education: <Education key="education" data={data} />,
    testimonials: <Testimonials key="testimonials" data={data} />,
    contact: <Contact key="contact" data={data} />
  };

  const defaultMainSections = [
    'hero',
    'achievements',
    'about',
    'skills',
    'projects',
    'services',
    'experience',
    'education',
    'testimonials',
    'contact'
  ];

  const rawOrder = (Array.isArray(data?.sectionOrder) && data.sectionOrder.length > 0)
    ? data.sectionOrder
    : ((Array.isArray(data?.sections) && data.sections.length > 0)
      ? data.sections
      : defaultMainSections);

  const mainSectionIds = [];
  const added = new Set();

  rawOrder.forEach((rawItem) => {
    const rawVal = typeof rawItem === 'object' && rawItem !== null ? (rawItem.id || rawItem.name || '') : rawItem;
    let id = String(rawVal || '').toLowerCase().trim();
    if (id === 'home' || id === 'intro') id = 'hero';
    if (id === 'certificates' || id === 'awards') id = 'achievements';
    if (id === 'timeline' || id === 'work') id = 'experience';
    if (id === 'academics') id = 'education';
    if (id === 'portfolio') id = 'projects';
    if (id === 'tech') id = 'skills';
    if (id === 'reviews') id = 'testimonials';
    if (id === 'header' || id === 'footer' || id === 'navbar' || !id) return;
    if (sectionComponentMap[id] && !added.has(id)) {
      mainSectionIds.push(id);
      added.add(id);
    }
  });

  defaultMainSections.forEach((id) => {
    if (!added.has(id)) {
      mainSectionIds.push(id);
      added.add(id);
    }
  });

  return (
    <div 
      className="campuscv-executive-template campuscv-template-root min-h-screen bg-[#FAF8F4] text-[#1A1A1A] font-sans antialiased"
      style={dynamicStyles}
      data-campuscv-template="executive-lawyer-portfolio"
    >
      {/* 1. Navbar */}
      {isSectionVisible('navbar') && <Navbar data={data} />}

      {/* 2. Core Portfolio Sections */}
      <main>
        {mainSectionIds.map((secId) => {
          if (!isSectionVisible(secId)) return null;
          return sectionComponentMap[secId] || null;
        })}
      </main>

      {/* 3. Footer */}
      {isSectionVisible('footer') && <Footer data={data} />}
    </div>
  );
}

export { Template as Portfolio };
