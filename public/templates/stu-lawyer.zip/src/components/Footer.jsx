import React from 'react';
import { Scale, Linkedin, Github, Twitter, Dribbble } from 'lucide-react';

export default function Footer(props = {}) {
  const incoming = props?.data || props?.portfolio || props || {};
  const data = (incoming && typeof incoming === 'object') ? incoming : {};
  const hero = (data?.hero && typeof data.hero === 'object') ? data.hero : data;

  const name = hero?.name || data?.name || "Alexander Vance";
  const title = hero?.title || data?.title || "Senior Legal Counsel & Partner";
  const socials = hero?.socials || data?.socials || {
    linkedin: "https://linkedin.com",
    github: "https://github.com",
    twitter: "https://twitter.com",
    dribbble: "https://dribbble.com",
  };

  const scrollToTop = (e) => {
    if (e && e.preventDefault) e.preventDefault();
    try {
      if (typeof window !== 'undefined') {
        window.scrollTo({ top: 0, left: 0, behavior: 'smooth' });
        if (document.documentElement) document.documentElement.scrollTo({ top: 0, left: 0, behavior: 'smooth' });
        if (document.body) document.body.scrollTo({ top: 0, left: 0, behavior: 'smooth' });
        const topEl = document.getElementById('hero') || document.querySelector('header') || document.getElementById('template-root') || document.body;
        if (topEl && typeof topEl.scrollIntoView === 'function') {
          topEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      }
    } catch (err) {
      try { window.scrollTo(0, 0); } catch (_) {}
    }
  };

  const dynamicSections = Array.isArray(data?.sections) && data.sections.length > 0
    ? data.sections
    : ['Hero', 'About', 'Skills', 'Projects', 'Experience', 'Contact'];

  const navLinks = dynamicSections
    .filter(sec => {
      const sName = typeof sec === 'string' ? sec : (sec?.name || sec?.id || '');
      return sName.toLowerCase() !== 'header' && sName.toLowerCase() !== 'footer' && sName.toLowerCase() !== 'navbar';
    })
    .map(sec => {
      const sName = typeof sec === 'string' ? sec : (sec?.name || sec?.id || '');
      const cleanName = sName.charAt(0).toUpperCase() + sName.slice(1);
      const id = sName.toLowerCase().replace(/\s+/g, '-');
      const href = id === 'home' || id === 'hero' ? '#hero' : `#${id}`;
      return {
        name: cleanName === 'Hero' ? 'Home' : cleanName,
        href
      };
    });

  return (
    <footer className="bg-[#0B0F19] text-white border-t border-[#C89B3C]/30 pt-16 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main 3-Column Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 pb-12 border-b border-[#C89B3C]/20">
          
          {/* Column 1: Brand & Logo */}
          <div className="lg:col-span-5 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-[#A67D28] to-[#C89B3C] flex items-center justify-center text-[#0B0F19] shadow-gold-glow">
                <Scale className="w-5 h-5 text-white" />
              </div>
              <div>
                <span className="font-serif text-xl font-bold tracking-tight text-white block">
                  {name}
                </span>
                <span className="text-[10px] font-bold tracking-widest text-[#D5B350] uppercase font-sans">
                  {title}
                </span>
              </div>
            </div>
            <p className="text-xs text-gray-400 font-sans font-light leading-relaxed max-w-sm">
              Providing strategic counsel, corporate jurisprudence, and bespoke advisory designed to safeguard enterprise assets and drive tangible results.
            </p>
            <div className="flex items-center gap-3 pt-2">
              {[
                { icon: Linkedin, url: socials?.linkedin, name: 'LinkedIn' },
                { icon: Github, url: socials?.github, name: 'GitHub' },
                { icon: Twitter, url: socials?.twitter, name: 'Twitter' },
                { icon: Dribbble, url: socials?.dribbble, name: 'Dribbble' },
              ].map((soc, i) => {
                const Icon = soc.icon;
                return (
                  <a
                    key={i}
                    href={soc.url || "#"}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2.5 border border-[#C89B3C]/30 text-gray-300 hover:text-[#D5B350] hover:border-[#D5B350] transition-colors"
                    aria-label={soc.name}
                  >
                    <Icon className="w-4 h-4" />
                  </a>
                );
              })}
            </div>
          </div>

          {/* Column 2: Navigation Links */}
          <div className="lg:col-span-4 space-y-3 font-sans">
            <h4 className="text-xs font-bold uppercase tracking-widest text-[#D5B350]">
              Navigation
            </h4>
            <ul className="grid grid-cols-2 gap-2 text-xs text-gray-300">
              {navLinks.map((link) => (
                <li key={link.name}>
                  <a href={link.href} className="hover:text-[#D5B350] transition-colors">
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 3: Quick Action / Back to Top */}
          <div className="lg:col-span-3 flex flex-col justify-between space-y-4 font-sans">
            <div>
              <h4 className="text-xs font-bold uppercase tracking-widest text-[#D5B350] mb-2">
                Executive Portfolio
              </h4>
              <p className="text-xs text-gray-400">
                Direct inquiries and high-velocity retainer consultations.
              </p>
            </div>
            <div>
              <button
                type="button"
                onClick={scrollToTop}
                className="inline-flex items-center gap-2 px-4 py-2.5 border border-[#C89B3C]/50 text-[#D5B350] hover:bg-[#C89B3C]/10 text-xs font-semibold tracking-wider uppercase transition-all cursor-pointer"
                aria-label="Scroll back to top"
              >
                <span>↑ Back to Top</span>
              </button>
            </div>
          </div>

        </div>

        {/* Bottom Bar: Copyright */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-gray-400 font-sans">
          <p>© {new Date().getFullYear()} {name}. All Rights Reserved. Executive Luxury Edition.</p>
          <button
            type="button"
            onClick={scrollToTop}
            className="text-[#D5B350] hover:underline cursor-pointer flex items-center gap-1"
          >
            <span>Back to top ↑</span>
          </button>
        </div>

      </div>
    </footer>
  );
}
