"use client";

import React from "react";
import { Layers, Zap, Code2, Sparkles, ArrowUpRight, Briefcase } from "lucide-react";

const DEFAULT_EXPERIENCE = [
  {
    id: "exp-1",
    role: "Software Engineering Intern",
    company: "Stripe",
    location: "San Francisco, CA",
    period: "May 2025 – Aug 2025",
    highlights: [
      "Engineered real-time settlement telemetry pipelines reducing dispute processing lag by 34%.",
      "Designed fault-tolerant event ingestion services handling 45k+ requests/sec using Go and Kafka.",
      "Shipped developer tooling in TypeScript that automated end-to-end integration test suites across 12 microservices."
    ],
    skills: ["Go", "Kafka", "TypeScript", "Distributed Systems", "AWS"],
    projectLink: "https://stripe.com"
  },
  {
    id: "exp-2",
    role: "Undergraduate AI Researcher",
    company: "Berkeley AI Research (BAIR)",
    location: "Berkeley, CA",
    period: "Aug 2024 – May 2025",
    highlights: [
      "Benchmarked speculative decoding paradigms across 7B–70B open-weight LLMs with PyTorch.",
      "Co-authored research artifact improving multi-token inference latency by 1.8x on consumer GPUs.",
      "Maintained public reproducible evaluation harness with 1.2k+ GitHub stars."
    ],
    skills: ["Python", "PyTorch", "CUDA", "LLM Inference", "HuggingFace"],
    projectLink: "https://bair.berkeley.edu"
  }
];

interface ExperienceSectionProps {
  data?: any;
}

export default function ExperienceSection({ data = {} }: ExperienceSectionProps) {
  // If user explicitly provided an empty array, return null
  if (Array.isArray(data?.experience) && data.experience.length === 0) {
    return null;
  }

  const rawExp = (Array.isArray(data?.experience) && data.experience.length > 0)
    ? data.experience
    : (Array.isArray(data?.workExperience) && data.workExperience.length > 0
        ? data.workExperience
        : (Array.isArray(data?.work) && data.work.length > 0
            ? data.work
            : (Array.isArray(data?.timeline) && data.timeline.length > 0
                ? data.timeline
                : DEFAULT_EXPERIENCE)));

  const iconOptions = [
    <Code2 key="1" className="w-5 h-5 text-brand-600" />,
    <Layers key="2" className="w-5 h-5 text-blue-600" />,
    <Zap key="3" className="w-5 h-5 text-emerald-600" />,
    <Sparkles key="4" className="w-5 h-5 text-purple-600" />
  ];

  const experienceList = rawExp.map((exp: any, idx: number) => {
    const role = exp.role || exp.title || exp.position || exp.designation || "Software Engineer";
    const company = exp.company || exp.organization || exp.employer || exp.institution || "Company";
    const location = exp.location || exp.city || "";

    const start = String(exp.startDate || exp.startYear || exp.start || exp.from || '').trim();
    const end = String(exp.endDate || exp.endYear || exp.end || exp.to || (exp.current ? 'Present' : '')).trim();
    let period = String(exp.period || exp.duration || exp.year || '').trim();
    if (!period && start && end && start !== end) {
      period = `${start} – ${end}`;
    } else if (!period && start) {
      period = exp.current ? `${start} – Present` : start;
    } else if (!period && end) {
      period = end;
    }

    const description = exp.description || exp.desc || exp.summary || exp.details || "";
    
    // Normalize raw highlights/bullets/responsibilities
    let rawHighlights: any[] = [];
    if (Array.isArray(exp.highlights) && exp.highlights.length > 0) {
      rawHighlights = exp.highlights;
    } else if (Array.isArray(exp.bullets) && exp.bullets.length > 0) {
      rawHighlights = exp.bullets;
    } else if (Array.isArray(exp.responsibilities) && exp.responsibilities.length > 0) {
      rawHighlights = exp.responsibilities;
    } else if (Array.isArray(exp.roles) && exp.roles.length > 0) {
      rawHighlights = exp.roles;
    } else if (description) {
      rawHighlights = typeof description === 'string' ? description.split(/\n+/).map(s => s.trim()).filter(Boolean) : [description];
    }

    const formattedHighlights = rawHighlights.map((item: any) => {
      if (typeof item === 'string') {
        return { text: item, title: '' };
      }
      if (typeof item === 'object' && item !== null) {
        const title = item.title || item.role || item.position || item.label || item.heading || '';
        const text = item.description || item.desc || item.summary || item.text || item.details || item.value || '';
        return { title, text: text || (typeof item === 'string' ? item : '') };
      }
      return { text: String(item), title: '' };
    }).filter(h => h.text || h.title);

    const skills = Array.isArray(exp.skills) && exp.skills.length > 0
      ? exp.skills
      : (Array.isArray(exp.technologies) && exp.technologies.length > 0 ? exp.technologies : []);

    const projectLink = exp.projectLink || exp.link || exp.url || "";

    return {
      id: exp.id || `exp-${idx}`,
      role,
      company,
      location,
      period,
      highlights: formattedHighlights,
      skills,
      projectLink,
      icon: iconOptions[idx % iconOptions.length]
    };
  });

  if (experienceList.length === 0) return null;

  return (
    <section 
      id="experience" 
      data-cv-section="experience" 
      data-node-id="section:experience:root:section:0"
      className="py-12 sm:py-16 border-b border-gray-200 scroll-mt-8"
    >
      <div className="mb-8">
        <h2 
          className="text-xs sm:text-sm font-bold text-gray-400 uppercase tracking-widest mb-2" 
          data-cv="experience.eyebrow"
          data-node-id="text:experience:eyebrow:0"
        >
          Work Experience
        </h2>
        <p 
          className="text-base text-gray-600" 
          data-cv="experience.description"
          data-node-id="text:experience:description:0"
        >
          Software engineering roles, technical internships, and career history.
        </p>
      </div>

      {/* Experience Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8" data-cv-collection="experience">
        {experienceList.map((exp: any, idx: number) => (
          <div
            key={exp.id}
            data-cv-item={`experience[${idx}]`}
            className="p-6 sm:p-7 rounded-2xl border border-gray-200 bg-white hover:border-brand-300 hover:shadow-md transition-all flex flex-col justify-between group shadow-2xs"
          >
            <div>
              {/* Card Header with Icon */}
              <div className="flex items-start gap-3.5 mb-4">
                <div className="w-11 h-11 rounded-xl bg-gray-50 border border-gray-200/80 flex items-center justify-center flex-shrink-0 shadow-2xs group-hover:border-brand-200 transition-colors">
                  {exp.icon}
                </div>
                <div className="min-w-0 flex-1">
                  <h3 
                    className="font-bold text-gray-900 text-base leading-snug group-hover:text-brand-600 transition-colors truncate" 
                    data-cv={`experience.${idx}.role`}
                    data-node-id={`text:experience:${idx}:role:0`}
                  >
                    {exp.role}
                  </h3>
                  <p 
                    className="text-xs sm:text-sm text-gray-500 font-semibold mt-0.5 truncate" 
                    data-cv={`experience.${idx}.company`}
                    data-node-id={`text:experience:${idx}:company:0`}
                  >
                    {exp.company}
                  </p>
                </div>
              </div>

              {/* Period & Location Badge */}
              {exp.period && (
                <div className="mb-4">
                  <span 
                    className="text-xs font-semibold text-gray-400 bg-gray-50 px-2.5 py-1 rounded-md border border-gray-100 inline-block" 
                    data-cv={`experience.${idx}.duration`}
                    data-node-id={`text:experience:${idx}:duration:0`}
                  >
                    {exp.period} {exp.location ? `• ${exp.location}` : ''}
                  </span>
                </div>
              )}

              {/* Bullet highlights - Vertical Clean Hierarchy */}
              {exp.highlights && exp.highlights.length > 0 && (
                <div className="space-y-3 mb-6">
                  {exp.highlights.slice(0, 3).map((item: any, bIdx: number) => (
                    <div key={bIdx} className="flex items-start gap-2.5">
                      <span className="text-brand-600 font-bold text-sm leading-none mt-1 select-none flex-shrink-0">•</span>
                      <div className="flex-1 min-w-0 text-xs sm:text-sm text-gray-600 leading-relaxed">
                        {item.title && (
                          <span className="font-semibold text-gray-900 block mb-0.5">
                            {item.title}
                          </span>
                        )}
                        {item.text && (
                          <span className="line-clamp-3 block">
                            {item.text}
                          </span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Bottom Tech & Link */}
            <div className="pt-4 border-t border-gray-100 flex items-center justify-between gap-2 mt-auto">
              <div className="flex flex-wrap gap-1.5 min-w-0">
                {exp.skills.slice(0, 3).map((skill: string, sIdx: number) => (
                  <span
                    key={sIdx}
                    className="text-xs font-semibold px-2.5 py-1 rounded-md bg-gray-50 text-gray-700 border border-gray-100 truncate"
                  >
                    {skill}
                  </span>
                ))}
              </div>
              {exp.projectLink && (
                <a
                  href={exp.projectLink.startsWith('http') ? exp.projectLink : `https://${exp.projectLink}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs sm:text-sm font-bold text-brand-600 hover:text-brand-700 flex items-center gap-1 transition-colors flex-shrink-0"
                >
                  <span>View</span>
                  <ArrowUpRight className="w-4 h-4" />
                </a>
              )}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
