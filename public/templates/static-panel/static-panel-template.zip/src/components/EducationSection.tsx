"use client";

import React from "react";
import { GraduationCap, Award, CheckCircle2 } from "lucide-react";

const DEFAULT_EDUCATION = [
  {
    id: "edu-1",
    degree: "B.S. in Computer Science & Engineering",
    school: "University of California, Berkeley",
    fieldOfStudy: "Honors Program (EECS)",
    period: "2022 – 2026",
    gpa: "3.92 / 4.00",
    honors: [
      "Dean's Honors List (All Semesters)",
      "Recipient of Berkeley EECS Undergraduate Excellence Scholarship",
      "Undergraduate Research Assistant at Berkeley AI Research (BAIR)"
    ],
    coursework: [
      "CS 162: Operating Systems & System Programming",
      "CS 189: Introduction to Machine Learning",
      "CS 186: Introduction to Database Systems",
      "CS 170: Efficient Algorithms & Intractable Problems",
      "CS 61C: Computer Architecture & Machine Structures"
    ]
  }
];

interface EducationSectionProps {
  data?: any;
}

export default function EducationSection({ data = {} }: EducationSectionProps) {
  // If user explicitly provided an empty array, return null
  if (Array.isArray(data?.education) && data.education.length === 0) {
    return null;
  }

  const rawEdu = (Array.isArray(data?.education) && data.education.length > 0)
    ? data.education
    : ((Array.isArray(data?.academics) && data.academics.length > 0)
        ? data.academics
        : ((Array.isArray(data?.educationList) && data.educationList.length > 0)
            ? data.educationList
            : DEFAULT_EDUCATION));

  const educationList = rawEdu.map((edu: any, idx: number) => {
    const degree = edu.degree || edu.title || edu.qualification || "Degree Program";
    const school = edu.school || edu.institution || edu.university || edu.college || "University";
    const fieldOfStudy = edu.fieldOfStudy || edu.department || edu.specialization || edu.major || "";

    const start = String(edu.startYear || edu.startDate || edu.from || '').trim();
    const end = String(edu.endYear || edu.endDate || edu.to || (edu.current ? 'Present' : '')).trim();
    let period = String(edu.period || edu.duration || edu.year || '').trim();
    if (!period && start && end && start !== end) {
      period = `${start} – ${end}`;
    } else if (!period && start) {
      period = edu.current ? `${start} – Present` : start;
    } else if (!period && end) {
      period = end;
    }

    const gpa = edu.gpa || edu.cgpa || edu.grade || "";
    const description = edu.description || edu.desc || edu.details || edu.summary || "";
    const honors = Array.isArray(edu.honors) ? edu.honors : (Array.isArray(edu.bullets) ? edu.bullets : (Array.isArray(edu.highlights) ? edu.highlights : (description ? [description] : [])));
    const coursework = Array.isArray(edu.coursework) ? edu.coursework : (Array.isArray(edu.courses) ? edu.courses : (Array.isArray(edu.skills) ? edu.skills : []));

    return {
      id: edu.id || `edu-${idx}`,
      degree,
      school,
      fieldOfStudy,
      period,
      gpa,
      honors,
      coursework
    };
  });

  if (educationList.length === 0) return null;

  return (
    <section id="education" data-cv-section="education" className="py-12 sm:py-16 border-b border-gray-200 scroll-mt-8">
      <div className="mb-8">
        <h2 className="text-xs sm:text-sm font-bold text-gray-400 uppercase tracking-widest mb-2" data-cv="education.eyebrow">
          Education & Honors
        </h2>
        <p className="text-base text-gray-600" data-cv="education.description">
          Academic credentials, coursework, and campus leadership.
        </p>
      </div>

      <div className="flex flex-col gap-6" data-cv-collection="education">
        {educationList.map((edu: any, idx: number) => (
          <div
            key={edu.id}
            className="p-7 sm:p-9 rounded-2xl border border-gray-200 bg-white shadow-xs"
            data-cv-item={`education[${idx}]`}
          >
            <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-5 mb-6">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-brand-50 border border-brand-100 flex items-center justify-center text-brand-600 flex-shrink-0">
                  <GraduationCap className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-extrabold text-gray-900 text-lg sm:text-xl leading-snug" data-cv={`education[${idx}].degree`}>
                    {edu.degree}
                  </h3>
                  <p className="text-base font-bold text-brand-600 mt-1" data-cv={`education[${idx}].institution`}>
                    {edu.school} {edu.fieldOfStudy ? `— ${edu.fieldOfStudy}` : ''}
                  </p>
                </div>
              </div>
              {edu.period && (
                <div className="text-xs sm:text-sm font-bold px-4 py-1.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 self-start" data-cv={`education[${idx}].duration`}>
                  {edu.period}
                </div>
              )}
            </div>

            {edu.gpa && (
              <div className="mb-6 inline-flex items-center gap-2 px-3.5 py-1.5 rounded-lg bg-amber-50 text-amber-800 border border-amber-200 text-xs sm:text-sm font-bold">
                <Award className="w-4 h-4 text-amber-600" />
                <span data-cv={`education[${idx}].gpa`}>{edu.gpa.startsWith("GPA") ? edu.gpa : `GPA: ${edu.gpa}`}</span>
              </div>
            )}

            {edu.honors && edu.honors.length > 0 && (
              <div className="space-y-3 mb-6">
                {edu.honors.map((honor: string, hIdx: number) => (
                  <div key={hIdx} className="flex items-start gap-3 text-sm sm:text-base text-gray-700 leading-relaxed">
                    <CheckCircle2 className="w-5 h-5 text-brand-600 flex-shrink-0 mt-0.5" />
                    <span>{honor}</span>
                  </div>
                ))}
              </div>
            )}

            {edu.coursework && edu.coursework.length > 0 && (
              <div className="pt-6 border-t border-gray-100">
                <span className="text-xs font-bold text-gray-500 uppercase tracking-wider block mb-3.5">
                  Key Coursework & Focus Areas
                </span>
                <div className="flex flex-wrap gap-2.5">
                  {edu.coursework.map((course: string, cIdx: number) => (
                    <span
                      key={cIdx}
                      className="text-xs sm:text-sm font-semibold px-3.5 py-1.5 rounded-lg bg-gray-50 text-gray-700 border border-gray-200/80 hover:bg-white transition-colors"
                    >
                      {course}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </section>
  );
}
