'use client';

import React, { useState, useEffect } from 'react';
import { useTheme } from '../ThemeContext';
import {
  Sparkles,
  ArrowRight,
  Download,
  Github,
  Linkedin,
  Twitter,
  ChevronDown,
  Terminal,
  Code2,
  ExternalLink
} from 'lucide-react';

const DEFAULT_PROFILE = {
  name: "Alex Sterling",
  nickname: "alex",
  title: "Senior Full-Stack & Cloud Engineer",
  roles: [
    "Full-Stack Architect",
    "Next.js & React Specialist",
    "Cloud & Distributed Systems Engineer",
    "AI & GenAI Solutions Builder"
  ],
  availability: "Available for Q4 Opportunities & Freelance",
  statusText: "Building next-gen digital experiences",
  email: "alex.sterling.dev@example.com",
  location: "San Francisco, CA (Open to Remote)",
  yearsOfExperience: 6,
  projectsCompleted: 42,
  avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=600&q=80",
  bio: "Passionate engineer dedicated to crafting fluid, high-performance web and cloud architectures. I bridge the gap between design aesthetic precision and scalable backend infrastructure.",
  socials: {
    github: "https://github.com",
    linkedin: "https://linkedin.com",
    twitter: "https://twitter.com"
  }
};

interface HeroCardProps {
  data?: any;
  onScrollToNext?: () => void;
  onScrollToProjects?: () => void;
}

export const HeroCard: React.FC<HeroCardProps> = React.memo(({
  data,
  onScrollToNext,
  onScrollToProjects
}) => {
  const contentOverrides = data?.contentOverrides || {};
  const styleOverrides = data?.styleOverrides || {};
  const profile = data?.profile || data?.hero || data || {};
  const { accentClass } = useTheme();

  // Comprehensive CampusCV field extraction with contentOverrides support
  const name =
    contentOverrides['text:hero:root:h1:name']?.value ||
    contentOverrides['text:hero:name']?.value ||
    data?.name ||
    data?.fullName ||
    profile?.name ||
    data?.basics?.name ||
    DEFAULT_PROFILE.name;

  const nickname =
    profile?.nickname ||
    profile?.username ||
    data?.username ||
    (name ? String(name).split(' ')[0]?.toLowerCase() : DEFAULT_PROFILE.nickname);

  const bio =
    contentOverrides['text:hero:root:p:lead']?.value ||
    contentOverrides['text:hero:root:p:bio']?.value ||
    contentOverrides['text:hero:bio']?.value ||
    data?.hero?.introductionText ||
    data?.hero?.description ||
    data?.introductionText ||
    data?.bio ||
    data?.aboutMe ||
    data?.summary ||
    data?.description ||
    profile?.bio ||
    profile?.summary ||
    DEFAULT_PROFILE.bio;
  
  // Resolve Avatar Image URL across CampusCV fields & live editor overrides
  const rawOverride =
    contentOverrides['image:hero:root:img:0']?.src ||
    (typeof contentOverrides['image:hero:root:img:0'] === 'string' ? contentOverrides['image:hero:root:img:0'] : null) ||
    contentOverrides['image:about:root:img:0']?.src ||
    (typeof contentOverrides['image:about:root:img:0'] === 'string' ? contentOverrides['image:about:root:img:0'] : null) ||
    data?.imageOverrides?.['image:hero:root:img:0'] ||
    data?.imageOverrides?.['image:about:root:img:0'] ||
    data?.imageOverrides?.['hero.avatarUrl'] ||
    data?.imageOverrides?.['hero.avatar'] ||
    data?.imageOverrides?.['hero.image'];
  const explicitAvatar = typeof rawOverride === 'object' && rawOverride !== null ? (rawOverride.src || rawOverride.value) : rawOverride;

  const avatar =
    explicitAvatar ||
    data?.profileImage ||
    data?.avatarUrl ||
    data?.avatar ||
    data?.photo ||
    data?.image ||
    profile?.avatar ||
    profile?.image ||
    profile?.profileImage ||
    data?.basics?.image ||
    data?.basics?.avatar ||
    DEFAULT_PROFILE.avatar;

  const location =
    contentOverrides['text:hero:root:span:location']?.value ||
    profile?.location ||
    data?.location ||
    data?.basics?.location?.city ||
    (data?.basics?.location ? `${data.basics.location.city || ''}, ${data.basics.location.countryCode || ''}` : '') ||
    DEFAULT_PROFILE.location;

  const yearsOfExperience = profile?.yearsOfExperience || profile?.experienceYears || data?.yearsOfExperience || DEFAULT_PROFILE.yearsOfExperience;
  const projectsCompleted = profile?.projectsCompleted || profile?.projectCount || data?.projectsCompleted || (Array.isArray(data?.projects) ? data.projects.length : DEFAULT_PROFILE.projectsCompleted);

  // Directly bind title / role
  const title =
    contentOverrides['text:hero:root:p:role']?.value ||
    contentOverrides['text:hero:role']?.value ||
    data?.hero?.subtitle ||
    data?.hero?.title ||
    data?.title ||
    data?.role ||
    data?.headline ||
    profile?.title ||
    profile?.role ||
    data?.basics?.label ||
    data?.tagline ||
    DEFAULT_PROFILE.title;

  const socials = profile?.socials || data?.socialLinks || DEFAULT_PROFILE.socials;
  const github = socials?.github || data?.github || "https://github.com";
  const linkedin = socials?.linkedin || data?.linkedin || "https://linkedin.com";
  const twitter = socials?.twitter || data?.twitter || "https://twitter.com";

  return (
    <div 
      data-section="hero" 
      data-cv-section="hero" 
      className="relative w-full h-full p-6 sm:p-10 md:p-12 flex flex-col justify-between overflow-hidden"
      style={styleOverrides['section:hero:root:section:0']}
    >
      {/* Background Decorative Glows */}
      <div 
        className={`absolute -top-32 -right-32 w-96 h-96 rounded-full bg-gradient-to-br ${accentClass.glow} pointer-events-none`} 
        style={{ transform: 'translate3d(0,0,0)', contain: 'paint' }}
      />
      <div 
        className="absolute -bottom-32 -left-32 w-96 h-96 rounded-full bg-cyan-600/10 blur-[100px] pointer-events-none" 
        style={{ transform: 'translate3d(0,0,0)', contain: 'paint' }}
      />

      {/* Card Header Tag */}
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/[0.06] border border-white/10 backdrop-blur-md">
          <Terminal className="w-3.5 h-3.5 text-zinc-400" />
          <span className="text-xs font-mono text-zinc-300">portfolio.init(2025)</span>
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
        </div>

        <div className="flex items-center gap-2.5">
          {github && (
            <a
              href={github}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2.5 rounded-2xl bg-white/[0.05] hover:bg-white/[0.12] border border-white/10 text-zinc-300 hover:text-white transition-all hover:scale-105"
              aria-label="GitHub"
            >
              <Github className="w-4 h-4" />
            </a>
          )}
          {linkedin && (
            <a
              href={linkedin}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2.5 rounded-2xl bg-white/[0.05] hover:bg-white/[0.12] border border-white/10 text-zinc-300 hover:text-white transition-all hover:scale-105"
              aria-label="LinkedIn"
            >
              <Linkedin className="w-4 h-4" />
            </a>
          )}
          {twitter && (
            <a
              href={twitter}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2.5 rounded-2xl bg-white/[0.05] hover:bg-white/[0.12] border border-white/10 text-zinc-300 hover:text-white transition-all hover:scale-105"
              aria-label="Twitter"
            >
              <Twitter className="w-4 h-4" />
            </a>
          )}
        </div>
      </div>

      {/* Main Grid Content */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-center my-auto">
        {/* Left Column: Story & CTAs */}
        <div className="lg:col-span-8 space-y-5">
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-sm sm:text-base font-mono text-zinc-400">
              <span>Hello, World! I&apos;m</span>
              <span className={`font-semibold ${accentClass.text}`}>@{nickname}</span>
            </div>

            <h1 
              data-node-id="text:hero:root:h1:name"
              data-node-type="text"
              data-cv="hero.name" 
              data-edit-key="hero.name"
              className="text-3xl sm:text-5xl md:text-6xl font-extrabold text-white tracking-tight leading-tight"
            >
              {name}
            </h1>

            {/* Hero Role & Headline */}
            <p 
              data-node-id="text:hero:root:p:role"
              data-node-type="text"
              data-cv="hero.role" 
              data-edit-key="hero.role"
              className="flex items-center gap-2 text-lg sm:text-2xl md:text-3xl font-bold text-zinc-300 min-h-[38px] cursor-text"
            >
              <span className="text-zinc-500 font-mono pointer-events-none select-none">&gt;</span>
              <span className="bg-gradient-to-r from-white via-zinc-200 to-zinc-400 bg-clip-text text-transparent pointer-events-none">
                {title}
              </span>
              <span className="inline-block w-0.5 h-5 sm:h-7 bg-emerald-400 animate-pulse pointer-events-none" />
            </p>
          </div>

          <p 
            data-node-id="text:hero:root:p:bio"
            data-node-type="text"
            data-cv="hero.bio" 
            data-edit-key="hero.bio"
            className="text-sm sm:text-base text-zinc-400 leading-relaxed max-w-2xl"
          >
            {bio}
          </p>

          {/* Quick Metrics row */}
          <div className="grid grid-cols-3 gap-3 max-w-lg pt-1">
            <div className="p-3 rounded-2xl bg-white/[0.03] border border-white/10 text-center">
              <div className="text-xl sm:text-2xl font-bold text-white font-mono">
                {yearsOfExperience}+
              </div>
              <div className="text-[11px] text-zinc-400 font-medium">Years Exp</div>
            </div>
            <div className="p-3 rounded-2xl bg-white/[0.03] border border-white/10 text-center">
              <div className="text-xl sm:text-2xl font-bold text-white font-mono">
                {projectsCompleted}+
              </div>
              <div className="text-[11px] text-zinc-400 font-medium">Projects Shipped</div>
            </div>
            <div className="p-3 rounded-2xl bg-white/[0.03] border border-white/10 text-center">
              <div className="text-xl sm:text-2xl font-bold text-emerald-400 font-mono">
                99.8%
              </div>
              <div className="text-[11px] text-zinc-400 font-medium">Client CSAT</div>
            </div>
          </div>

          {/* Action CTAs */}
          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              onClick={onScrollToProjects}
              data-node-id="button:hero:root:btn:projects"
              data-node-type="button"
              data-cv="hero.ctaText"
              className={`flex items-center gap-2 px-6 py-3 rounded-2xl font-semibold text-xs sm:text-sm text-white bg-gradient-to-r ${accentClass.gradient} shadow-xl shadow-black/50 hover:scale-[1.03] active:scale-[0.98] transition-all cursor-pointer`}
            >
              <span>Explore Projects</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Right Column: Visual Tech Card Showcase */}
        <div className="lg:col-span-4 flex flex-col items-center justify-center">
          <div className="relative w-full max-w-[320px] sm:max-w-[360px] rounded-3xl p-1 bg-gradient-to-br from-white/20 via-white/5 to-white/10 shadow-2xl">
            <div className="relative w-full rounded-[22px] bg-zinc-950/90 overflow-hidden flex flex-col items-center justify-center p-4 sm:p-5 text-center border border-white/10">
              {/* Center Accent Glow */}
              <div 
                className={`absolute -top-10 -right-10 w-40 h-40 rounded-full ${accentClass.bg} opacity-25 blur-3xl pointer-events-none`} 
                style={{ transform: 'translate3d(0,0,0)' }}
              />

              {/* Much Larger Hero Avatar Image */}
              <div className="relative w-44 h-44 sm:w-52 sm:h-52 md:w-56 md:h-56 rounded-2xl sm:rounded-3xl overflow-hidden border-2 border-white/25 shadow-2xl bg-zinc-900 group">
                <img
                  src={avatar}
                  alt={name}
                  className="w-full h-full object-cover object-top transition-transform duration-500 group-hover:scale-105"
                  loading="eager"
                  data-node-id="image:hero:root:img:0"
                  data-node-type="image"
                  data-cv="hero.avatar"
                  data-cv-image="hero.avatar"
                />
                <div className="absolute inset-0 ring-1 ring-inset ring-white/10 pointer-events-none rounded-2xl sm:rounded-3xl" />
                <div 
                  className="absolute bottom-2.5 right-2.5 flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-black/75 backdrop-blur-md border border-white/20 text-[10px] font-mono text-emerald-400 pointer-events-none select-none"
                >
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span>Available</span>
                </div>
              </div>

              <div 
                data-node-id="text:hero:root:div:name_badge"
                data-node-type="text"
                className="mt-3.5 font-bold text-base sm:text-lg text-white"
              >
                {name}
              </div>
              {location && (
                <div 
                  data-node-id="text:hero:root:span:location"
                  data-node-type="text"
                  data-cv="hero.location"
                  className="text-xs text-zinc-400 font-mono mt-0.5"
                >
                  {location}
                </div>
              )}

              <div className="mt-3 flex flex-wrap justify-center gap-1.5">
                {(Array.isArray(data?.skills) && data.skills.length > 0
                  ? data.skills.map((s: any) => typeof s === 'string' ? s : (s?.name || s?.title || String(s))).slice(0, 5)
                  : (Array.isArray(data?.techStack) ? data.techStack.slice(0, 5) : ['Next.js', 'TypeScript', 'AWS', 'Go', 'AI/LLM'])
                ).map((tech: string) => (
                  <span
                    key={tech}
                    className="px-2.5 py-0.5 rounded-lg bg-white/[0.06] border border-white/10 text-[10px] font-mono text-zinc-300"
                  >
                    {tech}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Slide Trigger */}
      <div className="flex justify-center pt-4">
        <button
          onClick={onScrollToNext}
          className="group flex flex-col items-center gap-1 text-xs text-zinc-500 hover:text-zinc-300 transition-colors cursor-pointer"
          aria-label="Slide to next card"
        >
          <span className="font-mono text-[10px] uppercase tracking-wider group-hover:text-zinc-300">Slide to About Card</span>
          <ChevronDown className="w-3.5 h-3.5 animate-bounce group-hover:text-white" />
        </button>
      </div>
    </div>
  );
});

HeroCard.displayName = 'HeroCard';
