export const photographyProfile = {
  name: "Elena Vance",
  title: "BFA Photography & Visual Media Artist",
  tagline: "Visual Storyteller & Editorial Lens Artist",
  campusName: "Tisch School of the Arts / NYU",
  graduationYear: "Class of 2026",
  email: "hello@elenavancephoto.com",
  phone: "+1 (555) 438-9201",
  location: "New York, NY",
  instagram: "https://instagram.com/elenavance.photo",
  behance: "https://behance.net/elenavance",
  linkedin: "https://linkedin.com/in/elena-vance-photo",
  avatarUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=800&q=80",
  heroBadge: "Available for Editorial & Grad Portraits",
  heroHeadline: "Capturing stories that last a lifetime",
  heroSubheadline: "Exploring human emotional depth, dynamic fashion palettes, and analog textures through purposeful light and visual storytelling.",
  bioHeadline: "Photography captures emotions beyond beautiful pictures. Whether editorial, campus moments, portraits, or fashion brands, I focus on genuine narratives reflecting true personality.",
  bioParagraph1: "As a senior Fine Arts Photography student at NYU Tisch, my work bridges the raw grit of 35mm film grain with the precision of contemporary digital medium format strobes.",
  bioParagraph2: "Selected for the 2025 Annual Student Salon and recipient of the Silver Key for Visual Arts, I collaborate with indie fashion designers, university theater productions, and student publications.",
  stats: [
    { label: "Years Behind Lens", value: "4+", subtext: "Since 2022" },
    { label: "Photo Shoots Completed", value: "140+", subtext: "Editorial & Campus" },
    { label: "Honors & Exhibitions", value: "7", subtext: "Galleries & Salons" },
    { label: "Client Satisfaction", value: "99%", subtext: "50+ Client Reviews" }
  ],
  education: [
    {
      id: "edu-1",
      degree: "Bachelor of Fine Arts in Photography & Imaging",
      institution: "New York University - Tisch School of the Arts",
      location: "New York, NY",
      period: "2022 - 2026 (Expected)",
      gpa: "3.92 / 4.0",
      honors: "Dean's Honor List (All Semesters), Tisch Artistic Excellence Scholarship",
      description: "Specializing in high-fashion studio lighting, analog darkroom chemistry, and visual culture theory.",
      coursework: [
        "Advanced Studio Lighting & Modifiers",
        "Color Science & Digital Master Printing",
        "35mm & Medium Format Film Chemistry",
        "History of Editorial & Documentary Photography",
        "Fashion Art Direction & Creative Casting"
      ]
    },
    {
      id: "edu-2",
      degree: "Pre-College Intensive: Editorial Storytelling",
      institution: "Rhode Island School of Design (RISD)",
      location: "Providence, RI",
      period: "Summer 2021",
      gpa: "Top 5% Cohort",
      honors: "Juror's Recognition for Best Portrait Series",
      description: "Intensive 6-week residency mastering natural light manipulation, street portraiture, and portfolio curation.",
      coursework: ["Natural Light Optics", "Narrative Sequence Design", "Fine Art Archival Framing"]
    }
  ],
  experience: [
    {
      id: "exp-1",
      role: "Lead Campus Media Photographer",
      company: "NYU Student Media & Arts Collective",
      location: "New York, NY",
      period: "Aug 2023 - Present",
      type: "Campus Role",
      description: "Directing photo coverage for university-wide gala events, runway fashion shows, and campus editorial magazines.",
      highlights: [
        "Photographed 45+ marquee campus events with over 20,000+ photo views on NYU arts portal.",
        "Mentored 6 junior student photographers on camera gear handling and fast-paced event turnaround.",
        "Implemented standardized Capture One color tethering pipeline for live runway shows."
      ]
    },
    {
      id: "exp-2",
      role: "Studio Assistant & Digital Tech Intern",
      company: "Lumina Daylight Studios",
      location: "SoHo, New York",
      period: "May 2024 - Dec 2024",
      type: "Internship",
      description: "Assisted senior fashion and commercial photographers during high-profile Vogue and GQ test shoots.",
      highlights: [
        "Calibrated Profoto D2 and Broncolor strobe heads, beauty dishes, and scrim setups.",
        "Managed live tethering workflows using Capture One Pro 23 across dual EIZO ColorEdge monitors.",
        "Handled digital asset management (DAM) and file ingest with zero data loss over 40+ production days."
      ]
    },
    {
      id: "exp-3",
      role: "Freelance Editorial & Graduation Photographer",
      company: "Elena Vance Visuals",
      location: "New York & Tri-State",
      period: "Jan 2023 - Present",
      type: "Freelance",
      description: "Partnering with graduating seniors, emerging actors, and indie apparel brands for customized visual shoots.",
      highlights: [
        "Executed 80+ portrait sessions with 5-star ratings on CampusCV booking platform.",
        "Designed tailor-made moodboards, locations, and styling guides for each client."
      ]
    }
  ],
  projects: [
    {
      id: "proj-1",
      title: "Neon Chromatics & High-Fashion Visions",
      category: "Editorial",
      imageUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=1200&q=85",
      beforeImageUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=1200&q=85",
      aspectRatio: "portrait",
      year: "2025",
      client: "NYU Fashion Revue",
      description: "An exploration of violet gels, dual strobe backlighting, and modern avant-garde eyewear highlighting retro-futurism.",
      exif: {
        camera: "Sony A7R V",
        lens: "FE 85mm f/1.4 GM II",
        aperture: "f/1.8",
        shutterSpeed: "1/250s",
        iso: "100",
        focalLength: "85mm"
      },
      tags: ["Editorial", "Color Gels", "Strobe Lighting", "Studio"]
    },
    {
      id: "proj-2",
      title: "Sunlit Romance & Golden Hour Nuptials",
      category: "Wedding",
      imageUrl: "https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=1200&q=85",
      beforeImageUrl: "https://images.unsplash.com/photo-1465495976277-4387d4b0b4c6?auto=format&fit=crop&w=1200&q=85",
      aspectRatio: "landscape",
      year: "2024",
      client: "Private Couple",
      description: "Capturing the intimate, tender emotions of an outdoor meadow ceremony with warm backlighting and delicate bokeh.",
      exif: {
        camera: "Sony A7 IV",
        lens: "FE 35mm f/1.4 GM",
        aperture: "f/1.4",
        shutterSpeed: "1/1000s",
        iso: "80",
        focalLength: "35mm"
      },
      tags: ["Wedding", "Natural Light", "Golden Hour", "Emotive"]
    },
    {
      id: "proj-3",
      title: "Solitude in the Desert: Neo-Western Aesthetic",
      category: "Editorial",
      imageUrl: "https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=1200&q=85",
      aspectRatio: "portrait",
      year: "2024",
      client: "Desert Wanderer Lookbook",
      description: "Cinematic medium-shot study of pastel architecture, equestrian elegance, and clean sun-drenched shadows in Palm Springs.",
      exif: {
        camera: "Fujifilm GFX 100S",
        lens: "GF 110mm f/2 R LM WR",
        aperture: "f/2.8",
        shutterSpeed: "1/800s",
        iso: "100",
        focalLength: "110mm"
      },
      tags: ["Fashion", "Architecture", "Medium Format"]
    },
    {
      id: "proj-4",
      title: "Botanical Reverie & Floral Portraits",
      category: "Portrait",
      imageUrl: "https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=1200&q=85",
      aspectRatio: "portrait",
      year: "2025",
      client: "Flora Magazine",
      description: "Delicate portraiture combining fresh spring blooms, translucent sunlight diffusion, and raw facial expressions.",
      exif: {
        camera: "Leica SL2-S",
        lens: "Summilux-SL 50mm f/1.4",
        aperture: "f/1.4",
        shutterSpeed: "1/500s",
        iso: "125",
        focalLength: "50mm"
      },
      tags: ["Portrait", "Botanical", "Natural Light"]
    },
    {
      id: "proj-5",
      title: "Analog Streets: 35mm Grain of Manhattan",
      category: "Film 35mm",
      imageUrl: "https://images.unsplash.com/photo-1478760329108-5c3ed9d495a0?auto=format&fit=crop&w=1200&q=85",
      aspectRatio: "landscape",
      year: "2024",
      client: "Tisch Senior Salon",
      description: "Shot on Kodak Portra 400 and self-developed in the NYU wet darkroom. Captures quiet reflections in lower Manhattan.",
      exif: {
        camera: "Leica M6 Classic",
        lens: "Summicron 35mm f/2 ASPH",
        aperture: "f/2.0",
        shutterSpeed: "1/125s",
        iso: "400",
        focalLength: "35mm"
      },
      tags: ["Analog", "35mm", "Kodak Portra", "Darkroom"]
    },
    {
      id: "proj-6",
      title: "Minimalist Geometry & Spatial Shadows",
      category: "Commercial",
      imageUrl: "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=1200&q=85",
      aspectRatio: "square",
      year: "2024",
      client: "Studio Moden Interiors",
      description: "Precision architectural and furniture still-life emphasizing diagonal light beams and emerald teal walls.",
      exif: {
        camera: "Sony A7R V",
        lens: "FE 24-70mm f/2.8 GM II",
        aperture: "f/8.0",
        shutterSpeed: "1/60s",
        iso: "100",
        focalLength: "42mm"
      },
      tags: ["Commercial", "Interior", "Minimalist"]
    }
  ],
  skills: [
    {
      name: "Digital Editing & Post-Production",
      skills: [
        { name: "Adobe Lightroom Classic", level: 98, tag: "Expert" },
        { name: "Adobe Photoshop (Retouching)", level: 95, tag: "Master" },
        { name: "Capture One Pro (Tethering)", level: 92, tag: "Pro" },
        { name: "DaVinci Resolve (Color Grading)", level: 85, tag: "Advanced" },
        { name: "Negative Lab Pro (Film Inversion)", level: 90, tag: "Expert" }
      ]
    },
    {
      name: "Lighting & Studio Technique",
      skills: [
        { name: "Profoto & Strobe Lighting Systems", level: 94, tag: "Advanced" },
        { name: "Gelled & Color Temperature Control", level: 96, tag: "Master" },
        { name: "High-Speed Sync & Outdoor Scrims", level: 90, tag: "Pro" },
        { name: "Continuous LED & Cinema Fixtures", level: 88, tag: "Advanced" }
      ]
    },
    {
      name: "Creative & Workflow Disciplines",
      skills: [
        { name: "Fashion Art Direction & Moodboards", level: 92, tag: "Lead" },
        { name: "Model Casting & On-Set Direction", level: 94, tag: "High Empathy" },
        { name: "Archival Fine-Art Inkjet Printing", level: 89, tag: "Certified" },
        { name: "Digital Asset Management (DAM)", level: 96, tag: "Organized" }
      ]
    }
  ],
  gear: [
    { id: "g-1", category: "Camera Bodies", name: "Sony A7R V", model: "61MP Full-Frame Flagship with AI AF" },
    { id: "g-2", category: "Camera Bodies", name: "Leica M6 Classic", model: "35mm Mechanical Rangefinder (1984)" },
    { id: "g-3", category: "Camera Bodies", name: "Fujifilm X100V", model: "Compact Fixed 23mm F2 Street Camera" },
    { id: "g-4", category: "Lenses", name: "Sony FE 85mm f/1.4 GM II", model: "High-Resolution Portrait Master" },
    { id: "g-5", category: "Lenses", name: "Sony FE 35mm f/1.4 GM", model: "Wide Environmental Storyteller" },
    { id: "g-6", category: "Lenses", name: "Leica Summicron 35mm f/2 ASPH", model: "German Precision Analog Glass" },
    { id: "g-7", category: "Lighting & Modifiers", name: "Profoto B10X Plus (500Ws)", model: "Battery-Powered Strobe Kit" },
    { id: "g-8", category: "Lighting & Modifiers", name: "Profoto 3' OCF Octa Softbox", model: "Soft Wrap Studio Light" },
    { id: "g-9", category: "Analog & Darkroom", name: "Jobo CPP-3 Processor", model: "Automated C-41 / B&W Chemistry" },
    { id: "g-10", category: "Tech & Accessories", name: "Tether Tools Pro Cable + EIZO ColorEdge", model: "Live Studio Tether Rig" }
  ],
  certificates: [
    {
      id: "cert-1",
      title: "Adobe Certified Professional in Visual Design",
      issuer: "Adobe Inc.",
      issueDate: "Jan 2025",
      credentialUrl: "https://adobe.com/verify/elena-vance",
      description: "Comprehensive validation in advanced retouching, color theory, smart objects, and non-destructive image compositing."
    },
    {
      id: "cert-2",
      title: "Capture One Certified Professional (COCP)",
      issuer: "Capture One",
      issueDate: "Oct 2024",
      credentialUrl: "https://captureone.com/cert/elena-vance",
      description: "Mastery of live studio tethering, batch RAW grading, skin tone uniformity, and ICC camera profile calibration."
    },
    {
      id: "cert-3",
      title: "Sony Alpha Imaging Academy Masterclass",
      issuer: "Sony Electronics",
      issueDate: "May 2024",
      credentialUrl: "https://sonyalpha.com/alumni/elena",
      description: "Specialized training on Real-time Eye AF tracking, dynamic range preservation, and hybrid editorial workflows."
    },
    {
      id: "cert-4",
      title: "National Scholastic Silver Key for Photography",
      issuer: "Alliance for Young Artists & Writers",
      issueDate: "Mar 2023",
      credentialUrl: "https://artandwriting.org",
      description: "Awarded for the 35mm documentary series 'Echoes of Lower East Side' exploring vanishing city landmarks."
    }
  ]
};

export default photographyProfile;
