"use client";

import React, { createContext, useContext, useState, ReactNode } from "react";
import { PortfolioProfile, ProjectItem } from "@/types/portfolio";
import { initialPortfolioData } from "@/data/portfolioData";

interface PortfolioContextType {
  data: PortfolioProfile;
  selectedProjectForModal: ProjectItem | null;
  setSelectedProjectForModal: (project: ProjectItem | null) => void;
}

const PortfolioContext = createContext<PortfolioContextType | undefined>(undefined);

export const PortfolioProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [data] = useState<PortfolioProfile>(initialPortfolioData);
  const [selectedProjectForModal, setSelectedProjectForModal] = useState<ProjectItem | null>(null);

  return (
    <PortfolioContext.Provider
      value={{
        data,
        selectedProjectForModal,
        setSelectedProjectForModal,
      }}
    >
      <div className="theme-violet">
        {children}
      </div>
    </PortfolioContext.Provider>
  );
};

export const usePortfolio = () => {
  const context = useContext(PortfolioContext);
  if (!context) {
    throw new Error("usePortfolio must be used within a PortfolioProvider");
  }
  return context;
};
