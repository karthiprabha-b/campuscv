import type { Metadata } from "next";
import { Plus_Jakarta_Sans, Space_Grotesk } from "next/font/google";
import "./globals.css";

const plusJakartaSans = Plus_Jakarta_Sans({
  subsets: ["latin"],
  variable: "--font-sans",
  display: "swap",
});

const spaceGrotesk = Space_Grotesk({
  subsets: ["latin"],
  variable: "--font-mono",
  display: "swap",
});

export const metadata: Metadata = {
  title: "Elena Vance | Photography Student Portfolio",
  description:
    "Editorial & Fine Art Photography Student Portfolio featuring studio lighting, 35mm analog darkroom, digital color grading, education, experience, and gear rig.",
  keywords: [
    "Photography Portfolio",
    "Student Portfolio",
    "Editorial Photography",
    "Wedding Photography",
    "NYU Tisch",
    "Sony Alpha",
    "Fashion Photography"
  ],
  openGraph: {
    title: "Elena Vance | Photography Student Portfolio",
    description: "Capturing stories that last a lifetime. Visual Storyteller & Editorial Lens Artist.",
    images: ["https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=1200&q=85"]
  }
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className={`${plusJakartaSans.variable} ${spaceGrotesk.variable} h-full antialiased`}>
      <body className="min-h-full bg-[#0b0713] text-white flex flex-col font-sans">
        {children}
      </body>
    </html>
  );
}
