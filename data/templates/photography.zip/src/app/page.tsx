"use client";

import React from "react";
import { PortfolioProvider } from "@/context/PortfolioContext";
import { Navbar } from "@/components/Navbar";
import { Hero } from "@/components/Hero";
import { About } from "@/components/About";
import { Projects } from "@/components/Projects";
import { Education } from "@/components/Education";
import { Experience } from "@/components/Experience";
import { Skills } from "@/components/Skills";
import { Certificates } from "@/components/Certificates";
import { Contact } from "@/components/Contact";
import { Footer } from "@/components/Footer";

export default function Home() {
  return (
    <PortfolioProvider>
      <main className="min-h-screen bg-[#0b0713] text-slate-100 selection:bg-purple-500 selection:text-white relative">
        {/* Top Fixed Navbar */}
        <Navbar />

        {/* Hero Section */}
        <Hero />

        {/* About Section */}
        <About />

        {/* Projects / Portfolio with Lightbox & EXIF & RAW vs Graded slider */}
        <Projects />

        {/* Academic Foundation & Coursework */}
        <Education />

        {/* Studio Experience & Internships */}
        <Experience />

        {/* Skills & Camera Rig Equipment Deck */}
        <Skills />

        {/* Verified Certifications & Awards */}
        <Certificates />

        {/* Floating Frosted Contact & Booking Section */}
        <Contact />

        {/* Footer */}
        <Footer />
      </main>
    </PortfolioProvider>
  );
}
