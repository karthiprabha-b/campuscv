import React, { useState } from 'react';
import { Camera, SlidersHorizontal, X, Layers, ArrowRight, Aperture, Clock, Zap } from 'lucide-react';
import { photographyProfile } from '../data/photographyDefaults.js';

const _default = photographyProfile || {};

export default function Projects({ data = {} }) {
  const [activeCategory, setActiveCategory] = useState('All');
  const [selectedProject, setSelectedProject] = useState(null);
  const [sliderPosition, setSliderPosition] = useState(50);
  const [compareMode, setCompareMode] = useState(false);

  // Allow custom projects or fallback to rich defaults
  const rawProjects = Array.isArray(data?.projects) && data.projects.length > 0 ? data.projects : (_default.projects || []);

  const projects = rawProjects.map((p, idx) => {
    const rawImg = p?.imageUrl || p?.image || p?.thumbnail || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=1200&q=85';
    const overrideImg = 
      data?.contentOverrides?.[`image:projects:card:${p?.id || idx}:img:0`]?.src ||
      (typeof data?.contentOverrides?.[`image:projects:card:${p?.id || idx}:img:0`] === 'string' ? data?.contentOverrides?.[`image:projects:card:${p?.id || idx}:img:0`] : null) ||
      data?.imageOverrides?.[`projects.${idx}.image`] ||
      rawImg;

    const projTitle = data?.contentOverrides?.[`text:projects:card:${p?.id || idx}:title`]?.value || p?.title || p?.name || 'Curated Photo Series';
    const projDesc = data?.contentOverrides?.[`text:projects:card:${p?.id || idx}:desc`]?.value || p?.description || p?.desc || 'Curated visual photography series captured with natural lighting and editorial styling.';
    const projClient = data?.contentOverrides?.[`text:projects:card:${p?.id || idx}:client`]?.value || p?.client || p?.subtitle || 'Client Project';
    const projCategory = data?.contentOverrides?.[`text:projects:card:${p?.id || idx}:category`]?.value || p?.category || 'Editorial';

    return {
      id: p?.id || `proj-${idx + 1}`,
      title: projTitle,
      category: projCategory,
      imageUrl: overrideImg,
      beforeImageUrl: p?.beforeImageUrl || p?.beforeImage || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=1200&q=85',
      year: p?.year || '2025',
      client: projClient,
      description: projDesc,
      exif: p?.exif || {
        camera: 'Sony A7R V',
        lens: 'FE 85mm f/1.4 GM',
        aperture: 'f/1.8',
        shutterSpeed: '1/250s',
        iso: '100',
        focalLength: '85mm'
      },
      tags: Array.isArray(p?.tags) ? p.tags : (Array.isArray(p?.technologies) ? p.technologies : ['Photography', 'Editorial'])
    };
  });

  const categories = ['All', ...Array.from(new Set(projects.map(p => p.category)))];

  const filteredProjects = activeCategory === 'All'
    ? projects
    : projects.filter(p => p.category === activeCategory);

  return (
    <section 
      id="portfolio" 
      data-cv-section="projects"
      data-node-id="section:projects:root:section:0"
      className="py-16 sm:py-24 bg-[#0e0919] text-white relative"
    >
      {/* Background Subtle Gradient */}
      <div className="absolute top-0 right-1/4 w-72 sm:w-96 h-72 sm:h-96 bg-purple-900/15 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 sm:mb-12 gap-5 sm:gap-6">
          <div>
            <div className="inline-flex items-center gap-2 text-xs font-mono tracking-widest uppercase text-purple-400 font-semibold mb-2">
              <Camera className="w-3.5 h-3.5" />
              <span>FEATURED CURATED PORTFOLIO</span>
            </div>
            <h2 className="text-2xl sm:text-4xl md:text-5xl font-extrabold text-white tracking-tight" data-node-id="text:projects:title">
              Visual Archives & Series
            </h2>
          </div>

          {/* Category Filter Tabs */}
          <div className="flex items-center gap-1.5 sm:gap-2 bg-zinc-950/80 p-1.5 rounded-full border border-white/10 overflow-x-auto no-scrollbar max-w-full">
            {categories.map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setActiveCategory(cat)}
                className={`px-3.5 sm:px-4 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-all cursor-pointer shrink-0 ${
                  activeCategory === cat
                    ? 'bg-purple-600 text-white shadow-lg shadow-purple-500/30'
                    : 'text-zinc-400 hover:text-white hover:bg-zinc-900'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 sm:gap-6">
          {filteredProjects.map((project, idx) => (
            <div
              key={project.id}
              data-node-id={`container:projects:card:${project.id}`}
              className="group relative rounded-3xl overflow-hidden bg-zinc-900 border border-white/10 hover:border-purple-500/50 transition-all duration-500 shadow-xl flex flex-col justify-between"
            >
              {/* Image Container */}
              <div className="relative aspect-[4/5] w-full overflow-hidden">
                <img
                  src={project.imageUrl}
                  data-node-id={`image:projects:card:${project.id}:img:0`}
                  data-node-type="image"
                  data-cv={`projects.items[${idx}].image`}
                  alt={project.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 cursor-pointer"
                  onClick={(e) => {
                    // Clicking image directly allows image inspector or double-click to edit
                  }}
                />

                {/* Dark Gradient Scrim (pointer-events-none allows clicks to hit elements) */}
                <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/20 to-transparent opacity-80 group-hover:opacity-90 transition-opacity pointer-events-none" />

                {/* Top Category Badge */}
                <div className="absolute top-3.5 left-3.5 sm:top-4 sm:left-4 glass-pill px-2.5 sm:px-3 py-1 rounded-full text-[10px] sm:text-xs font-mono font-medium text-white flex items-center gap-1.5 pointer-events-auto z-20">
                  <span className="w-1.5 h-1.5 rounded-full bg-purple-400 pointer-events-none" />
                  <span 
                    data-node-id={`text:projects:card:${project.id}:category`}
                    data-node-type="text"
                    data-cv={`projects.items[${idx}].category`}
                    className="cursor-text pointer-events-auto"
                  >
                    {project.category}
                  </span>
                </div>

                {/* Top Right Year */}
                <div className="absolute top-3.5 right-3.5 sm:top-4 sm:right-4 bg-black/60 backdrop-blur-md px-2 sm:px-2.5 py-0.5 sm:py-1 rounded-full text-[9px] sm:text-[10px] font-mono text-zinc-300 pointer-events-auto z-20">
                  <span 
                    data-node-id={`text:projects:card:${project.id}:year`}
                    data-node-type="text"
                    className="cursor-text pointer-events-auto"
                  >
                    {project.year}
                  </span>
                </div>

                {/* Bottom Information on Card */}
                <div className="absolute bottom-0 left-0 right-0 p-5 sm:p-6 space-y-1.5 sm:space-y-2 pointer-events-auto z-20">
                  <h3 
                    data-node-id={`text:projects:card:${project.id}:title`}
                    data-node-type="text"
                    data-cv={`projects.items[${idx}].title`}
                    className="text-base sm:text-lg font-bold text-white group-hover:text-purple-300 transition-colors leading-snug cursor-text pointer-events-auto"
                  >
                    {project.title}
                  </h3>
                  
                  <p 
                    data-node-id={`text:projects:card:${project.id}:desc`}
                    data-node-type="text"
                    data-cv={`projects.items[${idx}].description`}
                    className="text-xs text-zinc-300 line-clamp-2 leading-relaxed cursor-text pointer-events-auto"
                  >
                    {project.description}
                  </p>
                  
                  <div className="flex items-center justify-between pt-2 border-t border-white/10 text-[11px] text-zinc-400 pointer-events-auto">
                    <span 
                      data-node-id={`text:projects:card:${project.id}:client`}
                      data-node-type="text"
                      data-cv={`projects.items[${idx}].subtitle`}
                      className="font-mono text-purple-300 cursor-text pointer-events-auto"
                    >
                      {project.client}
                    </span>

                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedProject(project);
                        setCompareMode(false);
                      }}
                      className="flex items-center gap-1 text-white font-medium hover:text-purple-300 group-hover:translate-x-1 transition-all cursor-pointer pointer-events-auto"
                    >
                      Inspect Shot <ArrowRight className="w-3.5 h-3.5 text-purple-400 pointer-events-none" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>

      {/* Interactive Lightbox & RAW vs Graded Modal */}
      {selectedProject && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/90 backdrop-blur-xl animate-fadeIn">
          <div className="relative w-full max-w-5xl bg-[#120a22] border border-purple-500/30 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh]">
            
            {/* Modal Header */}
            <div className="flex items-center justify-between p-4 sm:p-6 border-b border-white/10 bg-[#0e071c]">
              <div>
                <span className="text-xs font-mono text-purple-400 uppercase tracking-widest block">
                  {selectedProject.category} • {selectedProject.year}
                </span>
                <h3 className="text-lg sm:text-2xl font-bold text-white">
                  {selectedProject.title}
                </h3>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setCompareMode(!compareMode)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold border transition-all ${
                    compareMode 
                      ? 'bg-purple-600 text-white border-purple-400' 
                      : 'bg-white/10 text-zinc-200 border-white/10 hover:bg-white/20'
                  }`}
                >
                  <SlidersHorizontal className="w-3.5 h-3.5" />
                  <span>{compareMode ? 'Exit RAW Compare' : 'RAW vs Graded'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setSelectedProject(null)}
                  className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Modal Body */}
            <div className="overflow-y-auto p-4 sm:p-6 space-y-6">
              
              {/* Image View or Comparison Slider */}
              <div className="relative aspect-[16/10] sm:aspect-[16/9] w-full max-h-[55vh] rounded-2xl overflow-hidden bg-black flex items-center justify-center">
                {!compareMode ? (
                  <img
                    src={selectedProject.imageUrl}
                    alt={selectedProject.title}
                    className="w-full h-full object-contain"
                  />
                ) : (
                  <div 
                    className="relative w-full h-full compare-container"
                    onMouseMove={(e) => {
                      const rect = e.currentTarget.getBoundingClientRect();
                      const x = Math.max(0, Math.min(e.clientX - rect.left, rect.width));
                      setSliderPosition((x / rect.width) * 100);
                    }}
                    onTouchMove={(e) => {
                      if (e.touches.length > 0) {
                        const rect = e.currentTarget.getBoundingClientRect();
                        const x = Math.max(0, Math.min(e.touches[0].clientX - rect.left, rect.width));
                        setSliderPosition((x / rect.width) * 100);
                      }
                    }}
                  >
                    {/* Graded Master (Full Background) */}
                    <img
                      src={selectedProject.imageUrl}
                      alt="Graded Master"
                      className="absolute inset-0 w-full h-full object-cover"
                    />

                    {/* RAW / Flat Profile (Clipped Overlay) */}
                    <div 
                      className="absolute inset-0 overflow-hidden"
                      style={{ width: `${sliderPosition}%` }}
                    >
                      <img
                        src={selectedProject.beforeImageUrl || selectedProject.imageUrl}
                        alt="RAW Profile"
                        className="absolute inset-0 w-full h-full object-cover filter saturate-50 contrast-75 brightness-110"
                        style={{ width: '100%', maxWidth: 'none' }}
                      />
                      <div className="absolute top-3 left-3 bg-black/70 px-2.5 py-1 rounded text-[10px] font-mono text-zinc-300">
                        RAW Unprocessed
                      </div>
                    </div>

                    <div className="absolute top-3 right-3 bg-purple-900/80 px-2.5 py-1 rounded text-[10px] font-mono text-purple-200">
                      Color Graded Master
                    </div>

                    {/* Divider Handle */}
                    <div
                      className="compare-handle"
                      style={{ left: `${sliderPosition}%` }}
                    >
                      <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-7 h-7 rounded-full bg-white text-black flex items-center justify-center shadow-xl text-xs font-bold">
                        ↔
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Project Details & EXIF Bar */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
                
                {/* Description */}
                <div className="md:col-span-7 space-y-3">
                  <h4 className="text-sm font-bold text-white">Creative Concept & Execution</h4>
                  <p className="text-xs sm:text-sm text-zinc-300 leading-relaxed">
                    {selectedProject.description}
                  </p>
                  
                  <div className="flex flex-wrap gap-2 pt-2">
                    {selectedProject.tags.map((tag, tIdx) => (
                      <span
                        key={tIdx}
                        className="px-2.5 py-1 rounded-full bg-purple-950/80 text-purple-300 text-[11px] font-mono border border-purple-500/20"
                      >
                        #{tag}
                      </span>
                    ))}
                  </div>
                </div>

                {/* EXIF Data Box */}
                <div className="md:col-span-5 bg-zinc-950/80 p-4 rounded-2xl border border-white/10 space-y-3">
                  <div className="flex items-center gap-2 text-xs font-mono text-purple-400 font-semibold uppercase">
                    <Aperture className="w-3.5 h-3.5" />
                    <span>EXIF Capture Specs</span>
                  </div>

                  <div className="grid grid-cols-2 gap-2.5 text-xs">
                    <div>
                      <span className="text-[10px] text-zinc-500 block uppercase">Camera</span>
                      <span className="text-zinc-200 font-medium">{selectedProject.exif.camera}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-zinc-500 block uppercase">Lens</span>
                      <span className="text-zinc-200 font-medium">{selectedProject.exif.lens}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-zinc-500 block uppercase">Aperture</span>
                      <span className="text-zinc-200 font-medium font-mono">{selectedProject.exif.aperture}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-zinc-500 block uppercase">Shutter</span>
                      <span className="text-zinc-200 font-medium font-mono">{selectedProject.exif.shutterSpeed}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-zinc-500 block uppercase">ISO</span>
                      <span className="text-zinc-200 font-medium font-mono">{selectedProject.exif.iso}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-zinc-500 block uppercase">Focal Length</span>
                      <span className="text-zinc-200 font-medium font-mono">{selectedProject.exif.focalLength}</span>
                    </div>
                  </div>
                </div>

              </div>

            </div>

          </div>
        </div>
      )}
    </section>
  );
}
