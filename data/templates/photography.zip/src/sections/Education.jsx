import React from 'react';
import { GraduationCap, Award, Calendar, MapPin, BookOpen } from 'lucide-react';
import { photographyProfile } from '../data/photographyDefaults.js';

const _default = photographyProfile || {};

export default function Education({ data = {} }) {
  const rawEdu = Array.isArray(data?.education) && data.education.length > 0 ? data.education : (_default.education || []);

  const educations = rawEdu.map((edu, idx) => {
    const id = edu?.id || `edu-${idx + 1}`;
    const rawDegree = edu?.degree || edu?.title || 'Bachelor of Fine Arts';
    const rawField = edu?.fieldOfStudy || edu?.major || edu?.field || edu?.specialization || '';
    
    // If degree already contains the field of study, avoid duplication
    const displayDegree = rawDegree;
    const displayField = rawField && !rawDegree.toLowerCase().includes(rawField.toLowerCase()) ? rawField : '';

    const degKey = `text:education:card:${id}:degree`;
    const fieldKey = `text:education:card:${id}:fieldOfStudy`;
    const instKey = `text:education:card:${id}:institution`;
    const periodKey = `text:education:card:${id}:period`;
    const gpaKey = `text:education:card:${id}:gpa`;
    const honorsKey = `text:education:card:${id}:honors`;
    const descKey = `text:education:card:${id}:description`;

    return {
      id,
      degree: data?.contentOverrides?.[degKey]?.value || (typeof data?.contentOverrides?.[degKey] === 'string' ? data?.contentOverrides?.[degKey] : null) || displayDegree,
      fieldOfStudy: data?.contentOverrides?.[fieldKey]?.value || (typeof data?.contentOverrides?.[fieldKey] === 'string' ? data?.contentOverrides?.[fieldKey] : null) || displayField,
      institution: data?.contentOverrides?.[instKey]?.value || (typeof data?.contentOverrides?.[instKey] === 'string' ? data?.contentOverrides?.[instKey] : null) || edu?.institution || edu?.school || edu?.university || 'University School of Arts',
      location: edu?.location || '',
      period: data?.contentOverrides?.[periodKey]?.value || (typeof data?.contentOverrides?.[periodKey] === 'string' ? data?.contentOverrides?.[periodKey] : null) || edu?.period || edu?.year || '2022 - 2026',
      gpa: data?.contentOverrides?.[gpaKey]?.value || (typeof data?.contentOverrides?.[gpaKey] === 'string' ? data?.contentOverrides?.[gpaKey] : null) || edu?.gpa || '',
      honors: data?.contentOverrides?.[honorsKey]?.value || (typeof data?.contentOverrides?.[honorsKey] === 'string' ? data?.contentOverrides?.[honorsKey] : null) || edu?.honors || '',
      description: data?.contentOverrides?.[descKey]?.value || (typeof data?.contentOverrides?.[descKey] === 'string' ? data?.contentOverrides?.[descKey] : null) || edu?.description || '',
      coursework: Array.isArray(edu?.coursework) ? edu.coursework : (Array.isArray(edu?.courses) ? edu.courses : []),
      degKey,
      fieldKey,
      instKey,
      periodKey,
      gpaKey,
      honorsKey,
      descKey
    };
  });

  return (
    <section 
      id="education" 
      data-cv-section="education"
      data-node-id="section:education:root:section:0"
      className="py-16 sm:py-24 bg-[#0b0713] text-white relative"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 sm:mb-16 gap-4">
          <div>
            <div className="inline-flex items-center gap-2 text-xs font-mono tracking-widest uppercase text-purple-400 font-semibold mb-2">
              <GraduationCap className="w-3.5 h-3.5" />
              <span>ACADEMIC FOUNDATION & CRITIQUE</span>
            </div>
            <h2 
              data-node-id="text:education:heading"
              data-node-type="text"
              className="text-2xl sm:text-4xl md:text-5xl font-extrabold text-white tracking-tight cursor-text"
            >
              Education & Residencies
            </h2>
          </div>
        </div>

        {/* Education Cards Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 sm:gap-8">
          {educations.map((edu) => (
            <div
              key={edu.id}
              data-node-id={`item:education:card:${edu.id}`}
              className="glass-panel p-6 sm:p-8 rounded-3xl border border-white/10 hover:border-purple-500/40 transition-all flex flex-col justify-between space-y-6 pointer-events-auto"
            >
              <div>
                <div className="flex items-center justify-between gap-4 border-b border-white/10 pb-4 mb-4">
                  {edu.gpa && (
                    <div 
                      data-node-id={edu.gpaKey}
                      data-node-type="text"
                      className="text-xs font-mono text-purple-400 bg-purple-950/80 px-3 py-1 rounded-full border border-purple-500/30 cursor-text"
                    >
                      GPA: {edu.gpa}
                    </div>
                  )}
                  <div className="flex items-center gap-1.5 text-xs text-zinc-400 font-mono ml-auto">
                    <Calendar className="w-3.5 h-3.5 pointer-events-none" />
                    <span 
                      data-node-id={edu.periodKey}
                      data-node-type="text"
                      className="cursor-text"
                    >
                      {edu.period}
                    </span>
                  </div>
                </div>

                <h3 
                  data-node-id={edu.degKey}
                  data-node-type="text"
                  className="text-lg sm:text-xl font-bold text-white leading-snug cursor-text"
                >
                  {edu.degree}
                </h3>
                
                {edu.fieldOfStudy && (
                  <div className="text-xs sm:text-sm font-semibold text-purple-300 mt-1">
                    Field of Study: <span 
                      data-node-id={edu.fieldKey}
                      data-node-type="text"
                      className="text-white font-medium cursor-text"
                    >
                      {edu.fieldOfStudy}
                    </span>
                  </div>
                )}

                <div 
                  data-node-id={edu.instKey}
                  data-node-type="text"
                  className="text-sm font-semibold text-zinc-300 mt-1.5 cursor-text"
                >
                  {edu.institution} {edu.location ? `• ${edu.location}` : ''}
                </div>

                {edu.description && (
                  <p 
                    data-node-id={edu.descKey}
                    data-node-type="text"
                    className="text-xs sm:text-sm text-zinc-300 mt-3 leading-relaxed cursor-text"
                  >
                    {edu.description}
                  </p>
                )}

                {edu.honors && (
                  <div className="flex items-center gap-2 mt-4 p-3 rounded-2xl bg-purple-950/40 border border-purple-500/20 text-xs text-purple-200">
                    <Award className="w-4 h-4 text-purple-400 shrink-0 pointer-events-none" />
                    <span 
                      data-node-id={edu.honorsKey}
                      data-node-type="text"
                      className="cursor-text"
                    >
                      {edu.honors}
                    </span>
                  </div>
                )}
              </div>

              {/* Coursework Tags */}
              {edu.coursework.length > 0 && (
                <div>
                  <div className="text-[11px] font-mono text-zinc-400 uppercase mb-2">Key Coursework</div>
                  <div className="flex flex-wrap gap-2">
                    {edu.coursework.map((c, cIdx) => (
                      <span
                        key={cIdx}
                        className="px-2.5 py-1 rounded-xl bg-zinc-900 text-zinc-300 text-xs border border-white/5"
                      >
                        {typeof c === 'string' ? c : c?.name || ''}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
