import React, { useState } from 'react';
import { Camera, Cpu, Sparkles, CheckCircle2, Package, Film, Zap } from 'lucide-react';
import { photographyProfile } from '../data/photographyDefaults.js';

const _default = photographyProfile || {};

export default function Skills({ data = {} }) {
  const [activeTab, setActiveTab] = useState('skills');

  // Format skills
  const rawSkills = Array.isArray(data?.skills) && data.skills.length > 0 ? data.skills : (_default.skills || []);
  
  // Normalize skills categories to avoid 1-card-per-skill repetition
  let skillCategories = [];
  const isStringArray = rawSkills.length > 0 && rawSkills.some(s => typeof s === 'string');

  if (isStringArray) {
    // Extract all string skills cleanly
    const stringList = [];
    rawSkills.forEach(item => {
      if (typeof item === 'string') {
        stringList.push(item);
      } else if (item?.name && typeof item.name === 'string' && !Array.isArray(item.skills)) {
        stringList.push(item.name);
      } else if (Array.isArray(item?.skills)) {
        item.skills.forEach(sub => {
          stringList.push(typeof sub === 'string' ? sub : sub?.name || 'Skill');
        });
      }
    });

    // Chunk into at most 3 balanced cards
    const total = stringList.length;
    if (total <= 5) {
      skillCategories = [{
        name: 'Core Competencies & Tools',
        skills: stringList.map(s => ({ name: s, tag: 'Proficient' }))
      }];
    } else {
      const perCard = Math.ceil(total / 3);
      const c1 = stringList.slice(0, perCard);
      const c2 = stringList.slice(perCard, perCard * 2);
      const c3 = stringList.slice(perCard * 2);

      skillCategories = [
        { name: 'Core Methodologies & Systems', skills: c1.map(s => ({ name: s, tag: 'Expert' })) },
        { name: 'Technical Stack & Tools', skills: c2.map(s => ({ name: s, tag: 'Advanced' })) },
        ...(c3.length > 0 ? [{ name: 'Specialized Applications', skills: c3.map(s => ({ name: s, tag: 'Proficient' })) }] : [])
      ];
    }
  } else {
    // Already structured categories
    skillCategories = rawSkills.map((cat, idx) => {
      const catName = cat?.name || cat?.category || 'Core Skill Area';
      const items = Array.isArray(cat?.skills) 
        ? cat.skills.map((s) => typeof s === 'string' ? { name: s, tag: 'Advanced' } : { name: s?.name || 'Skill', tag: s?.tag || 'Expert' })
        : (Array.isArray(cat?.items) ? cat.items.map((s) => ({ name: typeof s === 'string' ? s : s?.name, tag: 'Expert' })) : []);
      return { name: catName, skills: items };
    });
  }

  // Gear items: clean camera / hardware gear
  const rawGear = Array.isArray(data?.gear) && data.gear.length > 0 ? data.gear : (_default.gear || []);
  const gearItems = rawGear.map((item, idx) => {
    if (typeof item === 'string') {
      return {
        id: `gear-${idx}`,
        category: 'Hardware & Rig',
        name: item,
        model: 'Professional Equipment'
      };
    }
    return {
      id: item?.id || `gear-${idx}`,
      category: item?.category || 'Hardware & Studio',
      name: item?.name || item?.title || 'Equipment Item',
      model: item?.model || item?.description || 'Active Studio Rig'
    };
  });

  return (
    <section id="skills" className="py-16 sm:py-24 bg-[#0b0713] text-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header with Tab Switcher */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-10 sm:mb-16 gap-5 sm:gap-6">
          <div>
            <div className="inline-flex items-center gap-2 text-xs font-mono tracking-widest uppercase text-purple-400 font-semibold mb-2">
              <Sparkles className="w-3.5 h-3.5" />
              <span>TECHNICAL MASTERY & EQUIPMENT</span>
            </div>
            <h2 className="text-2xl sm:text-4xl md:text-5xl font-extrabold text-white tracking-tight">
              Skills & Camera Rig
            </h2>
          </div>

          {/* Toggle Tab */}
          <div className="flex items-center gap-1.5 sm:gap-2 bg-zinc-950 p-1 sm:p-1.5 rounded-full border border-white/10 self-start sm:self-auto">
            <button
              type="button"
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                setActiveTab('skills');
              }}
              className={`flex items-center gap-1.5 sm:gap-2 px-4 sm:px-5 py-2 rounded-full text-xs font-semibold transition-all cursor-pointer ${
                activeTab === 'skills'
                  ? 'bg-purple-600 text-white shadow-lg shadow-purple-500/30'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              <Cpu className="w-3.5 h-3.5" />
              <span>Software & Craft</span>
            </button>

            <button
              type="button"
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                setActiveTab('gear');
              }}
              className={`flex items-center gap-1.5 sm:gap-2 px-4 sm:px-5 py-2 rounded-full text-xs font-semibold transition-all cursor-pointer ${
                activeTab === 'gear'
                  ? 'bg-purple-600 text-white shadow-lg shadow-purple-500/30'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              <Camera className="w-3.5 h-3.5" />
              <span>Gear & Studio Kit</span>
            </button>
          </div>
        </div>

        {/* Tab 1: Skills Breakdown */}
        {activeTab === 'skills' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 sm:gap-6 lg:gap-8">
            {skillCategories.map((category, idx) => (
              <div
                key={idx}
                className={`glass-panel p-5 sm:p-7 rounded-3xl border border-white/10 flex flex-col justify-between space-y-5 hover:border-purple-500/40 transition-all duration-300 ${
                  skillCategories.length === 3 && idx === 2 ? 'md:col-span-2 lg:col-span-1' : ''
                }`}
              >
                <div>
                  <div className="flex items-center gap-2 mb-4 sm:mb-6">
                    <div className="w-2.5 h-2.5 rounded-full bg-purple-400" />
                    <h3 className="text-base sm:text-lg font-bold text-white tracking-tight">
                      {category.name}
                    </h3>
                  </div>

                  <div className="space-y-2.5 sm:space-y-3">
                    {category.skills.map((skill, sIdx) => (
                      <div
                        key={sIdx}
                        className="flex items-center justify-between p-2.5 sm:p-3 rounded-2xl bg-zinc-900/60 border border-white/5 hover:border-white/10 transition-colors"
                      >
                        <div className="flex items-center gap-2.5">
                          <CheckCircle2 className="w-4 h-4 text-purple-400 shrink-0" />
                          <span className="text-xs sm:text-sm text-zinc-200 font-medium">
                            {skill.name}
                          </span>
                        </div>
                        {skill.tag && (
                          <span className="text-[10px] sm:text-[11px] font-mono font-medium text-purple-300 bg-purple-950/80 px-2.5 py-0.5 sm:py-1 rounded-full border border-purple-500/30">
                            {skill.tag}
                          </span>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Tab 2: Camera Kit & Equipment */}
        {activeTab === 'gear' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 gear-card-grid">
            {gearItems.map((item, idx) => (
              <div
                key={item.id || idx}
                className="p-5 sm:p-6 rounded-3xl bg-zinc-900/60 border border-white/10 hover:border-purple-500/40 transition-all flex flex-col justify-between space-y-3"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] sm:text-[11px] font-mono text-purple-400 uppercase tracking-wider bg-purple-950/60 px-2.5 py-1 rounded-full border border-purple-500/20">
                    {item.category}
                  </span>
                  <Camera className="w-4 h-4 text-zinc-500" />
                </div>

                <div>
                  <h4 className="text-base sm:text-lg font-bold text-white tracking-tight">
                    {item.name}
                  </h4>
                  <p className="text-xs sm:text-sm text-zinc-300 mt-1">
                    {item.model}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}

      </div>
    </section>
  );
}
