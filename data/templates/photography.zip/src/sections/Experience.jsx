import React from 'react';
import { Camera, Calendar, MapPin, Sparkles, CheckCircle2, Briefcase } from 'lucide-react';
import { photographyProfile } from '../data/photographyDefaults.js';

const _default = photographyProfile || {};

export default function Experience({ data = {} }) {
  const rawExp = Array.isArray(data?.experience) && data.experience.length > 0 ? data.experience : (_default.experience || []);

  const experiences = rawExp.map((exp, idx) => {
    const id = exp?.id || `exp-${idx + 1}`;
    const roleKey = `text:experience:card:${id}:role`;
    const compKey = `text:experience:card:${id}:company`;
    const locKey = `text:experience:card:${id}:location`;
    const periodKey = `text:experience:card:${id}:period`;
    const typeKey = `text:experience:card:${id}:type`;
    const descKey = `text:experience:card:${id}:description`;

    return {
      id,
      role: data?.contentOverrides?.[roleKey]?.value || (typeof data?.contentOverrides?.[roleKey] === 'string' ? data?.contentOverrides?.[roleKey] : null) || exp?.role || exp?.title || exp?.position || 'Editorial Photographer',
      company: data?.contentOverrides?.[compKey]?.value || (typeof data?.contentOverrides?.[compKey] === 'string' ? data?.contentOverrides?.[compKey] : null) || exp?.company || exp?.organization || 'Studio Production',
      location: data?.contentOverrides?.[locKey]?.value || (typeof data?.contentOverrides?.[locKey] === 'string' ? data?.contentOverrides?.[locKey] : null) || exp?.location || 'New York, NY',
      period: data?.contentOverrides?.[periodKey]?.value || (typeof data?.contentOverrides?.[periodKey] === 'string' ? data?.contentOverrides?.[periodKey] : null) || exp?.period || exp?.duration || '2023 - Present',
      type: data?.contentOverrides?.[typeKey]?.value || (typeof data?.contentOverrides?.[typeKey] === 'string' ? data?.contentOverrides?.[typeKey] : null) || exp?.type || 'Studio Experience',
      description: data?.contentOverrides?.[descKey]?.value || (typeof data?.contentOverrides?.[descKey] === 'string' ? data?.contentOverrides?.[descKey] : null) || exp?.description || exp?.desc || 'Directing photo coverage for high-profile productions.',
      highlights: Array.isArray(exp?.highlights) ? exp.highlights : (Array.isArray(exp?.achievements) ? exp.achievements : []),
      roleKey,
      compKey,
      locKey,
      periodKey,
      typeKey,
      descKey
    };
  });

  return (
    <section 
      id="experience" 
      data-cv-section="experience"
      data-node-id="section:experience:root:section:0"
      className="py-16 sm:py-24 bg-[#0e0919] text-white relative"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 sm:mb-16 gap-4">
          <div>
            <div className="inline-flex items-center gap-2 text-xs font-mono tracking-widest uppercase text-purple-400 font-semibold mb-2">
              <Briefcase className="w-3.5 h-3.5" />
              <span>STUDIO & FIELD APPOINTMENTS</span>
            </div>
            <h2 
              data-node-id="text:experience:heading"
              data-node-type="text"
              className="text-2xl sm:text-4xl md:text-5xl font-extrabold text-white tracking-tight cursor-text"
            >
              Production Experience
            </h2>
          </div>
        </div>

        {/* Experience Timeline Cards */}
        <div className="space-y-6 sm:space-y-8">
          {experiences.map((exp) => (
            <div
              key={exp.id}
              data-node-id={`item:experience:card:${exp.id}`}
              className="glass-panel p-6 sm:p-8 rounded-3xl border border-white/10 hover:border-purple-500/40 transition-all duration-300 relative overflow-hidden group pointer-events-auto"
            >
              {/* Subtle Ambient Pill */}
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/10 pb-5 mb-5">
                <div>
                  <div className="flex items-center gap-2.5">
                    <span 
                      data-node-id={exp.typeKey}
                      data-node-type="text"
                      className="text-xs font-mono text-purple-400 bg-purple-950/80 px-2.5 py-1 rounded-full border border-purple-500/30 cursor-text"
                    >
                      {exp.type}
                    </span>
                    <span 
                      data-node-id={exp.locKey}
                      data-node-type="text"
                      className="text-xs text-zinc-400 font-mono cursor-text"
                    >
                      {exp.location}
                    </span>
                  </div>
                  <h3 
                    data-node-id={exp.roleKey}
                    data-node-type="text"
                    className="text-lg sm:text-2xl font-bold text-white mt-2 group-hover:text-purple-300 transition-colors cursor-text"
                  >
                    {exp.role}
                  </h3>
                  <div 
                    data-node-id={exp.compKey}
                    data-node-type="text"
                    className="text-sm font-semibold text-zinc-300 cursor-text mt-0.5"
                  >
                    {exp.company}
                  </div>
                </div>

                <div className="flex items-center gap-2 text-xs font-mono text-zinc-300 bg-black/40 px-3.5 py-2 rounded-2xl border border-white/10 self-start md:self-auto">
                  <Calendar className="w-3.5 h-3.5 text-purple-400 pointer-events-none" />
                  <span 
                    data-node-id={exp.periodKey}
                    data-node-type="text"
                    className="cursor-text"
                  >
                    {exp.period}
                  </span>
                </div>
              </div>

              {/* Description */}
              <p 
                data-node-id={exp.descKey}
                data-node-type="text"
                className="text-xs sm:text-sm text-zinc-300 leading-relaxed max-w-4xl mb-4 cursor-text"
              >
                {exp.description}
              </p>

              {/* Highlights List */}
              {exp.highlights.length > 0 && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5 pt-2">
                  {exp.highlights.map((h, hIdx) => {
                    const hKey = `text:experience:card:${exp.id}:highlight:${hIdx}`;
                    const hText = data?.contentOverrides?.[hKey]?.value || (typeof h === 'string' ? h : h?.title || '');
                    return (
                      <div key={hIdx} className="flex items-start gap-2 text-xs text-zinc-300">
                        <CheckCircle2 className="w-3.5 h-3.5 text-purple-400 shrink-0 mt-0.5 pointer-events-none" />
                        <span 
                          data-node-id={hKey}
                          data-node-type="text"
                          className="cursor-text"
                        >
                          {hText}
                        </span>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
