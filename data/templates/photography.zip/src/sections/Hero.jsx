import React from 'react';
import { ArrowUpRight, Sparkles, Camera, Layers, Aperture, Eye } from 'lucide-react';
import { photographyProfile } from '../data/photographyDefaults.js';

const _default = photographyProfile || {};

export default function Hero({ data = {} }) {
  const name = 
    data?.contentOverrides?.['text:hero:name']?.value ||
    (typeof data?.contentOverrides?.['text:hero:name'] === 'string' ? data?.contentOverrides?.['text:hero:name'] : null) ||
    data?.hero?.name || data?.name || data?.fullName || _default.name || 'Elena Vance';

  const headline = 
    data?.contentOverrides?.['text:hero:headline']?.value ||
    (typeof data?.contentOverrides?.['text:hero:headline'] === 'string' ? data?.contentOverrides?.['text:hero:headline'] : null) ||
    data?.hero?.headline || data?.heroHeadline || data?.headline || _default.heroHeadline || 'Capturing stories that last a lifetime';
  
  const rawBio = 
    data?.contentOverrides?.['text:hero:bio']?.value ||
    (typeof data?.contentOverrides?.['text:hero:bio'] === 'string' ? data?.contentOverrides?.['text:hero:bio'] : null) ||
    data?.contentOverrides?.['text:hero:description']?.value ||
    (typeof data?.contentOverrides?.['text:hero:description'] === 'string' ? data?.contentOverrides?.['text:hero:description'] : null) ||
    data?.hero?.description || data?.hero?.bio || data?.heroSubheadline || data?.bio || data?.summary || data?.aboutSummary;
  const bio = rawBio || _default.heroSubheadline || 'Exploring human emotional depth, dynamic fashion palettes, and analog textures through purposeful light and visual storytelling.';
  
  const badgeText = 
    data?.contentOverrides?.['text:hero:badge']?.value ||
    (typeof data?.contentOverrides?.['text:hero:badge'] === 'string' ? data?.contentOverrides?.['text:hero:badge'] : null) ||
    data?.hero?.badge || data?.heroBadge || _default.heroBadge || 'Available for Editorial & Grad Portraits';

  const heroTag1 = 
    data?.contentOverrides?.['text:hero:tag1']?.value ||
    (typeof data?.contentOverrides?.['text:hero:tag1'] === 'string' ? data?.contentOverrides?.['text:hero:tag1'] : null) ||
    'Editorial & Fashion';

  const heroTag2Label = 
    data?.contentOverrides?.['text:hero:tag2:label']?.value ||
    (typeof data?.contentOverrides?.['text:hero:tag2:label'] === 'string' ? data?.contentOverrides?.['text:hero:tag2:label'] : null) ||
    'Specialty';

  const heroTag2Value = 
    data?.contentOverrides?.['text:hero:tag2:value']?.value ||
    (typeof data?.contentOverrides?.['text:hero:tag2:value'] === 'string' ? data?.contentOverrides?.['text:hero:tag2:value'] : null) ||
    'Studio & Analog 35mm';

  const heroTag3Title = 
    data?.contentOverrides?.['text:hero:tag3:title']?.value ||
    (typeof data?.contentOverrides?.['text:hero:tag3:title'] === 'string' ? data?.contentOverrides?.['text:hero:tag3:title'] : null) ||
    '4+ Years Active';

  const heroTag3Sub = 
    data?.contentOverrides?.['text:hero:tag3:sub']?.value ||
    (typeof data?.contentOverrides?.['text:hero:tag3:sub'] === 'string' ? data?.contentOverrides?.['text:hero:tag3:sub'] : null) ||
    '140+ Projects Shot';

  // Hero Editorial Cover Image (support all override keys and image bindings)
  const defaultCover = 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=1200&q=85';
  const heroImage = 
    data?.contentOverrides?.['image:hero:cover:0']?.src ||
    (typeof data?.contentOverrides?.['image:hero:cover:0'] === 'string' ? data?.contentOverrides?.['image:hero:cover:0'] : null) ||
    data?.contentOverrides?.['image:hero:root:img:0']?.src ||
    (typeof data?.contentOverrides?.['image:hero:root:img:0'] === 'string' ? data?.contentOverrides?.['image:hero:root:img:0'] : null) ||
    data?.imageOverrides?.['hero.coverImage'] ||
    data?.imageOverrides?.['coverImage'] ||
    data?.imageOverrides?.['heroImage'] ||
    data?.hero?.coverImage ||
    data?.avatarUrl ||
    data?.profileImage ||
    defaultCover;

  return (
    <section 
      id="hero" 
      data-cv-section="hero"
      data-node-id="section:hero:root:section:0"
      className="relative min-h-[92vh] flex flex-col justify-center pt-24 sm:pt-32 pb-12 sm:pb-16 overflow-hidden bg-gradient-to-b from-[#4c1d95] via-[#24104c] to-[#0b0713]"
    >
      {/* Glowing Ambient Light Orbs */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[300px] sm:w-[500px] lg:w-[650px] h-[300px] sm:h-[500px] lg:h-[650px] bg-purple-500/20 rounded-full blur-[100px] sm:blur-[140px] pointer-events-none -z-0" />
      <div className="absolute top-12 right-10 w-[200px] sm:w-[350px] h-[200px] sm:h-[350px] bg-fuchsia-500/20 rounded-full blur-[90px] sm:blur-[120px] pointer-events-none -z-0" />

      {/* Main Hero Container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 sm:gap-12 items-center">
        
        {/* Left Column: Headline & Bio Tagline */}
        <div className="lg:col-span-6 space-y-4 sm:space-y-6 text-center lg:text-left flex flex-col items-center lg:items-start">
          
          {/* Status Badge */}
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/10 border border-white/20 backdrop-blur-md text-purple-200 text-xs font-medium tracking-wide pointer-events-auto">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping pointer-events-none" />
            <span className="w-2 h-2 rounded-full bg-emerald-400 -ml-4 pointer-events-none" />
            <span 
              data-node-id="text:hero:badge"
              data-node-type="text"
              data-cv="hero.badge"
              className="cursor-text pointer-events-auto"
            >
              {badgeText}
            </span>
          </div>

          {/* Main Hero Headline */}
          <h1 
            data-node-id="text:hero:headline"
            data-node-type="text"
            data-cv="hero.headline"
            className="text-3xl sm:text-5xl md:text-6xl font-extrabold text-white tracking-tight leading-[1.1] sm:leading-[1.05] drop-shadow-sm max-w-2xl font-sans cursor-text pointer-events-auto"
          >
            {headline}
          </h1>

          {/* Subheadline */}
          <p 
            data-node-id="text:hero:bio"
            data-node-type="text"
            data-cv="hero.description"
            className="text-sm sm:text-base md:text-lg text-purple-100/80 max-w-xl font-normal leading-relaxed cursor-text pointer-events-auto"
          >
            {bio}
          </p>

          {/* Action CTAs */}
          <div className="flex flex-wrap items-center justify-center lg:justify-start gap-3 sm:gap-4 pt-2 w-full sm:w-auto pointer-events-auto">
            <a
              href="#portfolio"
              className="inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-full bg-white text-black font-semibold text-xs sm:text-sm hover:bg-purple-100 hover:shadow-xl hover:shadow-white/20 transition-all cursor-pointer group w-full sm:w-auto pointer-events-auto"
            >
              <span>View Visual Archives</span>
              <ArrowUpRight className="w-4 h-4 text-black group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform pointer-events-none" />
            </a>

            <a
              href="#contact"
              className="inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-full bg-black/40 hover:bg-black/60 text-white border border-white/20 backdrop-blur-md font-semibold text-xs sm:text-sm transition-all w-full sm:w-auto pointer-events-auto"
            >
              <Sparkles className="w-4 h-4 text-purple-400 pointer-events-none" />
              <span>Contact & Booking</span>
            </a>
          </div>
        </div>

        {/* Right Column: Hero Visual & Floating Badges */}
        <div className="lg:col-span-6 relative flex justify-center items-center mt-4 lg:mt-0">
          
          {/* Main Editorial Hero Image */}
          <div className="relative w-full max-w-[320px] sm:max-w-[400px] md:max-w-[440px] aspect-[4/5] rounded-3xl overflow-hidden border border-white/20 shadow-2xl shadow-purple-900/60 group">
            <img
              src={heroImage}
              data-node-id="image:hero:cover:0"
              data-node-type="image"
              data-cv="hero.coverImage"
              alt="Editorial Photography Model"
              className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700 cursor-pointer pointer-events-auto"
            />
            
            {/* Gradient Overlay (pointer-events-none allows clicks directly onto img) */}
            <div className="absolute inset-0 bg-gradient-to-t from-purple-950/80 via-transparent to-transparent opacity-60 pointer-events-none" />

            {/* Floating Live Badge inside card */}
            <div className="absolute top-4 left-4 glass-pill px-3 py-1.5 rounded-full text-xs font-medium text-white flex items-center gap-1.5 pointer-events-auto z-20">
              <Camera className="w-3.5 h-3.5 text-purple-300 pointer-events-none" />
              <span 
                data-node-id="text:hero:tag1"
                data-node-type="text"
                className="cursor-text pointer-events-auto"
              >
                {heroTag1}
              </span>
            </div>

            {/* Floating Bottom Badge */}
            <div className="absolute bottom-4 right-4 glass-panel-light px-3.5 py-2.5 rounded-2xl text-xs font-semibold text-white shadow-xl flex items-center gap-2.5 animate-float pointer-events-auto z-20">
              <div className="w-7 h-7 rounded-xl bg-purple-600/40 flex items-center justify-center border border-white/30 text-purple-200 pointer-events-none">
                <Aperture className="w-4 h-4 pointer-events-none" />
              </div>
              <div className="pointer-events-auto">
                <span 
                  data-node-id="text:hero:tag2:label"
                  data-node-type="text"
                  className="block text-[9px] text-purple-200/80 uppercase tracking-wider font-mono cursor-text"
                >
                  {heroTag2Label}
                </span>
                <span 
                  data-node-id="text:hero:tag2:value"
                  data-node-type="text"
                  className="text-white text-xs font-bold cursor-text"
                >
                  {heroTag2Value}
                </span>
              </div>
            </div>
          </div>

          {/* Floating Accompanying Mini Badge on Left */}
          <div className="hidden md:flex absolute -bottom-4 -left-4 lg:-left-6 glass-panel border border-white/20 p-3 rounded-2xl shadow-2xl items-center gap-3 animate-float [animation-delay:2s] pointer-events-auto z-20">
            <div className="w-10 h-10 rounded-xl bg-purple-600/30 flex items-center justify-center border border-purple-400/30 text-purple-300 shrink-0 pointer-events-none">
              <Layers className="w-5 h-5 pointer-events-none" />
            </div>
            <div className="pointer-events-auto">
              <span 
                data-node-id="text:hero:tag3:title"
                data-node-type="text"
                className="block text-xs font-bold text-white cursor-text"
              >
                {heroTag3Title}
              </span>
              <span 
                data-node-id="text:hero:tag3:sub"
                data-node-type="text"
                className="block text-[10px] text-zinc-400 font-mono cursor-text"
              >
                {heroTag3Sub}
              </span>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
}
