import React from 'react';
import { Mail, Phone, MapPin, Sparkles, ArrowUpRight, Camera, Globe, Instagram, Linkedin, MessageCircle } from 'lucide-react';
import { photographyProfile } from '../data/photographyDefaults.js';

const _default = photographyProfile || {};

export default function Contact({ data = {} }) {
  const email = data?.contact?.email || data?.email || _default.email || 'hello@elenavancephoto.com';
  const phone = data?.contact?.phone || data?.phone || _default.phone || '+1 (555) 438-9201';
  const location = data?.contact?.location || data?.location || _default.location || 'New York, NY';
  
  return (
    <section 
      id="contact" 
      data-cv-section="contact"
      data-node-id="section:contact:root:section:0"
      className="py-16 sm:py-24 bg-gradient-to-b from-[#0e0919] via-[#150a2a] to-[#0b0713] text-white relative overflow-hidden"
    >
      {/* Background Ambient Glow */}
      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 w-96 sm:w-[600px] h-96 sm:h-[600px] bg-purple-600/15 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-12 sm:mb-16">
          <div className="inline-flex items-center gap-2 text-xs font-mono tracking-widest uppercase text-purple-400 font-semibold mb-2">
            <Sparkles className="w-3.5 h-3.5" />
            <span>COMMISSIONS & INQUIRIES</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight" data-node-id="text:contact:title">
            Let’s Connect & Collaborate
          </h2>
          <p className="text-sm sm:text-base text-purple-200/80 mt-3" data-node-id="text:contact:desc">
            Open for editorial shoots, collaborative creative projects, consulting, and professional commissions.
          </p>
        </div>

        {/* Direct Contact Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 sm:gap-6 mb-8">
          
          {/* 1. Email Card */}
          <div
            data-node-id="container:contact:card:email"
            className="glass-panel p-6 sm:p-7 rounded-3xl border border-white/10 hover:border-purple-500/50 transition-all flex flex-col justify-between items-center text-center group min-h-[240px]"
          >
            <div className="flex flex-col items-center w-full">
              <div className="w-12 h-12 rounded-2xl bg-purple-600/30 flex items-center justify-center text-purple-300 group-hover:bg-purple-600 group-hover:text-white transition-colors mb-4 shadow-lg shadow-purple-900/30">
                <Mail className="w-5 h-5" />
              </div>
              <div className="text-[10px] sm:text-[11px] font-mono text-purple-300/90 uppercase tracking-wider font-semibold mb-1">
                Email Inquiries
              </div>
              <div 
                data-cv="contact.email"
                data-node-id="text:contact:email"
                className="text-sm sm:text-base font-bold text-white break-all leading-snug"
              >
                {email}
              </div>
            </div>

            <a
              href={`mailto:${email}`}
              className="mt-5 inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-white/10 hover:bg-purple-600 text-purple-200 hover:text-white text-xs font-semibold transition-all"
            >
              <span>Write Email</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </a>
          </div>

          {/* 2. Phone Card */}
          <div
            data-node-id="container:contact:card:phone"
            className="glass-panel p-6 sm:p-7 rounded-3xl border border-white/10 hover:border-purple-500/50 transition-all flex flex-col justify-between items-center text-center group min-h-[240px]"
          >
            <div className="flex flex-col items-center w-full">
              <div className="w-12 h-12 rounded-2xl bg-purple-600/30 flex items-center justify-center text-purple-300 group-hover:bg-purple-600 group-hover:text-white transition-colors mb-4 shadow-lg shadow-purple-900/30">
                <Phone className="w-5 h-5" />
              </div>
              <div className="text-[10px] sm:text-[11px] font-mono text-purple-300/90 uppercase tracking-wider font-semibold mb-1">
                Phone & Studio
              </div>
              <div 
                data-cv="contact.phone"
                data-node-id="text:contact:phone"
                className="text-sm sm:text-base font-bold text-white leading-snug"
              >
                {phone || '+1 (555) 000-0000'}
              </div>
            </div>

            {phone ? (
              <a
                href={`tel:${phone}`}
                className="mt-5 inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-white/10 hover:bg-purple-600 text-purple-200 hover:text-white text-xs font-semibold transition-all"
              >
                <span>Call Studio</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </a>
            ) : (
              <span className="mt-5 text-[11px] text-zinc-400 font-mono">Available via Email</span>
            )}
          </div>

          {/* 3. Location Card */}
          <div
            data-node-id="container:contact:card:location"
            className="glass-panel p-6 sm:p-7 rounded-3xl border border-white/10 hover:border-purple-500/50 transition-all flex flex-col justify-between items-center text-center group min-h-[240px]"
          >
            <div className="flex flex-col items-center w-full">
              <div className="w-12 h-12 rounded-2xl bg-purple-600/30 flex items-center justify-center text-purple-300 group-hover:bg-purple-600 group-hover:text-white transition-colors mb-4 shadow-lg shadow-purple-900/30">
                <MapPin className="w-5 h-5" />
              </div>
              <div className="text-[10px] sm:text-[11px] font-mono text-purple-300/90 uppercase tracking-wider font-semibold mb-1">
                Location / Base
              </div>
              <div 
                data-cv="contact.location"
                data-node-id="text:contact:location"
                className="text-sm sm:text-base font-bold text-white leading-snug"
              >
                {location}
              </div>
            </div>

            <div className="mt-5 inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-purple-950/60 text-purple-300 border border-purple-500/20 text-[11px] font-mono">
              <span>Open for Travel & Remote</span>
            </div>
          </div>

        </div>

        {/* Direct Inquiries Banner */}
        <div 
          data-node-id="container:contact:banner"
          className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-purple-950/60 via-zinc-900/80 to-purple-950/60 border border-purple-500/20 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left"
        >
          <div className="space-y-1">
            <div className="flex items-center justify-center sm:justify-start gap-2 text-purple-300 text-xs font-mono font-semibold uppercase">
              <Camera className="w-3.5 h-3.5" />
              <span>Direct Studio Inquiries</span>
            </div>
            <p className="text-xs sm:text-sm text-zinc-300">
              For project inquiries, bookings, or editorial commissions, please reach out directly via email or phone.
            </p>
          </div>

          <a
            href={`mailto:${email}`}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs sm:text-sm shadow-xl shadow-purple-600/30 transition-all shrink-0 cursor-pointer"
          >
            <span>Send Direct Email</span>
            <ArrowUpRight className="w-4 h-4" />
          </a>
        </div>

      </div>
    </section>
  );
}
