import React from 'react';
import { Camera, Sparkles, Award, MapPin, CheckCircle2, Heart } from 'lucide-react';
import { photographyProfile } from '../data/photographyDefaults.js';

const _default = photographyProfile || {};

export default function About({ data = {} }) {
  const name = 
    data?.contentOverrides?.['text:about:name']?.value ||
    (typeof data?.contentOverrides?.['text:about:name'] === 'string' ? data?.contentOverrides?.['text:about:name'] : null) ||
    data?.hero?.name || data?.name || data?.fullName || _default.name || 'Elena Vance';

  const role = 
    data?.contentOverrides?.['text:about:role']?.value ||
    (typeof data?.contentOverrides?.['text:about:role'] === 'string' ? data?.contentOverrides?.['text:about:role'] : null) ||
    data?.hero?.role || data?.role || data?.title || _default.title || 'Visual Storyteller';
  
  const bioHeadline = 
    data?.contentOverrides?.['text:about:headline']?.value ||
    (typeof data?.contentOverrides?.['text:about:headline'] === 'string' ? data?.contentOverrides?.['text:about:headline'] : null) ||
    data?.about?.headline || data?.bioHeadline || _default.bioHeadline || 'Photography captures emotions beyond beautiful pictures. Whether editorial, campus moments, portraits, or fashion brands, I focus on genuine narratives reflecting true personality.';
  
  const p1 = 
    data?.contentOverrides?.['text:about:p1']?.value ||
    (typeof data?.contentOverrides?.['text:about:p1'] === 'string' ? data?.contentOverrides?.['text:about:p1'] : null) ||
    data?.about?.paragraph1 || data?.bioParagraph1 || _default.bioParagraph1 || 'As a senior Fine Arts Photography student at NYU Tisch, my work bridges the raw grit of 35mm film grain with the precision of contemporary digital medium format strobes.';
  
  const p2 = 
    data?.contentOverrides?.['text:about:p2']?.value ||
    (typeof data?.contentOverrides?.['text:about:p2'] === 'string' ? data?.contentOverrides?.['text:about:p2'] : null) ||
    data?.about?.paragraph2 || data?.bioParagraph2 || _default.bioParagraph2 || 'Selected for the Annual Student Salon and recipient of the Silver Key for Visual Arts, I collaborate with indie fashion designers, university theater productions, and student publications.';

  const rawStats = Array.isArray(data?.stats) && data.stats.length > 0 ? data.stats : (_default.stats || []);
  const stats = rawStats.map((st, idx) => {
    const valKey = `text:about:stat:${idx}:value`;
    const lblKey = `text:about:stat:${idx}:label`;
    const subKey = `text:about:stat:${idx}:subtext`;
    return {
      value: data?.contentOverrides?.[valKey]?.value || (typeof data?.contentOverrides?.[valKey] === 'string' ? data?.contentOverrides?.[valKey] : null) || st.value,
      label: data?.contentOverrides?.[lblKey]?.value || (typeof data?.contentOverrides?.[lblKey] === 'string' ? data?.contentOverrides?.[lblKey] : null) || st.label,
      subtext: data?.contentOverrides?.[subKey]?.value || (typeof data?.contentOverrides?.[subKey] === 'string' ? data?.contentOverrides?.[subKey] : null) || st.subtext,
      valKey,
      lblKey,
      subKey
    };
  });

  const aboutImage = 
    data?.contentOverrides?.['image:about:photo:0']?.src ||
    (typeof data?.contentOverrides?.['image:about:photo:0'] === 'string' ? data?.contentOverrides?.['image:about:photo:0'] : null) ||
    data?.contentOverrides?.['image:about:root:img:0']?.src ||
    (typeof data?.contentOverrides?.['image:about:root:img:0'] === 'string' ? data?.contentOverrides?.['image:about:root:img:0'] : null) ||
    data?.imageOverrides?.['about.image'] ||
    data?.imageOverrides?.['aboutImage'] ||
    data?.about?.image ||
    data?.aboutImage ||
    'https://images.unsplash.com/photo-1554080353-a576cf803bda?auto=format&fit=crop&w=1000&q=80';

  const awardTitle = 
    data?.contentOverrides?.['text:about:award:title']?.value ||
    (typeof data?.contentOverrides?.['text:about:award:title'] === 'string' ? data?.contentOverrides?.['text:about:award:title'] : null) ||
    'Fine Arts Senior Exhibition';

  const awardDesc = 
    data?.contentOverrides?.['text:about:award:desc']?.value ||
    (typeof data?.contentOverrides?.['text:about:award:desc'] === 'string' ? data?.contentOverrides?.['text:about:award:desc'] : null) ||
    'Recipient of Tisch Artistic Excellence & National Scholastic Silver Key.';

  return (
    <section 
      id="about" 
      data-cv-section="about"
      data-node-id="section:about:root:section:0"
      className="py-16 sm:py-24 bg-[#0b0713] text-white relative"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Stats Highlight Bar */}
        <div className="hero-stats-grid grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 mb-16 sm:mb-24">
          {stats.map((st, idx) => (
            <div
              key={idx}
              className="glass-panel p-4 sm:p-6 rounded-3xl border border-white/10 hover:border-purple-500/30 transition-colors text-center sm:text-left pointer-events-auto"
            >
              <div 
                data-node-id={st.valKey}
                data-node-type="text"
                className="text-2xl sm:text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-purple-300 via-white to-purple-200 cursor-text pointer-events-auto"
              >
                {st.value}
              </div>
              <div 
                data-node-id={st.lblKey}
                data-node-type="text"
                className="text-xs sm:text-sm font-semibold text-white mt-1 cursor-text pointer-events-auto"
              >
                {st.label}
              </div>
              {st.subtext && (
                <div 
                  data-node-id={st.subKey}
                  data-node-type="text"
                  className="text-[10px] sm:text-xs text-zinc-400 font-mono mt-0.5 cursor-text pointer-events-auto"
                >
                  {st.subtext}
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Main About Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 sm:gap-12 items-center">
          
          {/* Left Column: Portrait & Studio Card */}
          <div className="lg:col-span-5 relative">
            <div className="relative aspect-[3/4] w-full max-w-md mx-auto rounded-3xl overflow-hidden border border-white/15 shadow-2xl">
              <img
                src={aboutImage}
                data-node-id="image:about:photo:0"
                data-node-type="image"
                data-cv="about.image"
                alt="Artist in Darkroom"
                className="w-full h-full object-cover object-center cursor-pointer pointer-events-auto"
              />
              
              {/* Gradient Overlay (pointer-events-none allows clicks to hit img) */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent pointer-events-none" />
              
              {/* Overlaid Award Card */}
              <div className="absolute bottom-4 left-4 right-4 glass-panel-light p-3.5 rounded-2xl pointer-events-auto z-20">
                <div className="flex items-center gap-2 text-purple-300 text-xs font-semibold mb-1">
                  <Sparkles className="w-3.5 h-3.5 pointer-events-none" />
                  <span 
                    data-node-id="text:about:award:title"
                    data-node-type="text"
                    className="cursor-text pointer-events-auto"
                  >
                    {awardTitle}
                  </span>
                </div>
                <p 
                  data-node-id="text:about:award:desc"
                  data-node-type="text"
                  className="text-[11px] text-zinc-200 cursor-text pointer-events-auto"
                >
                  {awardDesc}
                </p>
              </div>
            </div>
          </div>

          {/* Right Column: Bio Content */}
          <div className="lg:col-span-7 space-y-5 sm:space-y-6">
            
            <div className="inline-flex items-center gap-2 text-xs font-mono tracking-widest uppercase text-purple-400 font-semibold">
              <Camera className="w-3.5 h-3.5" />
              <span>THE ARTIST & VISION</span>
            </div>

            <h2 
              data-node-id="text:about:headline"
              data-node-type="text"
              data-cv="about.headline"
              className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight leading-tight cursor-text pointer-events-auto"
            >
              {bioHeadline}
            </h2>

            <div className="space-y-4 text-zinc-300 text-sm sm:text-base leading-relaxed">
              <p 
                data-node-id="text:about:p1"
                data-node-type="text"
                data-cv="about.paragraph1"
                className="cursor-text pointer-events-auto"
              >
                {p1}
              </p>
              <p 
                data-node-id="text:about:p2"
                data-node-type="text"
                data-cv="about.paragraph2"
                className="cursor-text pointer-events-auto"
              >
                {p2}
              </p>
            </div>

            {/* Core Values / Style Badges */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              <div className="flex items-center gap-2.5 p-3 rounded-2xl bg-zinc-900/60 border border-white/5">
                <CheckCircle2 className="w-4 h-4 text-purple-400 shrink-0" />
                <span className="text-xs sm:text-sm font-medium text-zinc-200">Natural & Strobe Lighting Mastery</span>
              </div>
              <div className="flex items-center gap-2.5 p-3 rounded-2xl bg-zinc-900/60 border border-white/5">
                <CheckCircle2 className="w-4 h-4 text-purple-400 shrink-0" />
                <span className="text-xs sm:text-sm font-medium text-zinc-200">35mm & 120 Analog Film Chemistry</span>
              </div>
              <div className="flex items-center gap-2.5 p-3 rounded-2xl bg-zinc-900/60 border border-white/5">
                <CheckCircle2 className="w-4 h-4 text-purple-400 shrink-0" />
                <span className="text-xs sm:text-sm font-medium text-zinc-200">Editorial Casting & Art Direction</span>
              </div>
              <div className="flex items-center gap-2.5 p-3 rounded-2xl bg-zinc-900/60 border border-white/5">
                <CheckCircle2 className="w-4 h-4 text-purple-400 shrink-0" />
                <span className="text-xs sm:text-sm font-medium text-zinc-200">High-Resolution Master Retouching</span>
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
