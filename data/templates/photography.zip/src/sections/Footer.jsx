import React from 'react';
import { Camera, ArrowUp, Heart, Sparkles } from 'lucide-react';
import { photographyProfile } from '../data/photographyDefaults.js';

const _default = photographyProfile || {};

export default function Footer({ data = {} }) {
  const name = data?.hero?.name || data?.name || data?.fullName || _default.name || 'Elena Vance';
  const role = data?.hero?.role || data?.role || data?.title || _default.title || 'Visual Storyteller & Editorial Lens Artist';

  const scrollToTop = (e) => {
    if (e && e.preventDefault) e.preventDefault();
    try {
      if (typeof window !== 'undefined') {
        window.scrollTo({ top: 0, left: 0, behavior: 'smooth' });
        if (document.documentElement) document.documentElement.scrollTo({ top: 0, left: 0, behavior: 'smooth' });
        if (document.body) document.body.scrollTo({ top: 0, left: 0, behavior: 'smooth' });
        const topEl = document.getElementById('hero') || document.querySelector('header') || document.getElementById('template-root') || document.body;
        if (topEl && typeof topEl.scrollIntoView === 'function') {
          topEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      }
    } catch (err) {
      try { window.scrollTo(0, 0); } catch (_) {}
    }
  };

  return (
    <footer className="py-12 bg-[#06040a] border-t border-white/10 text-zinc-400 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-6">
        
        {/* Brand */}
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-xl bg-purple-600/30 flex items-center justify-center text-purple-400 border border-purple-500/30">
            <Camera className="w-4 h-4" />
          </div>
          <div>
            <span className="font-bold text-white text-sm block">{name}</span>
            <span className="text-[11px] text-zinc-500 font-mono">{role}</span>
          </div>
        </div>

        {/* Copyright */}
        <div className="text-center text-zinc-500">
          © {new Date().getFullYear()} {name}. All visual archives & original imagery protected.
        </div>

        {/* Back to top button */}
        <button
          onClick={scrollToTop}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-zinc-300 hover:text-white transition-colors border border-white/10"
        >
          <span>Back to top</span>
          <ArrowUp className="w-3.5 h-3.5 text-purple-400" />
        </button>

      </div>
    </footer>
  );
}
