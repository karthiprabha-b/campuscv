import React from 'react';
import { Award, CheckCircle2, ArrowUpRight, Calendar, ShieldCheck } from 'lucide-react';
import { photographyProfile } from '../data/photographyDefaults.js';

const _default = photographyProfile || {};

export default function Certificates({ data = {} }) {
  const rawCerts = Array.isArray(data?.certificates) && data.certificates.length > 0 
    ? data.certificates 
    : (Array.isArray(data?.certifications) && data.certifications.length > 0 ? data.certifications : (_default.certificates || []));

  const certificates = rawCerts.map((cert, idx) => {
    const id = cert?.id || `cert-${idx + 1}`;
    const titleKey = `text:certificates:card:${id}:title`;
    const issuerKey = `text:certificates:card:${id}:issuer`;
    const dateKey = `text:certificates:card:${id}:issueDate`;
    const descKey = `text:certificates:card:${id}:description`;

    return {
      id,
      title: data?.contentOverrides?.[titleKey]?.value || (typeof data?.contentOverrides?.[titleKey] === 'string' ? data?.contentOverrides?.[titleKey] : null) || cert?.title || cert?.name || 'Photography Certification',
      issuer: data?.contentOverrides?.[issuerKey]?.value || (typeof data?.contentOverrides?.[issuerKey] === 'string' ? data?.contentOverrides?.[issuerKey] : null) || cert?.issuer || cert?.authority || cert?.organization || 'Credential Authority',
      issueDate: data?.contentOverrides?.[dateKey]?.value || (typeof data?.contentOverrides?.[dateKey] === 'string' ? data?.contentOverrides?.[dateKey] : null) || cert?.issueDate || cert?.date || cert?.year || '2024',
      credentialUrl: cert?.credentialUrl || cert?.url || cert?.link || '#',
      description: data?.contentOverrides?.[descKey]?.value || (typeof data?.contentOverrides?.[descKey] === 'string' ? data?.contentOverrides?.[descKey] : null) || cert?.description || cert?.desc || 'Validated proficiency in creative image composition and production.',
      titleKey,
      issuerKey,
      dateKey,
      descKey
    };
  });

  return (
    <section 
      id="certificates" 
      data-cv-section="certificates"
      data-node-id="section:certificates:root:section:0"
      className="py-16 sm:py-24 bg-[#0e0919] text-white relative"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 sm:mb-16 gap-4">
          <div>
            <div className="inline-flex items-center gap-2 text-xs font-mono tracking-widest uppercase text-purple-400 font-semibold mb-2">
              <Award className="w-3.5 h-3.5" />
              <span>HONORS & CREDENTIALS</span>
            </div>
            <h2 
              data-node-id="text:certificates:heading"
              data-node-type="text"
              className="text-2xl sm:text-4xl md:text-5xl font-extrabold text-white tracking-tight cursor-text"
            >
              Certifications & Awards
            </h2>
          </div>
        </div>

        {/* Certificates Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 sm:gap-6">
          {certificates.map((cert) => (
            <div
              key={cert.id}
              data-node-id={`item:certificates:card:${cert.id}`}
              className="glass-panel p-6 sm:p-7 rounded-3xl border border-white/10 hover:border-purple-500/40 transition-all flex flex-col justify-between space-y-4 group pointer-events-auto"
            >
              <div>
                <div className="flex items-center justify-between gap-3 mb-3">
                  <span 
                    data-node-id={cert.issuerKey}
                    data-node-type="text"
                    className="text-xs font-mono text-purple-400 bg-purple-950/80 px-2.5 py-1 rounded-full border border-purple-500/30 cursor-text"
                  >
                    {cert.issuer}
                  </span>
                  <div className="flex items-center gap-1.5 text-xs text-zinc-400 font-mono">
                    <Calendar className="w-3 h-3 pointer-events-none" />
                    <span 
                      data-node-id={cert.dateKey}
                      data-node-type="text"
                      className="cursor-text"
                    >
                      {cert.issueDate}
                    </span>
                  </div>
                </div>

                <h3 
                  data-node-id={cert.titleKey}
                  data-node-type="text"
                  className="text-base sm:text-lg font-bold text-white group-hover:text-purple-300 transition-colors cursor-text"
                >
                  {cert.title}
                </h3>
                <p 
                  data-node-id={cert.descKey}
                  data-node-type="text"
                  className="text-xs sm:text-sm text-zinc-300 mt-2 leading-relaxed cursor-text"
                >
                  {cert.description}
                </p>
              </div>

              {cert.credentialUrl && cert.credentialUrl !== '#' && (
                <a
                  href={cert.credentialUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-purple-400 hover:text-purple-300 transition-colors self-start pt-2 pointer-events-auto"
                >
                  <span>Verify Credential</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </a>
              )}
            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
