"use client";

import React from "react";
import { usePortfolio } from "@/context/PortfolioContext";
import { Award, CheckCircle, ExternalLink, ShieldCheck } from "lucide-react";

export const Certificates: React.FC = () => {
  const { data } = usePortfolio();

  return (
    <section id="certificates" className="py-24 bg-[#0e0919] text-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="mb-16">
          <div className="inline-flex items-center gap-2 text-xs font-mono tracking-widest uppercase text-purple-400 font-semibold mb-2">
            <Award className="w-3.5 h-3.5" />
            <span>CREDENTIALS & INDUSTRY ACCREDITATIONS</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight">
            Certifications & Awards
          </h2>
        </div>

        {/* Certificates Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {data.certificates.map((cert) => (
            <div
              key={cert.id}
              className="glass-panel p-6 sm:p-8 rounded-3xl border border-white/10 hover:border-purple-500/40 transition-all duration-300 flex flex-col justify-between group"
            >
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-xs font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-3 py-1 rounded-full">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>Verified Credential</span>
                  </div>

                  <span className="text-xs font-mono text-zinc-400">
                    {cert.issueDate}
                  </span>
                </div>

                <h3 className="text-xl font-bold text-white group-hover:text-purple-300 transition-colors">
                  {cert.title}
                </h3>

                <div className="text-xs font-mono text-purple-300 font-semibold uppercase tracking-wider">
                  Issuer: {cert.issuer}
                </div>

                <p className="text-xs sm:text-sm text-zinc-300 leading-relaxed">
                  {cert.description}
                </p>
              </div>

              {cert.credentialUrl && (
                <div className="mt-6 pt-4 border-t border-white/10 flex items-center justify-between">
                  <a
                    href={cert.credentialUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1.5 text-xs text-purple-300 hover:text-white font-mono transition-colors group/link"
                  >
                    <span>Verify Credential on Issuer Portal</span>
                    <ExternalLink className="w-3.5 h-3.5 group-hover/link:translate-x-0.5 group-hover/link:-translate-y-0.5 transition-transform" />
                  </a>
                </div>
              )}
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
