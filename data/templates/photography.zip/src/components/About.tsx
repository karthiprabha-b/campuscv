"use client";

import React from "react";
import Image from "next/image";
import { usePortfolio } from "@/context/PortfolioContext";
import { ArrowUpRight } from "lucide-react";

export const About: React.FC = () => {
  const { data } = usePortfolio();

  const statCards = [
    {
      value: data.stats[0]?.value || "4+",
      label: data.stats[0]?.label || "Years Experience",
      subtext: data.stats[0]?.subtext || "Fine Art & Editorial",
      image: "https://images.unsplash.com/photo-1518895949257-7621c3c786d7?auto=format&fit=crop&w=600&q=80",
      accent: "from-rose-600/70 to-purple-900/80"
    },
    {
      value: data.stats[1]?.value || "140+",
      label: data.stats[1]?.label || "Shoots Completed",
      subtext: data.stats[1]?.subtext || "Campus, Fashion & Runway",
      image: "https://images.unsplash.com/photo-1511556532299-8f662fc26c06?auto=format&fit=crop&w=600&q=80",
      accent: "from-amber-600/70 to-indigo-900/80"
    },
    {
      value: data.stats[2]?.value || "7",
      label: data.stats[2]?.label || "Exhibitions & Awards",
      subtext: data.stats[2]?.subtext || "NYU Salon & Scholastic",
      image: "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=600&q=80",
      accent: "from-teal-600/70 to-purple-900/80"
    }
  ];

  return (
    <section id="about" className="py-16 sm:py-24 bg-[#0b0713] text-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top Header & Philosophy Block */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 sm:gap-8 mb-12 sm:mb-16 items-start">
          {/* Section Tag */}
          <div className="lg:col-span-3">
            <div className="inline-flex items-center gap-2 text-xs font-mono tracking-widest uppercase text-purple-400 font-semibold">
              <span className="w-2 h-2 rounded-full bg-purple-500" />
              <span>ABOUT THE ARTIST</span>
            </div>
          </div>

          {/* Philosophy Statement & Bio Lead */}
          <div className="lg:col-span-9 space-y-4 sm:space-y-6">
            <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold tracking-tight text-white leading-tight">
              {data.bioHeadline}
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6 text-zinc-300 text-sm sm:text-base leading-relaxed">
              <p>{data.bioParagraph1}</p>
              <p>{data.bioParagraph2}</p>
            </div>

            {/* Quick Action Pill */}
            <div className="pt-2">
              <a
                href="#education"
                className="inline-flex items-center gap-2 px-4 sm:px-5 py-2 sm:py-2.5 rounded-full bg-zinc-900 border border-white/20 text-white font-medium text-xs hover:bg-zinc-800 transition-colors group"
              >
                <span>Explore Academic & Studio Background</span>
                <ArrowUpRight className="w-3.5 h-3.5 text-purple-400 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
              </a>
            </div>
          </div>
        </div>

        {/* 3 Metric Image Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 pt-2 sm:pt-4">
          {statCards.map((card, idx) => (
            <div
              key={idx}
              className={`relative h-64 sm:h-72 lg:h-80 rounded-3xl overflow-hidden border border-white/10 group shadow-xl hover:border-purple-500/40 transition-all duration-500 ${
                idx === 2 ? "sm:col-span-2 lg:col-span-1" : ""
              }`}
            >
              {/* Background Image */}
              <Image
                src={card.image}
                alt={card.label}
                fill
                className="object-cover group-hover:scale-110 transition-transform duration-700"
              />

              {/* Gradient Scrim */}
              <div className={`absolute inset-0 bg-gradient-to-t ${card.accent} opacity-75 group-hover:opacity-65 transition-opacity`} />
              <div className="absolute inset-0 bg-black/30" />

              {/* Card Content at bottom */}
              <div className="absolute inset-0 p-5 sm:p-6 flex flex-col justify-end text-center items-center z-10">
                <span className="text-3xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight drop-shadow-md">
                  {card.value}
                </span>
                <span className="text-sm sm:text-base font-semibold text-white/95 mt-1">
                  {card.label}
                </span>
                <span className="text-[11px] sm:text-xs text-purple-200/90 font-mono mt-0.5">
                  {card.subtext}
                </span>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
