"use client";

import React, { useState } from "react";
import Image from "next/image";
import { usePortfolio } from "@/context/PortfolioContext";
import { ProjectItem } from "@/types/portfolio";
import {
  Camera,
  SlidersHorizontal,
  X,
  Layers,
  ArrowRight
} from "lucide-react";

export const Projects: React.FC = () => {
  const { data } = usePortfolio();
  const [activeCategory, setActiveCategory] = useState<string>("All");
  const [selectedProject, setSelectedProject] = useState<ProjectItem | null>(null);
  const [sliderPosition, setSliderPosition] = useState<number>(50);
  const [compareMode, setCompareMode] = useState<boolean>(false);

  const categories = ["All", "Editorial", "Wedding", "Portrait", "Film 35mm", "Commercial"];

  const filteredProjects = activeCategory === "All"
    ? data.projects
    : data.projects.filter((p) => p.category === activeCategory);

  return (
    <section id="portfolio" className="py-16 sm:py-24 bg-[#0e0919] text-white relative">
      {/* Background Subtle Gradient */}
      <div className="absolute top-0 right-1/4 w-72 sm:w-96 h-72 sm:h-96 bg-purple-900/15 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 sm:mb-12 gap-5 sm:gap-6">
          <div>
            <div className="inline-flex items-center gap-2 text-xs font-mono tracking-widest uppercase text-purple-400 font-semibold mb-2">
              <Camera className="w-3.5 h-3.5" />
              <span>FEATURED CURATED PORTFOLIO</span>
            </div>
            <h2 className="text-2xl sm:text-4xl md:text-5xl font-extrabold text-white tracking-tight">
              Visual Archives & Series
            </h2>
          </div>

          {/* Category Filter Tabs (Scrollable on small screens) */}
          <div className="flex items-center gap-1.5 sm:gap-2 bg-zinc-950/80 p-1.5 rounded-full border border-white/10 overflow-x-auto no-scrollbar max-w-full">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-3.5 sm:px-4 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-all cursor-pointer shrink-0 ${
                  activeCategory === cat
                    ? "bg-purple-600 text-white shadow-lg shadow-purple-500/30"
                    : "text-zinc-400 hover:text-white hover:bg-zinc-900"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 sm:gap-6">
          {filteredProjects.map((project) => (
            <div
              key={project.id}
              onClick={() => {
                setSelectedProject(project);
                setCompareMode(false);
              }}
              className="group relative rounded-3xl overflow-hidden bg-zinc-900 border border-white/10 hover:border-purple-500/50 transition-all duration-500 cursor-pointer shadow-xl flex flex-col justify-between"
            >
              {/* Image Container */}
              <div className="relative aspect-[4/5] w-full overflow-hidden">
                <Image
                  src={project.imageUrl}
                  alt={project.title}
                  fill
                  className="object-cover group-hover:scale-105 transition-transform duration-700"
                />

                {/* Dark Gradient Scrim */}
                <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/20 to-transparent opacity-80 group-hover:opacity-90 transition-opacity" />

                {/* Top Category Badge */}
                <div className="absolute top-3.5 left-3.5 sm:top-4 sm:left-4 glass-pill px-2.5 sm:px-3 py-1 rounded-full text-[10px] sm:text-[11px] font-mono font-medium text-white flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-purple-400" />
                  <span>{project.category}</span>
                </div>

                {/* Top Right Year */}
                <div className="absolute top-3.5 right-3.5 sm:top-4 sm:right-4 bg-black/60 backdrop-blur-md px-2 sm:px-2.5 py-0.5 sm:py-1 rounded-full text-[9px] sm:text-[10px] font-mono text-zinc-300">
                  {project.year}
                </div>

                {/* Bottom Information on Card */}
                <div className="absolute bottom-0 left-0 right-0 p-5 sm:p-6 space-y-1.5 sm:space-y-2">
                  <h3 className="text-base sm:text-lg font-bold text-white group-hover:text-purple-300 transition-colors leading-snug">
                    {project.title}
                  </h3>
                  <p className="text-xs text-zinc-300 line-clamp-2">
                    {project.description}
                  </p>

                  {/* EXIF Mini Pill */}
                  <div className="pt-2 flex items-center justify-between text-[10px] sm:text-[11px] font-mono text-purple-200/80 border-t border-white/10 mt-2 sm:mt-3">
                    <span className="flex items-center gap-1">
                      <Camera className="w-3 h-3 text-purple-400" />
                      {project.exif.camera}
                    </span>
                    <span className="flex items-center gap-1 text-white font-medium group-hover:translate-x-1 transition-transform">
                      <span>View EXIF</span>
                      <ArrowRight className="w-3 h-3" />
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Lightbox / EXIF Modal */}
        {selectedProject && (
          <div
            className="fixed inset-0 z-50 bg-black/90 backdrop-blur-2xl flex items-center justify-center p-3 sm:p-6 animate-in fade-in"
            onClick={() => setSelectedProject(null)}
          >
            <div
              className="relative max-w-5xl w-full max-h-[92vh] overflow-y-auto bg-zinc-950 border border-white/15 rounded-3xl shadow-2xl flex flex-col lg:flex-row"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Close Button */}
              <button
                onClick={() => setSelectedProject(null)}
                className="absolute top-3 right-3 sm:top-4 sm:right-4 z-20 p-2 rounded-full bg-black/70 text-white hover:bg-white hover:text-black transition-colors cursor-pointer"
                aria-label="Close modal"
              >
                <X className="w-5 h-5" />
              </button>

              {/* Left Side: Photo Display */}
              <div className="lg:w-7/12 relative aspect-[4/5] sm:aspect-square lg:aspect-auto bg-black flex items-center justify-center overflow-hidden min-h-[300px] sm:min-h-[420px] lg:min-h-[520px]">
                {compareMode && selectedProject.beforeImageUrl ? (
                  <div className="relative w-full h-full select-none">
                    {/* Before Image */}
                    <Image
                      src={selectedProject.beforeImageUrl}
                      alt="Raw Before"
                      fill
                      className="object-cover"
                    />
                    {/* After Image */}
                    <div
                      className="absolute inset-0 overflow-hidden"
                      style={{ clipPath: `inset(0 0 0 ${sliderPosition}%)` }}
                    >
                      <Image
                        src={selectedProject.imageUrl}
                        alt="Graded After"
                        fill
                        className="object-cover"
                      />
                    </div>
                    {/* Slider Line */}
                    <div
                      className="absolute top-0 bottom-0 w-0.5 bg-white shadow-2xl cursor-ew-resize z-10"
                      style={{ left: `${sliderPosition}%` }}
                    >
                      <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-white text-black text-[11px] sm:text-xs font-bold flex items-center justify-center shadow-lg">
                        ↔
                      </div>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={sliderPosition}
                      onChange={(e) => setSliderPosition(Number(e.target.value))}
                      className="absolute inset-0 opacity-0 cursor-ew-resize w-full h-full z-20"
                    />
                    <span className="absolute top-3 left-3 bg-black/70 px-2 py-0.5 rounded text-[9px] sm:text-[10px] font-mono text-zinc-300">
                      RAW UNGRADED
                    </span>
                    <span className="absolute top-3 right-12 sm:right-14 bg-purple-900/80 px-2 py-0.5 rounded text-[9px] sm:text-[10px] font-mono text-purple-200">
                      COLOR GRADED
                    </span>
                  </div>
                ) : (
                  <div className="relative w-full h-full">
                    <Image
                      src={selectedProject.imageUrl}
                      alt={selectedProject.title}
                      fill
                      className="object-contain lg:object-cover"
                    />
                  </div>
                )}

                {/* Compare Mode Toggle Pill */}
                {selectedProject.beforeImageUrl && (
                  <button
                    onClick={() => setCompareMode(!compareMode)}
                    className="absolute bottom-3 left-3 sm:bottom-4 sm:left-4 z-20 flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-black/80 hover:bg-black text-white text-xs font-medium border border-white/20 backdrop-blur-md transition-all cursor-pointer"
                  >
                    <Layers className="w-3.5 h-3.5 text-purple-400" />
                    <span>{compareMode ? "Standard View" : "Compare RAW / Grade"}</span>
                  </button>
                )}
              </div>

              {/* Right Side: EXIF & Creative Story Details */}
              <div className="lg:w-5/12 p-5 sm:p-7 lg:p-8 flex flex-col justify-between space-y-5 sm:space-y-6">
                <div className="space-y-3 sm:space-y-4">
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 sm:py-1 rounded-full bg-purple-900/50 border border-purple-400/30 text-purple-200 text-xs font-mono">
                      {selectedProject.category}
                    </span>
                    <span className="text-xs text-zinc-400 font-mono">
                      {selectedProject.year} • {selectedProject.client || "Self-Initiated"}
                    </span>
                  </div>

                  <h3 className="text-xl sm:text-2xl font-bold text-white leading-tight">
                    {selectedProject.title}
                  </h3>

                  <p className="text-xs sm:text-sm text-zinc-300 leading-relaxed">
                    {selectedProject.description}
                  </p>

                  {/* Tags */}
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {selectedProject.tags.map((tag, idx) => (
                      <span
                        key={idx}
                        className="text-[10px] sm:text-[11px] px-2 sm:px-2.5 py-0.5 rounded-md bg-zinc-900 text-zinc-400 border border-white/10"
                      >
                        #{tag}
                      </span>
                    ))}
                  </div>

                  {/* EXIF Data Grid Deck */}
                  <div className="bg-zinc-900/90 rounded-2xl p-3.5 sm:p-4 border border-white/10 space-y-2.5 sm:space-y-3">
                    <div className="flex items-center gap-2 text-xs font-mono font-semibold text-purple-300 uppercase tracking-wider">
                      <SlidersHorizontal className="w-3.5 h-3.5" />
                      <span>Camera & EXIF Metadata</span>
                    </div>

                    <div className="grid grid-cols-2 gap-2 sm:gap-3 text-xs font-mono">
                      <div className="bg-black/50 p-2 sm:p-2.5 rounded-xl border border-white/5">
                        <span className="text-[9px] sm:text-[10px] text-zinc-500 block uppercase">Body</span>
                        <span className="text-white font-medium text-[11px] sm:text-xs truncate block">{selectedProject.exif.camera}</span>
                      </div>
                      <div className="bg-black/50 p-2 sm:p-2.5 rounded-xl border border-white/5">
                        <span className="text-[9px] sm:text-[10px] text-zinc-500 block uppercase">Lens</span>
                        <span className="text-white font-medium text-[11px] sm:text-xs truncate block">{selectedProject.exif.lens}</span>
                      </div>
                      <div className="bg-black/50 p-2 sm:p-2.5 rounded-xl border border-white/5">
                        <span className="text-[9px] sm:text-[10px] text-zinc-500 block uppercase">Aperture</span>
                        <span className="text-purple-300 font-semibold">{selectedProject.exif.aperture}</span>
                      </div>
                      <div className="bg-black/50 p-2 sm:p-2.5 rounded-xl border border-white/5">
                        <span className="text-[9px] sm:text-[10px] text-zinc-500 block uppercase">Shutter</span>
                        <span className="text-purple-300 font-semibold">{selectedProject.exif.shutterSpeed}</span>
                      </div>
                      <div className="bg-black/50 p-2 sm:p-2.5 rounded-xl border border-white/5">
                        <span className="text-[9px] sm:text-[10px] text-zinc-500 block uppercase">ISO</span>
                        <span className="text-purple-300 font-semibold">{selectedProject.exif.iso}</span>
                      </div>
                      <div className="bg-black/50 p-2 sm:p-2.5 rounded-xl border border-white/5">
                        <span className="text-[9px] sm:text-[10px] text-zinc-500 block uppercase">Focal Length</span>
                        <span className="text-purple-300 font-semibold">{selectedProject.exif.focalLength}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Footer Action */}
                <div className="pt-3 sm:pt-4 border-t border-white/10 flex items-center justify-between">
                  <span className="text-[11px] sm:text-xs font-mono text-zinc-400">Senior Portfolio</span>
                  <a
                    href="#contact"
                    onClick={() => setSelectedProject(null)}
                    className="px-3.5 sm:px-4 py-1.5 sm:py-2 rounded-full bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold transition-colors"
                  >
                    Inquire Similar Shoot
                  </a>
                </div>
              </div>
            </div>
          </div>
        )}

      </div>
    </section>
  );
};
