"use client";

import React, { useState } from "react";
import Image from "next/image";
import { usePortfolio } from "@/context/PortfolioContext";
import { Mail, Phone, MapPin, Sparkles, ArrowUpRight, Copy, Check } from "lucide-react";

export const Contact: React.FC = () => {
  const { data } = usePortfolio();
  const [copied, setCopied] = useState(false);

  const handleCopyEmail = () => {
    navigator.clipboard.writeText(data.email);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <section id="contact" className="relative py-16 sm:py-24 md:py-28 flex items-center justify-center overflow-hidden bg-zinc-950">
      {/* Cinematic Background Atmosphere Image */}
      <div className="absolute inset-0 z-0">
        <Image
          src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=1600&q=80"
          alt="Cinematic Portrait Backdrop"
          fill
          className="object-cover object-center opacity-25"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0b0713] via-[#100722]/85 to-[#0b0713]" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full">
        <div className="max-w-4xl mx-auto text-center space-y-6 sm:space-y-8">
          
          {/* Tag */}
          <div className="inline-flex items-center gap-2 text-xs font-mono tracking-widest uppercase text-purple-400 font-semibold px-3.5 sm:px-4 py-1.5 rounded-full bg-white/5 border border-white/10 backdrop-blur-md">
            <Sparkles className="w-3.5 h-3.5 text-purple-400" />
            <span>LET&apos;S CONNECT & COLLABORATE</span>
          </div>

          {/* Big Editorial Invitation */}
          <h2 className="text-3xl sm:text-5xl md:text-6xl font-extrabold text-white tracking-tight leading-[1.1] font-sans">
            Let&apos;s Create Something Beautiful Together
          </h2>

          <p className="text-sm sm:text-base md:text-lg text-zinc-300 leading-relaxed max-w-2xl mx-auto">
            Creating timeless photography that celebrates genuine emotions, meaningful connections, and unforgettable stories across campus, fashion lookbooks, and editorial commissions.
          </p>

          {/* Direct Contact Cards Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5 pt-4 sm:pt-6">
            
            {/* Email Card */}
            <div className="glass-panel p-5 sm:p-6 rounded-3xl border border-white/10 hover:border-purple-500/40 transition-all text-left flex flex-col justify-between group">
              <div className="space-y-2">
                <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-2xl bg-purple-950/80 border border-purple-500/30 flex items-center justify-center text-purple-300">
                  <Mail className="w-4 h-4 sm:w-5 sm:h-5" />
                </div>
                <span className="text-[11px] sm:text-xs font-mono text-zinc-400 uppercase tracking-wider block">
                  Direct Email
                </span>
                <span className="text-xs sm:text-sm font-semibold text-white block break-all font-mono">
                  {data.email}
                </span>
              </div>

              <div className="pt-4 mt-4 border-t border-white/10 flex items-center gap-2">
                <button
                  onClick={handleCopyEmail}
                  className="flex-1 inline-flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-medium transition-colors cursor-pointer"
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="text-emerald-300">Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5 text-zinc-400" />
                      <span>Copy Email</span>
                    </>
                  )}
                </button>

                <a
                  href={`mailto:${data.email}`}
                  className="p-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white transition-colors"
                  title="Open Mail"
                >
                  <ArrowUpRight className="w-4 h-4" />
                </a>
              </div>
            </div>

            {/* Studio / Phone Card */}
            <div className="glass-panel p-5 sm:p-6 rounded-3xl border border-white/10 hover:border-purple-500/40 transition-all text-left flex flex-col justify-between group">
              <div className="space-y-2">
                <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-2xl bg-purple-950/80 border border-purple-500/30 flex items-center justify-center text-purple-300">
                  <Phone className="w-4 h-4 sm:w-5 sm:h-5" />
                </div>
                <span className="text-[11px] sm:text-xs font-mono text-zinc-400 uppercase tracking-wider block">
                  Phone & Studio Line
                </span>
                <span className="text-xs sm:text-sm font-semibold text-white block font-mono">
                  {data.phone}
                </span>
              </div>

              <div className="pt-4 mt-4 border-t border-white/10">
                <span className="text-xs text-zinc-400 font-mono">
                  Mon – Sat • 9am – 7pm EST
                </span>
              </div>
            </div>

            {/* Location / Campus Card */}
            <div className="glass-panel p-5 sm:p-6 rounded-3xl border border-white/10 hover:border-purple-500/40 transition-all text-left flex flex-col justify-between group sm:col-span-2 lg:col-span-1">
              <div className="space-y-2">
                <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-2xl bg-purple-950/80 border border-purple-500/30 flex items-center justify-center text-purple-300">
                  <MapPin className="w-4 h-4 sm:w-5 sm:h-5" />
                </div>
                <span className="text-[11px] sm:text-xs font-mono text-zinc-400 uppercase tracking-wider block">
                  Location & Base
                </span>
                <span className="text-xs sm:text-sm font-semibold text-white block">
                  {data.location}
                </span>
              </div>

              <div className="pt-4 mt-4 border-t border-white/10">
                <span className="text-xs text-purple-300 font-mono">
                  {data.campusName}
                </span>
              </div>
            </div>

          </div>

          {/* Direct CTA Action */}
          <div className="pt-4 sm:pt-6 flex flex-col sm:flex-row items-center justify-center gap-3 sm:gap-4 w-full">
            <a
              href={`mailto:${data.email}?subject=Photography%20Shoot%20Inquiry%20-%20Elena%20Vance`}
              className="inline-flex items-center justify-center gap-2 px-6 sm:px-8 py-3.5 sm:py-4 rounded-full bg-gradient-to-r from-purple-600 to-fuchsia-600 hover:from-purple-500 hover:to-fuchsia-500 text-white font-bold text-xs sm:text-sm shadow-xl shadow-purple-600/30 transition-all hover:scale-105 cursor-pointer group w-full sm:w-auto"
            >
              <Mail className="w-4 h-4" />
              <span>Email Direct Booking Request</span>
              <ArrowUpRight className="w-4 h-4 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
            </a>

            <a
              href={data.instagram}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center justify-center gap-2 px-5 sm:px-6 py-3.5 sm:py-4 rounded-full bg-zinc-900/90 hover:bg-zinc-800 text-zinc-200 border border-white/10 text-xs sm:text-sm font-semibold transition-colors w-full sm:w-auto"
            >
              <span>View Instagram Feed</span>
              <ArrowUpRight className="w-4 h-4 text-purple-400" />
            </a>
          </div>

        </div>
      </div>
    </section>
  );
};
