"use client";

import React from "react";
import Image from "next/image";
import { usePortfolio } from "@/context/PortfolioContext";
import { ArrowUpRight, Sparkles, Camera, Layers } from "lucide-react";

export const Hero: React.FC = () => {
  const { data } = usePortfolio();

  return (
    <section className="relative min-h-[95vh] flex flex-col justify-between pt-24 sm:pt-28 md:pt-32 pb-8 sm:pb-12 overflow-hidden bg-gradient-to-b from-[#4c1d95] via-[#24104c] to-[#0b0713]">
      {/* Glowing Ambient Light Orbs */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[320px] sm:w-[500px] lg:w-[600px] h-[320px] sm:h-[500px] lg:h-[600px] bg-purple-500/25 rounded-full blur-[100px] sm:blur-[140px] pointer-events-none -z-0" />
      <div className="absolute top-10 right-10 w-[200px] sm:w-[350px] h-[200px] sm:h-[350px] bg-fuchsia-500/20 rounded-full blur-[90px] sm:blur-[120px] pointer-events-none -z-0" />

      {/* Top Content Row */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 sm:gap-12 items-center">
        
        {/* Left Column: Headline & Bio Tagline */}
        <div className="lg:col-span-6 space-y-4 sm:space-y-6 text-center lg:text-left flex flex-col items-center lg:items-start">
          {/* Status Badge */}
          <div className="inline-flex items-center gap-2 px-3 sm:px-3.5 py-1.5 rounded-full bg-white/10 border border-white/20 backdrop-blur-md text-purple-200 text-[11px] sm:text-xs font-medium tracking-wide">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            <span className="w-2 h-2 rounded-full bg-emerald-400 -ml-3.5" />
            <span>{data.heroBadge}</span>
          </div>

          {/* Main Hero Headline */}
          <h1 className="text-3xl sm:text-5xl md:text-6xl xl:text-7xl font-extrabold text-white tracking-tight leading-[1.1] sm:leading-[1.05] drop-shadow-sm font-sans max-w-2xl">
            {data.heroHeadline}
          </h1>

          {/* Subheadline / Student Philosophy */}
          <p className="text-sm sm:text-base md:text-lg text-purple-100/80 max-w-xl font-normal leading-relaxed">
            {data.heroSubheadline}
          </p>

          {/* Action CTAs */}
          <div className="flex flex-wrap items-center justify-center lg:justify-start gap-3 sm:gap-4 pt-2 w-full sm:w-auto">
            <a
              href="#portfolio"
              className="inline-flex items-center justify-center gap-2 px-5 sm:px-6 py-3 sm:py-3.5 rounded-full bg-white text-black font-semibold text-xs sm:text-sm hover:bg-purple-100 hover:shadow-xl hover:shadow-white/20 transition-all cursor-pointer group w-full sm:w-auto"
            >
              <span>View Portfolio</span>
              <ArrowUpRight className="w-4 h-4 text-black group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
            </a>

            <a
              href="#contact"
              className="inline-flex items-center justify-center gap-2 px-5 sm:px-6 py-3 sm:py-3.5 rounded-full bg-black/40 hover:bg-black/60 text-white border border-white/20 backdrop-blur-md font-semibold text-xs sm:text-sm transition-all w-full sm:w-auto"
            >
              <Sparkles className="w-4 h-4 text-purple-400" />
              <span>Contact Artist</span>
            </a>
          </div>
        </div>

        {/* Right Column: Hero Visual & Floating Badges */}
        <div className="lg:col-span-6 relative flex justify-center items-center mt-4 lg:mt-0">
          {/* Main Editorial Hero Image */}
          <div className="relative w-full max-w-[300px] sm:max-w-[380px] md:max-w-[420px] aspect-[4/5] rounded-3xl overflow-hidden border border-white/20 shadow-2xl shadow-purple-900/60 group">
            <Image
              src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=1200&q=85"
              alt="Editorial Photography Model"
              fill
              priority
              className="object-cover object-center group-hover:scale-105 transition-transform duration-700"
            />
            {/* Gradient Overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-purple-950/80 via-transparent to-transparent opacity-60" />

            {/* Floating Live Badge inside card */}
            <div className="absolute top-3 left-3 sm:top-4 sm:left-4 glass-pill px-2.5 sm:px-3 py-1 sm:py-1.5 rounded-full text-[11px] sm:text-xs font-medium text-white flex items-center gap-1.5">
              <Camera className="w-3.5 h-3.5 text-purple-300" />
              <span>Editorial & Fashion</span>
            </div>

            {/* Floating Badge 2 */}
            <div className="absolute bottom-3 right-3 sm:bottom-6 sm:right-6 glass-panel-light px-3 sm:px-4 py-2 sm:py-2.5 rounded-2xl text-[11px] sm:text-xs font-semibold text-white shadow-xl flex items-center gap-2 sm:gap-2.5 animate-float">
              <div className="w-5 h-5 sm:w-6 sm:h-6 rounded-lg overflow-hidden relative border border-white/40 shrink-0">
                <Image
                  src="https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=120&q=80"
                  alt="Wedding thumbnail"
                  fill
                  className="object-cover"
                />
              </div>
              <div>
                <span className="block text-[9px] sm:text-[10px] text-purple-200/80 uppercase tracking-wider font-mono">Specialty</span>
                <span className="text-white text-[11px] sm:text-xs font-bold">Wedding & Stories</span>
              </div>
            </div>
          </div>

          {/* Floating Accompanying Mini Badge on Left */}
          <div className="hidden md:flex absolute -bottom-4 -left-4 lg:-left-6 glass-panel border border-white/20 p-2.5 sm:p-3 rounded-2xl shadow-2xl items-center gap-2.5 sm:gap-3 animate-float [animation-delay:2s]">
            <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl bg-purple-600/30 flex items-center justify-center border border-purple-400/30 text-purple-300 shrink-0">
              <Layers className="w-4 h-4 sm:w-5 sm:h-5" />
            </div>
            <div>
              <div className="text-xs sm:text-sm font-bold text-white">35mm Analog & Strobe</div>
              <div className="text-[10px] sm:text-[11px] text-zinc-400 font-mono">Sony A7R V • Leica M6</div>
            </div>
          </div>
        </div>
      </div>

      {/* Subtle Hairline Divider */}
      <div className="w-full my-6 sm:my-8 relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="h-px bg-gradient-to-r from-transparent via-white/15 to-transparent w-full" />
      </div>

      {/* Giant Typography Background Banner ("PHOTO") */}
      <div className="w-full relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-3 sm:gap-4">
        <div className="overflow-hidden select-none w-full sm:w-auto text-center sm:text-left">
          <span className="text-6xl sm:text-8xl md:text-9xl lg:text-[140px] xl:text-[180px] font-black tracking-tighter text-white/10 uppercase leading-none block font-sans">
            PHOTO
          </span>
        </div>

        {/* Mini Quick Access Pill */}
        <div className="flex items-center gap-2 bg-black/40 backdrop-blur-md border border-white/15 px-3.5 py-1.5 rounded-full shrink-0">
          <span className="w-2 h-2 rounded-full bg-purple-400 animate-pulse" />
          <span className="text-[11px] sm:text-xs font-mono text-purple-200">
            NYU Tisch Salon ’25 Featured Artist
          </span>
        </div>
      </div>
    </section>
  );
};
