"use client";

import React from "react";
import { usePortfolio } from "@/context/PortfolioContext";
import { GraduationCap, Award, BookOpen, Calendar, MapPin } from "lucide-react";

export const Education: React.FC = () => {
  const { data } = usePortfolio();

  return (
    <section id="education" className="py-16 sm:py-24 bg-[#0b0713] text-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="mb-10 sm:mb-16">
          <div className="inline-flex items-center gap-2 text-xs font-mono tracking-widest uppercase text-purple-400 font-semibold mb-2">
            <GraduationCap className="w-3.5 h-3.5" />
            <span>ACADEMIC FOUNDATION</span>
          </div>
          <h2 className="text-2xl sm:text-4xl md:text-5xl font-extrabold text-white tracking-tight">
            Education & Honors
          </h2>
        </div>

        {/* Education Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 sm:gap-8">
          {data.education.map((edu) => (
            <div
              key={edu.id}
              className="glass-panel p-5 sm:p-7 lg:p-8 rounded-3xl border border-white/10 hover:border-purple-500/40 transition-all duration-300 relative group flex flex-col justify-between"
            >
              <div className="space-y-3.5 sm:space-y-4">
                {/* Degree & Period */}
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-900/60 border border-purple-400/30 text-purple-200 text-xs font-mono">
                    <Calendar className="w-3 h-3" />
                    {edu.period}
                  </span>

                  {edu.gpa && (
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-950/80 border border-emerald-400/30 text-emerald-300 text-xs font-mono font-medium">
                      GPA: {edu.gpa}
                    </span>
                  )}
                </div>

                <h3 className="text-lg sm:text-xl md:text-2xl font-bold text-white leading-snug">
                  {edu.degree}
                </h3>

                <div className="flex flex-wrap items-center gap-2 text-xs sm:text-sm text-purple-300 font-medium font-mono">
                  <span>{edu.institution}</span>
                  <span>•</span>
                  <span className="text-zinc-400 flex items-center gap-1">
                    <MapPin className="w-3 h-3" />
                    {edu.location}
                  </span>
                </div>

                {edu.honors && (
                  <div className="flex items-center gap-2 text-xs text-amber-300 bg-amber-950/40 border border-amber-400/20 px-3 py-1.5 rounded-xl">
                    <Award className="w-4 h-4 shrink-0" />
                    <span>{edu.honors}</span>
                  </div>
                )}

                <p className="text-xs sm:text-sm text-zinc-300 leading-relaxed">
                  {edu.description}
                </p>

                {/* Coursework Pills */}
                {edu.coursework && edu.coursework.length > 0 && (
                  <div className="pt-3 border-t border-white/10 space-y-2">
                    <div className="flex items-center gap-1.5 text-xs font-mono text-zinc-400 uppercase tracking-wider">
                      <BookOpen className="w-3 h-3 text-purple-400" />
                      <span>Key Disciplines & Coursework</span>
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {edu.coursework.map((course, idx) => (
                        <span
                          key={idx}
                          className="text-[11px] sm:text-xs px-2.5 py-1 rounded-lg bg-zinc-900/80 text-zinc-300 border border-white/5"
                        >
                          {course}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
