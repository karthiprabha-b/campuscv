"use client";

import React from "react";
import { usePortfolio } from "@/context/PortfolioContext";
import { Briefcase, Calendar, MapPin, CheckCircle2 } from "lucide-react";

export const Experience: React.FC = () => {
  const { data } = usePortfolio();

  const getBadgeColor = (type: string) => {
    switch (type) {
      case "Campus Role":
        return "bg-purple-950/80 text-purple-300 border-purple-400/30";
      case "Internship":
        return "bg-blue-950/80 text-blue-300 border-blue-400/30";
      case "Freelance":
        return "bg-emerald-950/80 text-emerald-300 border-emerald-400/30";
      default:
        return "bg-zinc-800 text-zinc-300 border-zinc-700";
    }
  };

  return (
    <section id="experience" className="py-16 sm:py-24 bg-[#0e0919] text-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="mb-10 sm:mb-16">
          <div className="inline-flex items-center gap-2 text-xs font-mono tracking-widest uppercase text-purple-400 font-semibold mb-2">
            <Briefcase className="w-3.5 h-3.5" />
            <span>INDUSTRY & CAMPUS IMPACT</span>
          </div>
          <h2 className="text-2xl sm:text-4xl md:text-5xl font-extrabold text-white tracking-tight">
            Experience & Internships
          </h2>
        </div>

        {/* Timeline / Card Grid */}
        <div className="space-y-4 sm:space-y-6">
          {data.experience.map((exp) => (
            <div
              key={exp.id}
              className="glass-panel p-5 sm:p-7 lg:p-8 rounded-3xl border border-white/10 hover:border-purple-500/40 transition-all duration-300 relative group flex flex-col md:flex-row gap-5 sm:gap-6 md:gap-8 justify-between"
            >
              {/* Left Column: Company, Role & Meta */}
              <div className="md:w-5/12 space-y-2.5 sm:space-y-3">
                <div className="flex flex-wrap items-center gap-2">
                  <span
                    className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] sm:text-[11px] font-mono border ${getBadgeColor(
                      exp.type
                    )}`}
                  >
                    {exp.type}
                  </span>

                  <span className="text-[11px] sm:text-xs text-zinc-400 font-mono flex items-center gap-1">
                    <Calendar className="w-3 h-3 text-purple-400" />
                    {exp.period}
                  </span>
                </div>

                <h3 className="text-lg sm:text-xl md:text-2xl font-bold text-white">
                  {exp.role}
                </h3>

                <div className="text-xs sm:text-sm font-semibold text-purple-300 flex flex-wrap items-center gap-1.5 sm:gap-2">
                  <span>{exp.company}</span>
                  <span className="text-zinc-600">•</span>
                  <span className="text-zinc-400 font-normal flex items-center gap-1 text-xs">
                    <MapPin className="w-3 h-3" />
                    {exp.location}
                  </span>
                </div>

                <p className="text-xs sm:text-sm text-zinc-300 pt-1 leading-relaxed">
                  {exp.description}
                </p>
              </div>

              {/* Right Column: Key Achievements / Bullet Points */}
              <div className="md:w-7/12 bg-black/40 p-4 sm:p-5 md:p-6 rounded-2xl border border-white/5 flex flex-col justify-between">
                <div className="space-y-2.5 sm:space-y-3">
                  <span className="text-[11px] sm:text-xs font-mono uppercase tracking-wider text-purple-300 font-semibold block">
                    Key Outcomes & Milestones
                  </span>
                  <ul className="space-y-2 sm:space-y-2.5">
                    {exp.highlights.map((item, hIdx) => (
                      <li key={hIdx} className="flex items-start gap-2 sm:gap-2.5 text-xs sm:text-sm text-zinc-300">
                        <CheckCircle2 className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-purple-400 shrink-0 mt-0.5" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
