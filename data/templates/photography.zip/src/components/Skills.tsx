"use client";

import React, { useState } from "react";
import { usePortfolio } from "@/context/PortfolioContext";
import { Camera, Cpu, Sparkles, CheckCircle2, Package, Film, Zap } from "lucide-react";

export const Skills: React.FC = () => {
  const { data } = usePortfolio();
  const [activeTab, setActiveTab] = useState<"skills" | "gear">("skills");

  return (
    <section id="skills" className="py-16 sm:py-24 bg-[#0b0713] text-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header with Tab Switcher */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-10 sm:mb-16 gap-5 sm:gap-6">
          <div>
            <div className="inline-flex items-center gap-2 text-xs font-mono tracking-widest uppercase text-purple-400 font-semibold mb-2">
              <Sparkles className="w-3.5 h-3.5" />
              <span>TECHNICAL MASTERY & EQUIPMENT</span>
            </div>
            <h2 className="text-2xl sm:text-4xl md:text-5xl font-extrabold text-white tracking-tight">
              Skills & Camera Rig
            </h2>
          </div>

          {/* Toggle Tab */}
          <div className="flex items-center gap-1.5 sm:gap-2 bg-zinc-950 p-1 sm:p-1.5 rounded-full border border-white/10 self-start sm:self-auto">
            <button
              onClick={() => setActiveTab("skills")}
              className={`flex items-center gap-1.5 sm:gap-2 px-3.5 sm:px-5 py-1.5 sm:py-2 rounded-full text-xs font-semibold transition-all cursor-pointer ${
                activeTab === "skills"
                  ? "bg-purple-600 text-white shadow-lg shadow-purple-500/30"
                  : "text-zinc-400 hover:text-white"
              }`}
            >
              <Cpu className="w-3.5 h-3.5" />
              <span>Software & Craft</span>
            </button>

            <button
              onClick={() => setActiveTab("gear")}
              className={`flex items-center gap-1.5 sm:gap-2 px-3.5 sm:px-5 py-1.5 sm:py-2 rounded-full text-xs font-semibold transition-all cursor-pointer ${
                activeTab === "gear"
                  ? "bg-purple-600 text-white shadow-lg shadow-purple-500/30"
                  : "text-zinc-400 hover:text-white"
              }`}
            >
              <Camera className="w-3.5 h-3.5" />
              <span>Gear & Studio Kit</span>
            </button>
          </div>
        </div>

        {/* Tab 1: Skills Breakdown */}
        {activeTab === "skills" && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 sm:gap-6 lg:gap-8">
            {data.skills.map((category, idx) => (
              <div
                key={idx}
                className={`glass-panel p-5 sm:p-7 rounded-3xl border border-white/10 flex flex-col justify-between space-y-5 hover:border-purple-500/40 transition-all duration-300 ${
                  idx === 2 ? "md:col-span-2 lg:col-span-1" : ""
                }`}
              >
                <div>
                  <div className="flex items-center gap-2 mb-4 sm:mb-6">
                    <div className="w-2 h-2 sm:w-2.5 sm:h-2.5 rounded-full bg-purple-400" />
                    <h3 className="text-base sm:text-lg font-bold text-white tracking-tight">
                      {category.name}
                    </h3>
                  </div>

                  <div className="space-y-2.5 sm:space-y-3">
                    {category.skills.map((skill, sIdx) => (
                      <div
                        key={sIdx}
                        className="flex items-center justify-between p-2.5 sm:p-3 rounded-2xl bg-zinc-900/60 border border-white/5 hover:border-white/10 transition-colors"
                      >
                        <div className="flex items-center gap-2 sm:gap-2.5">
                          <CheckCircle2 className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-purple-400 shrink-0" />
                          <span className="text-xs sm:text-sm text-zinc-200 font-medium">
                            {skill.name}
                          </span>
                        </div>
                        {skill.tag && (
                          <span className="text-[10px] sm:text-[11px] font-mono font-medium text-purple-300 bg-purple-950/80 px-2 sm:px-2.5 py-0.5 sm:py-1 rounded-full border border-purple-500/30">
                            {skill.tag}
                          </span>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Tab 2: Camera Kit & Equipment */}
        {activeTab === "gear" && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
            {data.gear.map((item) => (
              <div
                key={item.id}
                className="glass-panel p-5 sm:p-6 rounded-3xl border border-white/10 hover:border-purple-500/40 transition-all flex items-start gap-3.5 sm:gap-4 group"
              >
                <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-2xl bg-purple-950/80 border border-purple-400/30 flex items-center justify-center text-purple-300 shrink-0 group-hover:scale-105 transition-transform">
                  {item.category.includes("Camera") ? (
                    <Camera className="w-5 h-5 sm:w-6 sm:h-6" />
                  ) : item.category.includes("Lighting") ? (
                    <Zap className="w-5 h-5 sm:w-6 sm:h-6" />
                  ) : item.category.includes("Analog") ? (
                    <Film className="w-5 h-5 sm:w-6 sm:h-6" />
                  ) : (
                    <Package className="w-5 h-5 sm:w-6 sm:h-6" />
                  )}
                </div>

                <div className="space-y-0.5 sm:space-y-1">
                  <span className="text-[9px] sm:text-[10px] font-mono uppercase tracking-wider text-purple-300 block">
                    {item.category}
                  </span>
                  <h4 className="text-sm sm:text-base font-bold text-white group-hover:text-purple-200 transition-colors">
                    {item.name}
                  </h4>
                  <p className="text-xs text-zinc-400 leading-snug">
                    {item.model}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}

      </div>
    </section>
  );
};
