export interface ProjectItem {
  id: string;
  title: string;
  category: "Editorial" | "Portrait" | "Film 35mm" | "Documentary" | "Commercial" | "Wedding";
  imageUrl: string;
  beforeImageUrl?: string;
  aspectRatio?: "portrait" | "landscape" | "square";
  year: string;
  client?: string;
  description: string;
  exif: {
    camera: string;
    lens: string;
    aperture: string;
    shutterSpeed: string;
    iso: string;
    focalLength: string;
  };
  tags: string[];
}

export interface EducationItem {
  id: string;
  degree: string;
  institution: string;
  location: string;
  period: string;
  gpa?: string;
  honors?: string;
  description: string;
  coursework: string[];
}

export interface ExperienceItem {
  id: string;
  role: string;
  company: string;
  location: string;
  period: string;
  type: "Internship" | "Campus Role" | "Freelance" | "Exhibition";
  description: string;
  highlights: string[];
}

export interface SkillCategory {
  name: string;
  skills: { name: string; level: number; tag?: string }[];
}

export interface GearItem {
  id: string;
  category: "Camera Bodies" | "Lenses" | "Lighting & Modifiers" | "Analog & Darkroom" | "Tech & Accessories";
  name: string;
  model: string;
  iconType?: string;
}

export interface CertificateItem {
  id: string;
  title: string;
  issuer: string;
  issueDate: string;
  credentialUrl?: string;
  badgeImageUrl?: string;
  description: string;
}

export interface StatMetric {
  label: string;
  value: string;
  subtext?: string;
}

export interface PortfolioProfile {
  name: string;
  title: string;
  tagline: string;
  campusName: string;
  graduationYear: string;
  email: string;
  phone: string;
  location: string;
  instagram: string;
  behance: string;
  linkedin: string;
  bioHeadline: string;
  bioParagraph1: string;
  bioParagraph2: string;
  avatarUrl: string;
  heroBadge: string;
  heroHeadline: string;
  heroSubheadline: string;
  stats: StatMetric[];
  education: EducationItem[];
  experience: ExperienceItem[];
  projects: ProjectItem[];
  skills: SkillCategory[];
  gear: GearItem[];
  certificates: CertificateItem[];
}

export type ThemePalette = "violet" | "noir" | "emerald" | "terracotta";
