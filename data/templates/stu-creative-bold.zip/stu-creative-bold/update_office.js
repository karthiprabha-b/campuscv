const fs = require('fs');
const path = require('path');

const officeRoot = 'a:/Office/Portfolio site';

// 1. Update dashboard/page.tsx
const dashboardPath = path.join(officeRoot, 'src/app/dashboard/page.tsx');
if (fs.existsSync(dashboardPath)) {
  let content = fs.readFileSync(dashboardPath, 'utf8');

  // Update getPlanDiscount
  const oldGetPlanDiscount = `  const getPlanDiscount = (plan: PlanConfig) => {
    if (!appliedPlanCoupon) return { discount: 0, finalPrice: plan.price, isApplicable: false };
    const isApplicable = !appliedPlanCoupon.applicablePlanIds ||
      appliedPlanCoupon.applicablePlanIds.length === 0 ||
      appliedPlanCoupon.applicablePlanIds.includes(plan.id);

    if (!isApplicable) {
      return { discount: 0, finalPrice: plan.price, isApplicable: false };
    }

    let discount = 0;
    if (appliedPlanCoupon.discountType === 'fixed') {
      discount = Math.min(plan.price, appliedPlanCoupon.discountValue || 0);
    } else {
      const pct = appliedPlanCoupon.discountPercent ?? appliedPlanCoupon.discountValue ?? 0;
      discount = Math.round((plan.price * pct) / 100);
    }
    const finalPrice = Math.max(0, plan.price - discount);
    return { discount, finalPrice, isApplicable: true };
  };`;

  const newGetPlanDiscount = `  const getPlanDiscount = (plan: PlanConfig) => {
    if (!appliedPlanCoupon) return { discount: 0, finalPrice: plan.price, isApplicable: false };
    const isApplicable = !appliedPlanCoupon.applicablePlanIds ||
      appliedPlanCoupon.applicablePlanIds.length === 0 ||
      appliedPlanCoupon.applicablePlanIds.includes(plan.id);

    if (!isApplicable) {
      return { discount: 0, finalPrice: plan.price, isApplicable: false };
    }

    const isTrial = (plan.id || '').toLowerCase().includes('trial') || 
      (plan.id || '').toLowerCase().includes('test') || 
      (plan.name || '').toLowerCase().includes('trial') || 
      (plan.tier || '').toLowerCase() === 'trial';

    let discount = 0;
    if (appliedPlanCoupon.discountType === 'fixed') {
      discount = Math.min(plan.price, appliedPlanCoupon.discountValue || 0);
    } else {
      const pct = appliedPlanCoupon.discountPercent ?? appliedPlanCoupon.discountValue ?? 0;
      discount = Math.round((plan.price * pct) / 100);
    }

    let finalPrice = plan.price - discount;
    if (isTrial) {
      finalPrice = Math.max(0, finalPrice);
      discount = plan.price - finalPrice;
    } else {
      // Monthly, Quarterly, Yearly: Minimum value is ₹ 1 when 100% coupon is applied
      finalPrice = Math.max(1, finalPrice);
      discount = plan.price - finalPrice;
    }

    return { discount, finalPrice, isApplicable: true };
  };`;

  if (content.includes('const getPlanDiscount = (plan: PlanConfig) => {')) {
    content = content.replace(oldGetPlanDiscount, newGetPlanDiscount);
    console.log('✓ Updated getPlanDiscount in dashboard/page.tsx');
  }

  // Update handleUpgrade
  const oldHandleUpgradeDiscount = `    if (appliedPlanCoupon) {
      const discount = (plan.price * (appliedPlanCoupon.discountPercent ?? 0)) / 100;
      finalPrice = Math.max(0, plan.price - discount);
      couponCode = appliedPlanCoupon.code;
      mockDb.useCoupon(appliedPlanCoupon.id);
    }`;

  const newHandleUpgradeDiscount = `    if (appliedPlanCoupon) {
      const isTrial = (plan.id || '').toLowerCase().includes('trial') || 
        (plan.id || '').toLowerCase().includes('test') || 
        (plan.name || '').toLowerCase().includes('trial') || 
        (plan.tier || '').toLowerCase() === 'trial';
      const discount = (plan.price * (appliedPlanCoupon.discountPercent ?? appliedPlanCoupon.discountValue ?? 0)) / 100;
      finalPrice = isTrial ? Math.max(0, plan.price - discount) : Math.max(1, plan.price - discount);
      couponCode = appliedPlanCoupon.code;
      mockDb.useCoupon(appliedPlanCoupon.id);
    }`;

  if (content.includes(oldHandleUpgradeDiscount)) {
    content = content.replace(oldHandleUpgradeDiscount, newHandleUpgradeDiscount);
    console.log('✓ Updated handleUpgrade in dashboard/page.tsx');
  }

  fs.writeFileSync(dashboardPath, content, 'utf8');
}

// 2. Update UpgradePlanModal.tsx
const modalPath = path.join(officeRoot, 'src/components/common/UpgradePlanModal.tsx');
if (fs.existsSync(modalPath)) {
  let content = fs.readFileSync(modalPath, 'utf8');

  // Update handlePayWithRazorpay price calculation
  const oldModalFinalPrice = `      let finalPrice = plan.price;
      if (appliedCoupon) {
        if (appliedCoupon.discountType === 'percentage' || appliedCoupon.discountType === 'percent') {
          finalPrice = Math.max(0, Math.round(plan.price * (1 - (appliedCoupon.discountValue || appliedCoupon.discountPercent || 0) / 100)));
        } else if (appliedCoupon.discountType === 'fixed') {
          finalPrice = Math.max(0, plan.price - appliedCoupon.discountValue);
        }
      }`;

  const newModalFinalPrice = `      let finalPrice = plan.price;
      const isTrial = (plan.id || '').toLowerCase().includes('trial') || 
        (plan.id || '').toLowerCase().includes('test') || 
        (plan.name || '').toLowerCase().includes('trial') || 
        (plan.tier || '').toLowerCase() === 'trial';

      if (appliedCoupon) {
        if (appliedCoupon.discountType === 'percentage' || appliedCoupon.discountType === 'percent') {
          const pct = appliedCoupon.discountValue || appliedCoupon.discountPercent || 0;
          finalPrice = Math.round(plan.price * (1 - pct / 100));
        } else if (appliedCoupon.discountType === 'fixed') {
          finalPrice = plan.price - (appliedCoupon.discountValue || 0);
        }

        if (isTrial) {
          finalPrice = Math.max(0, finalPrice);
        } else {
          finalPrice = Math.max(1, finalPrice);
        }
      }

      // If finalPrice is 0 (Trial Plan with 100% coupon), direct free activation
      if (finalPrice === 0) {
        if (appliedCoupon) {
          mockDb.useCoupon(appliedCoupon.id);
        }
        mockAuth.upgradeToPro(plan.duration);
        const updatedUser = mockAuth.getCurrentUser();
        if (updatedUser) {
          updatedUser.storageLimitMB = plan.storageMB;
          updatedUser.planType = \`\${plan.duration}-days\` as any;
          localStorage.setItem('portly_current_user', JSON.stringify(updatedUser));
        }
        mockDb.addTransaction({
          email: user.email,
          itemType: 'subscription',
          itemName: \`\${plan.name} (\${plan.duration} Days)\`,
          price: 0,
          originalPrice: plan.price,
          couponApplied: appliedCoupon?.code,
        });
        setIsProcessing(null);
        if (onUpgradeSuccess) onUpgradeSuccess(plan);
        onClose();
        return;
      }`;

  if (content.includes(oldModalFinalPrice)) {
    content = content.replace(oldModalFinalPrice, newModalFinalPrice);
    console.log('✓ Updated handlePayWithRazorpay in UpgradePlanModal.tsx');
  }

  fs.writeFileSync(modalPath, content, 'utf8');
}

// 3. Update MobileTemplatesSheet.tsx
const mobileSheetPath = path.join(officeRoot, 'src/components/editor/MobileTemplatesSheet.tsx');
if (fs.existsSync(mobileSheetPath)) {
  let content = fs.readFileSync(mobileSheetPath, 'utf8');

  const oldMap = `              {templates.map((tpl: any) => {
                const isActive = tpl.id === currentTemplateId;
                const access = checkTemplateAccess(currentUser, tpl);
                const isLocked = !isActive && !access.isAccessible;`;

  const newMap = `              {templates.filter((tpl: any) => {
                if (tpl.id === currentTemplateId) return true;
                const access = checkTemplateAccess(currentUser, tpl);
                return access.isAccessible;
              }).map((tpl: any) => {
                const isActive = tpl.id === currentTemplateId;
                const access = checkTemplateAccess(currentUser, tpl);
                const isLocked = !isActive && !access.isAccessible;`;

  if (content.includes(oldMap)) {
    content = content.replace(oldMap, newMap);
    console.log('✓ Updated MobileTemplatesSheet.tsx to show only purchased plan templates');
    fs.writeFileSync(mobileSheetPath, content, 'utf8');
  }
}

console.log('ALL UPDATES COMPLETED SUCCESSFULLY!');
