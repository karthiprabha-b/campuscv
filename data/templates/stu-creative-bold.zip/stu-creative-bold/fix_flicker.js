const fs = require('fs');
const path = require('path');

const baseDir = __dirname;
const officeDir = 'a:/Office/Portfolio site';

console.log('--- FIXING ALL FLICKER ISSUES ---');

// 1. UPDATE Hero.tsx (Solid Crisp Golden Accent Ring - 100% Zero Flicker)
const heroPath = path.join(baseDir, 'src/sections/Hero.tsx');
const newHero = `"use client";

import React from "react";
import { ArrowDownRight, ArrowDown, MessageSquare } from "lucide-react";
import { HeroData } from "@/data/portfolio";

interface HeroProps {
  data?: any;
  hero?: Partial<HeroData> & { avatarUrl?: string };
}

export default function Hero(props: HeroProps = {}) {
  const incoming = props.hero || props.data?.hero || props.data || {};
  const rawName = incoming.name || props.data?.name || props.data?.fullName || "Portfolio";
  
  const hero: HeroData & { avatarUrl?: string } = {
    greeting: incoming.greeting || props.data?.greeting || "HEY, I'M",
    name: rawName,
    title: incoming.title || props.data?.title || "SOFTWARE DEVELOPER",
    highlightedTitle: incoming.highlightedTitle || props.data?.highlightedTitle || "",
    description: incoming.description || incoming.intro || incoming.introductionText || props.data?.profile?.summary || props.data?.bio || props.data?.summary || "Builder-focused Developer with hands-on technical skills.",
    primaryCtaText: incoming.primaryCtaText || "VIEW MY WORK",
    primaryCtaHref: incoming.primaryCtaHref || "#projects",
    secondaryCtaText: incoming.secondaryCtaText || "GET IN TOUCH",
    secondaryCtaHref: incoming.secondaryCtaHref || "#contact",
    avatarUrl: incoming.avatarUrl || props.data?.avatarUrl || props.data?.profile?.photo || props.data?.profileImage || props.data?.avatar || "/profile.png"
  };

  const nameWords = (hero.name || "Portfolio").split(" ").filter(Boolean);

  return (
    <section
      id="home"
      data-section="hero"
      className="relative min-h-[90vh] pt-28 pb-16 flex items-center px-6 sm:px-12 md:px-16 lg:px-24 overflow-hidden z-10 bg-[#FAF9F6]"
    >
      <div className="max-w-7xl mx-auto w-full grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
        {/* Left Side: Bold Typography */}
        <div className="lg:col-span-7 flex flex-col justify-center space-y-6">
          <span
            data-field="hero.greeting"
            className="text-xs sm:text-sm font-black tracking-widest text-[#111111]/70 uppercase"
          >
            {hero.greeting}
          </span>

          <h1
            data-field="hero.name"
            className="text-4xl sm:text-6xl md:text-7xl font-black tracking-wide leading-tight text-[#111111]"
          >
            {nameWords.map((word: string, i: number) => (
              <span key={i} className="block">
                {word}
              </span>
            ))}
          </h1>

          <div className="inline-flex">
            <span
              data-field="hero.title"
              className="bg-[#FFC107] text-[#111111] text-xs sm:text-sm font-black tracking-wider uppercase px-4 py-2 shadow-xs rounded-xs font-bold"
            >
              {hero.title} {hero.highlightedTitle}
            </span>
          </div>

          <p
            data-field="hero.description"
            className="text-sm sm:text-base leading-relaxed text-[#666666] max-w-xl font-normal"
          >
            {hero.description}
          </p>

          {/* Action Buttons with Zero Layout Thrash / Zero Flicker */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 pt-4">
            <a
              href={hero.primaryCtaHref || "#projects"}
              data-field="hero.primaryCtaText"
              className="inline-flex items-center justify-center px-8 py-4 bg-[#111111] text-[#FAF9F6] text-xs sm:text-sm font-black tracking-widest uppercase border-2 border-[#111111] hover:bg-[#FFC107] hover:border-[#FFC107] hover:text-[#111111] transition-colors duration-150 shadow-sm rounded-xs cursor-pointer select-none"
            >
              {hero.primaryCtaText || "VIEW MY WORK"}
              <ArrowDownRight className="w-4 h-4 ml-2 stroke-[3]" />
            </a>

            <a
              href={hero.secondaryCtaHref || "#contact"}
              data-field="hero.secondaryCtaText"
              className="inline-flex items-center justify-center px-8 py-4 bg-transparent border-2 border-[#111111] text-[#111111] text-xs sm:text-sm font-black tracking-widest uppercase hover:bg-[#111111] hover:text-[#FAF9F6] transition-colors duration-150 rounded-xs cursor-pointer select-none"
            >
              {hero.secondaryCtaText || "GET IN TOUCH"}
              <MessageSquare className="w-4 h-4 ml-2 stroke-[2.5]" />
            </a>
          </div>
        </div>

        {/* Right Side: Crisp High-Resolution Layered Ring Layout (No Flickering Animations) */}
        <div className="lg:col-span-5 flex justify-center lg:justify-end items-center relative py-12 lg:py-0 select-none">
          <div className="relative w-72 h-72 sm:w-96 sm:h-96">
            
            {/* Crisp Golden Layered Ring (Static, Crisp, Anti-Aliased) */}
            <div className="absolute -inset-3 rounded-full border-2 border-[#FFC107] pointer-events-none opacity-90" />
            <div className="absolute -inset-1 rounded-full border border-[#111111]/15 pointer-events-none" />

            {/* Back Shadow Offset Circle */}
            <div className="absolute top-3 left-3 w-full h-full rounded-full bg-[#111111]/5 border border-[#111111]/10 pointer-events-none" />

            {/* Floating Star Vector (Static Crisp Accent) */}
            <div className="absolute -top-3 left-4 text-[#FFC107] w-8 h-8 stroke-[2] pointer-events-none drop-shadow-xs">
              <svg viewBox="0 0 24 24" fill="none" stroke="#FFC107">
                <path d="M12 2v20M2 12h20M5 5l14 14M19 5L5 19" />
              </svg>
            </div>

            {/* Floating Mini Dot Matrix Accent */}
            <div className="absolute -right-2 top-8 w-16 h-16 opacity-30 pointer-events-none">
              <svg width="100%" height="100%" fill="none" xmlns="http://www.w3.org/2000/svg">
                <defs>
                  <pattern id="hero-dots-static" width="10" height="10" patternUnits="userSpaceOnUse">
                    <circle cx="2" cy="2" r="1.5" fill="#111111" />
                  </pattern>
                </defs>
                <rect width="100%" height="100%" fill="url(#hero-dots-static)" />
              </svg>
            </div>

            {/* Main Picture Frame */}
            <div className="absolute inset-0 rounded-full overflow-hidden border-4 border-[#111111] bg-white shadow-xl">
              <img
                src={hero.avatarUrl}
                alt={hero.name}
                data-field="hero.avatarUrl"
                className="w-full h-full object-cover"
                onError={(e) => {
                  e.currentTarget.src = 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80';
                }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Floating Scroll Down Indicator */}
      <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 flex flex-col items-center pointer-events-none select-none">
        <a
          href="#about"
          className="flex flex-col items-center text-[10px] sm:text-xs font-black tracking-widest text-[#111111]/50 uppercase pointer-events-auto hover:text-[#FFC107] transition-colors"
        >
          <span>SCROLL</span>
          <ArrowDown className="w-4 h-4 mt-1" />
        </a>
      </div>
    </section>
  );
}
`;
fs.writeFileSync(heroPath, newHero, 'utf8');
console.log('✓ Updated Hero.tsx with solid crisp golden ring');

// 2. UPDATE Navbar.tsx (Stable Sticky Header with No Scroll Listeners that Cause Re-render Flickers)
const navbarPath = path.join(baseDir, 'src/components/Navbar.tsx');
const newNavbar = `"use client";

import React, { useState, useEffect } from "react";
import { Menu, X, ArrowUpRight } from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";
import { NavLink } from "@/data/portfolio";

interface NavbarProps {
  data?: any;
  navLinks?: NavLink[];
  name?: string;
}

export default function Navbar(props: NavbarProps = {}) {
  const [isOpen, setIsOpen] = useState(false);

  const rawName = props.name || props.data?.name || props.data?.fullName || props.data?.hero?.name || "PORTFOLIO";
  const brandName = rawName.toUpperCase().endsWith('.') ? rawName.toUpperCase() : \`\${rawName.toUpperCase().split(' ')[0]}.\`;

  const defaultLinks: NavLink[] = [
    { label: "Home", href: "#home" },
    { label: "About", href: "#about" },
    { label: "Skills", href: "#skills" },
    { label: "Projects", href: "#projects" },
    { label: "Experience", href: "#experience" },
    { label: "Contact", href: "#contact" }
  ];

  const links: NavLink[] = Array.isArray(props.navLinks) && props.navLinks.length > 0
    ? props.navLinks.filter(l => !l.label.toLowerCase().includes('service') && !l.label.toLowerCase().includes('tool'))
    : (Array.isArray(props.data?.navLinks) && props.data.navLinks.length > 0
      ? props.data.navLinks.filter((l: any) => !l.label.toLowerCase().includes('service') && !l.label.toLowerCase().includes('tool'))
      : defaultLinks);

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 768) {
        setIsOpen(false);
      }
    };
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  return (
    <header className="sticky top-0 left-0 right-0 z-50 bg-[#FAF9F6]/95 backdrop-blur-md border-b border-[#111111]/10 py-4 px-6 sm:px-12 md:px-16 lg:px-24">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <a
          href="#home"
          data-field="name"
          className="text-xl md:text-2xl font-black tracking-tight text-[#111111] hover:text-[#FFC107] transition-colors duration-150 select-none"
        >
          {brandName}
        </a>

        <nav className="hidden md:flex items-center space-x-8">
          {links.map((link: NavLink) => (
            <a
              key={link.label}
              href={link.href}
              className="relative text-base font-bold tracking-wide text-[#111111] hover:text-[#FFC107] transition-colors duration-150 group select-none"
            >
              {link.label}
              <span className="absolute left-0 bottom-[-4px] w-0 h-[2px] bg-[#FFC107] transition-all duration-200 group-hover:w-full" />
            </a>
          ))}
        </nav>

        <div className="hidden md:flex items-center space-x-4">
          <a
            href="#contact"
            className="inline-flex items-center px-5 py-2.5 bg-[#111111] text-[#FAF9F6] text-xs font-black tracking-wider uppercase border-2 border-[#111111] hover:bg-[#FFC107] hover:border-[#FFC107] hover:text-[#111111] transition-colors duration-150 shadow-sm rounded-xs cursor-pointer select-none"
          >
            {"Let's Talk"}
            <ArrowUpRight className="w-3.5 h-3.5 ml-1.5 stroke-[3]" />
          </a>
        </div>

        <div className="flex items-center space-x-3 md:hidden">
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="p-2 rounded-full text-[#111111] hover:bg-[#111111]/5 cursor-pointer"
            aria-label="Toggle menu"
          >
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.15 }}
            className="absolute top-full left-0 right-0 bg-[#FAF9F6] border-b border-[#111111]/10 shadow-xl px-6 py-8 flex flex-col space-y-6 md:hidden z-40"
          >
            <div className="flex flex-col space-y-4">
              {links.map((link: NavLink) => (
                <a
                  key={link.label}
                  href={link.href}
                  onClick={() => setIsOpen(false)}
                  className="text-lg font-bold text-[#111111] hover:text-[#FFC107] transition-colors"
                >
                  {link.label}
                </a>
              ))}
            </div>

            <div className="pt-4 border-t border-[#111111]/10">
              <a
                href="#contact"
                onClick={() => setIsOpen(false)}
                className="w-full justify-center inline-flex items-center px-6 py-3 bg-[#111111] text-[#FAF9F6] text-sm font-black tracking-wider uppercase border border-[#111111] hover:bg-[#FFC107] hover:text-[#111111] transition-colors rounded-xs cursor-pointer"
              >
                {"Let's Talk"}
                <ArrowUpRight className="w-4.5 h-4.5 ml-2 stroke-[3]" />
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
`;
fs.writeFileSync(navbarPath, newNavbar, 'utf8');
console.log('✓ Updated Navbar.tsx');

// 3. UPDATE template.tsx (Deep comparison to avoid re-render loops in Editor canvas)
const templateMainPath = path.join(baseDir, 'src/template.tsx');
const newTemplate = `"use client";

import React, { useState, useEffect, useMemo, useRef } from "react";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import BackgroundDecor from "./components/BackgroundDecor";
import ScrollToTop from "./components/ScrollToTop";
import TestimonialCarousel from "./components/TestimonialCarousel";

// Section imports
import Hero from "./sections/Hero";
import About from "./sections/About";
import Approach from "./sections/Approach";
import Education from "./sections/Education";
import Skills from "./sections/Skills";
import Certifications from "./sections/Certifications";
import Projects from "./sections/Projects";
import Experience from "./sections/Experience";
import Achievements from "./sections/Achievements";
import Contact from "./sections/Contact";

import { normalizeData, NormalizedPortfolioData } from "./utils/normalizeData";
import "./styles/index.css";

const CRITICAL_CSS = \`
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Outfit:wght@400;500;600;700;800;900&display=swap');

  :root {
    --brand-yellow: #FFC107;
    --brand-dark: #111111;
    --brand-cream: #FAF9F6;
    --brand-muted: #666666;
    --font-inter: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    --font-outfit: 'Outfit', sans-serif;
  }

  .portfolio-root {
    background-color: #FAF9F6 !important;
    color: #111111 !important;
    font-family: 'Inter', sans-serif;
  }

  .bg-brand-yellow {
    background-color: #FFC107 !important;
  }

  .text-brand-yellow {
    color: #FFC107 !important;
  }

  .border-brand-yellow {
    border-color: #FFC107 !important;
  }

  .bg-brand-dark {
    background-color: #111111 !important;
    color: #ffffff !important;
  }

  .text-brand-dark {
    color: #111111 !important;
  }

  .border-brand-dark {
    border-color: #111111 !important;
  }

  .text-brand-muted {
    color: #666666 !important;
  }

  .bg-brand-cream {
    background-color: #FAF9F6 !important;
  }

  .text-brand-cream {
    color: #FAF9F6 !important;
  }

  footer.bg-brand-dark {
    background-color: #111111 !important;
    color: #ffffff !important;
  }
\`;

export interface TemplateProps {
  data?: any;
  portfolio?: any;
  profile?: any;
  cv?: any;
  resume?: any;
  [key: string]: any;
}

export default function Template(props: TemplateProps = {}) {
  const rawPropsData = props?.data || props?.portfolio || props?.profile || props?.cv || props?.resume || props || {};
  const [liveData, setLiveData] = useState<NormalizedPortfolioData>(() => normalizeData(rawPropsData));
  const prevStringRef = useRef<string>('');

  // Update only when serialized data changes to prevent infinite render loops
  useEffect(() => {
    try {
      const serialized = JSON.stringify(props?.data || props?.portfolio || props?.profile || props?.cv || props?.resume || props || {});
      if (serialized !== prevStringRef.current) {
        prevStringRef.current = serialized;
        setLiveData(normalizeData(JSON.parse(serialized)));
      }
    } catch {}
  }, [props?.data, props?.portfolio, props?.profile, props?.cv, props?.resume, props]);

  useEffect(() => {
    if (typeof window === "undefined") return;

    const handleMessage = (event: MessageEvent) => {
      try {
        const payload = event.data;
        if (!payload || typeof payload !== "object") return;

        if (
          payload.type === "CAMPUSCV_SET_DATA" ||
          payload.type === "SET_PORTFOLIO_DATA" ||
          payload.type === "UPDATE_DATA" ||
          payload.type === "CAMPUSCV_UPDATE_DATA" ||
          payload.type === "campuscv_update"
        ) {
          const incoming = payload.data || payload.portfolio || payload.payload;
          if (incoming && typeof incoming === "object") {
            setLiveData(normalizeData(incoming));
          }
        } else if (payload.type === "UPDATE_FIELD" && payload.field) {
          setLiveData((prev) => {
            const copy: any = { ...prev };
            const parts = payload.field.split(".");
            if (parts.length === 1) {
              copy[parts[0]] = payload.value;
            } else if (parts.length === 2) {
              copy[parts[0]] = { ...copy[parts[0]], [parts[1]]: payload.value };
            }
            return normalizeData(copy);
          });
        }
      } catch (err) {
        console.warn("CampusCV postMessage listener notice:", err);
      }
    };

    window.addEventListener("message", handleMessage);

    try {
      if (window.parent && window.parent !== window) {
        window.parent.postMessage({ type: "CAMPUSCV_TEMPLATE_READY", templateId: "stu-creative-bold" }, "*");
      }
    } catch (_) {}

    return () => {
      window.removeEventListener("message", handleMessage);
    };
  }, []);

  const data = liveData;

  const isSectionVisible = (sectionName: string): boolean => {
    if (data[\`\${sectionName}.visible\`] === false || data[\`\${sectionName}.visible\`] === 0) return false;
    if (data[\`\${sectionName}Visible\`] === false || data[\`\${sectionName}Visible\`] === 0) return false;
    if (data[sectionName] && typeof data[sectionName] === "object" && data[sectionName].visible === false) {
      return false;
    }
    return true;
  };

  const primaryAccent = data.theme?.primaryColor || data.accentColor || data.themeColor || "";
  const dynamicStyles: React.CSSProperties = {
    position: "relative",
    minHeight: "100vh",
    overflow: "hidden",
    backgroundColor: "#FAF9F6",
    color: "#111111",
    ...(primaryAccent
      ? {
          "--brand-yellow": primaryAccent,
          "--primary": primaryAccent,
        } as any
      : {})
  };

  return (
    <div
      className="portfolio-root light min-h-screen bg-[#FAF9F6] text-[#111111] font-sans antialiased relative overflow-hidden"
      data-theme="light"
      style={dynamicStyles}
    >
      <style dangerouslySetInnerHTML={{ __html: CRITICAL_CSS }} />

      <BackgroundDecor />

      <Navbar data={data} navLinks={data.navLinks} name={data.name} />

      <main className="relative z-10">
        {/* 1. Hero Section */}
        {isSectionVisible("hero") && <Hero data={data} hero={data.hero} />}

        {/* 2. About Section */}
        {isSectionVisible("about") && <About data={data} about={data.about} />}

        {/* 3. My Approach (Workflow) Section */}
        {isSectionVisible("approach") && <Approach data={data} approachSteps={data.approachSteps} />}

        {/* 4. Education History Section */}
        {isSectionVisible("education") && <Education data={data} education={data.education} />}

        {/* 5. Skills & Proficiency Section */}
        {isSectionVisible("skills") && <Skills data={data} skills={data.skills} />}

        {/* 6. Certifications Section */}
        {isSectionVisible("certifications") && <Certifications data={data} certifications={data.certifications} />}

        {/* 7. Featured Projects Section */}
        {isSectionVisible("projects") && <Projects data={data} projects={data.projects} />}

        {/* 8. Career Work Experience Section */}
        {isSectionVisible("experience") && <Experience data={data} experiences={data.experiences} />}

        {/* 9. Testimonials Section */}
        {isSectionVisible("testimonials") && (
          <section className="py-24 px-6 sm:px-12 md:px-16 lg:px-24 border-t border-[#111111]/10 relative z-10 bg-[#111111]/[0.02]">
            <div className="max-w-7xl mx-auto">
              <div className="flex flex-col mb-16 items-center text-center space-y-3">
                <span className="text-xs font-black tracking-widest text-[#FFC107] uppercase">
                  Feedback
                </span>
                <h2 className="text-3xl sm:text-4xl md:text-5xl font-black tracking-wide leading-tight text-[#111111]">
                  WHAT PEOPLE SAY
                </h2>
                <div className="w-12 h-1 bg-[#FFC107] mt-2" />
              </div>
              <TestimonialCarousel data={data} testimonials={data.testimonials} />
            </div>
          </section>
        )}

        {/* 10. Achievements / Awards Section */}
        {isSectionVisible("achievements") && <Achievements data={data} achievements={data.achievements} />}

        {/* 11. Contact Section */}
        {isSectionVisible("contact") && <Contact data={data} contact={data.contact} />}
      </main>

      <Footer data={data} contact={data.contact} navLinks={data.navLinks} name={data.name} />

      <ScrollToTop />
    </div>
  );
}

export { Template as Portfolio };
`;
fs.writeFileSync(templateMainPath, newTemplate, 'utf8');
console.log('✓ Updated template.tsx with re-render loop prevention');
