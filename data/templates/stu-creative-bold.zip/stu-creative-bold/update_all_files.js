const fs = require('fs');
const path = require('path');

const baseDir = __dirname;

console.log('Writing updated template files...');

// 1. normalizeData.ts
const normalizeDataContent = `import {
  heroData as defaultHero,
  aboutData as defaultAbout,
  approachSteps as defaultApproach,
  educationHistory as defaultEducation,
  skillCategories as defaultSkills,
  certifications as defaultCertifications,
  projects as defaultProjects,
  experiences as defaultExperiences,
  testimonials as defaultTestimonials,
  achievements as defaultAchievements,
  contactData as defaultContact,
  HeroData,
  AboutData,
  ApproachStep,
  EducationItem,
  SkillCategory,
  CertificationItem,
  ProjectItem,
  ExperienceItem,
  TestimonialItem,
  AchievementItem,
  ContactData,
  NavLink
} from '../data/portfolio';

export interface NormalizedPortfolioData {
  name: string;
  fullName: string;
  title: string;
  theme?: {
    primaryColor?: string;
    backgroundColor?: string;
    textColor?: string;
  };
  hero: HeroData;
  about: AboutData;
  approachSteps: ApproachStep[];
  education: EducationItem[];
  skills: SkillCategory[];
  certifications: CertificationItem[];
  projects: ProjectItem[];
  experiences: ExperienceItem[];
  testimonials: TestimonialItem[];
  achievements: AchievementItem[];
  contact: ContactData;
  navLinks: NavLink[];
  contentOverrides?: Record<string, any>;
  imageOverrides?: Record<string, any>;
  [key: string]: any;
}

export function normalizeData(raw: any): NormalizedPortfolioData {
  const data = typeof raw === 'object' && raw !== null ? (raw.data || raw.portfolio || raw.cv || raw.resume || raw.profile || raw) : {};

  // Extract student/candidate full name across all possible structures
  const resolvedName = (
    data.fullName ||
    data.name ||
    data.profile?.fullName ||
    data.profile?.name ||
    data.personalInfo?.fullName ||
    data.personalInfo?.name ||
    data.personal?.fullName ||
    data.personal?.name ||
    data.basics?.name ||
    data.hero?.name ||
    (typeof raw === 'object' && raw !== null ? (raw.fullName || raw.name || raw.profile?.fullName || raw.profile?.name || raw.personal?.fullName) : null) ||
    'Portfolio'
  ).trim();

  const resolvedTitle = (
    data.title ||
    data.headline ||
    data.role ||
    data.designation ||
    data.hero?.title ||
    data.profile?.headline ||
    data.personalInfo?.headline ||
    data.basics?.label ||
    'Software Developer & Engineer'
  ).trim();

  // Resolve profile avatar
  const rawOverride =
    data.contentOverrides?.['image:hero:root:img:0']?.src ||
    (typeof data.contentOverrides?.['image:hero:root:img:0'] === 'string' ? data.contentOverrides?.['image:hero:root:img:0'] : null) ||
    data.contentOverrides?.['image:about:root:img:0']?.src ||
    data.imageOverrides?.['image:hero:root:img:0'] ||
    data.imageOverrides?.['image:about:root:img:0'] ||
    data.imageOverrides?.['hero.avatarUrl'] ||
    data.imageOverrides?.['about.avatarUrl'];

  const explicitAvatar = typeof rawOverride === 'object' && rawOverride !== null ? (rawOverride.src || rawOverride.value) : rawOverride;
  const avatarUrl =
    explicitAvatar ||
    data.hero?.avatarUrl ||
    data.avatarUrl ||
    data.profileImage ||
    data.profile?.photo ||
    data.profile?.avatarUrl ||
    data.personalInfo?.photo ||
    data.avatar ||
    data.photo ||
    data.image ||
    data.about?.avatarUrl ||
    data.basics?.image ||
    data.basics?.avatar ||
    '/profile.png';

  // 1. Normalize Hero
  const hero: HeroData = {
    greeting: data.hero?.greeting || data.greeting || "HEY, I'M",
    name: resolvedName,
    title: data.hero?.title || resolvedTitle,
    highlightedTitle: data.hero?.highlightedTitle || data.highlightedTitle || data.hero?.subtitle || "",
    description:
      data.hero?.description ||
      data.hero?.intro ||
      data.hero?.introductionText ||
      data.profile?.summary ||
      data.profile?.about ||
      data.bio ||
      data.summary ||
      data.basics?.summary ||
      "Builder-focused Software Developer with hands-on technical skills.",
    primaryCtaText: data.hero?.primaryCtaText || "VIEW MY WORK",
    primaryCtaHref: data.hero?.primaryCtaHref || "#projects",
    secondaryCtaText: data.hero?.secondaryCtaText || "GET IN TOUCH",
    secondaryCtaHref: data.hero?.secondaryCtaHref || "#contact",
    ...(data.hero && typeof data.hero === 'object' ? data.hero : {})
  };
  (hero as any).avatarUrl = avatarUrl;
  hero.name = resolvedName;

  // 2. Normalize About
  const aboutRaw = data.about || {};
  let stats = defaultAbout.stats;
  if (Array.isArray(aboutRaw.stats) && aboutRaw.stats.length > 0) {
    stats = aboutRaw.stats.map((st: any, idx: number) => ({
      value: typeof st.value === 'number' ? st.value : (parseInt(String(st.value).replace(/\\D/g, '')) || (idx + 1) * 5),
      suffix: st.suffix !== undefined ? st.suffix : (String(st.value).includes('+') ? '+' : (String(st.value).includes('%') ? '%' : '')),
      label: st.label || st.title || \`Stat \${idx + 1}\`,
      icon: st.icon || ['BookOpen', 'Briefcase', 'Award', 'Heart'][idx % 4]
    }));
  } else if (Array.isArray(data.stats) && data.stats.length > 0) {
    stats = data.stats.map((st: any, idx: number) => ({
      value: typeof st.value === 'number' ? st.value : (parseInt(String(st.value).replace(/\\D/g, '')) || (idx + 1) * 5),
      suffix: st.suffix !== undefined ? st.suffix : '',
      label: st.label || st.title || \`Stat \${idx + 1}\`,
      icon: st.icon || ['BookOpen', 'Briefcase', 'Award', 'Heart'][idx % 4]
    }));
  }

  const about: AboutData = {
    title: aboutRaw.title || data.aboutHeading || "ABOUT ME",
    subtitle: aboutRaw.subtitle || data.aboutSubtitle || "A Glimpse Into My Journey",
    description:
      (typeof aboutRaw === 'string' ? aboutRaw : aboutRaw.description) ||
      aboutRaw.bio ||
      aboutRaw.story ||
      data.profile?.about ||
      data.profile?.summary ||
      data.bio ||
      data.aboutMe ||
      data.summary ||
      "Passionate developer focused on building impactful digital architectures.",
    objective: aboutRaw.objective || data.objective || aboutRaw.mission || defaultAbout.objective,
    stats
  };

  // 3. Normalize Approach Steps
  let approachStepsList = defaultApproach;
  const rawApproach = data.approachSteps || data.approach || data.workflow || data.process;
  if (Array.isArray(rawApproach) && rawApproach.length > 0) {
    approachStepsList = rawApproach.map((st: any, idx: number) => ({
      step: String(st.step || (idx + 1 < 10 ? \`0\${idx + 1}\` : \`\${idx + 1}\`)),
      title: st.title || st.name || \`Phase \${idx + 1}\`,
      description: st.description || st.desc || '',
      icon: st.icon || ['Search', 'Palette', 'Cpu', 'Rocket'][idx % 4]
    }));
  }

  // 4. Normalize Education
  let educationList = defaultEducation;
  const rawEdu = data.education || data.educationHistory || data.academics || data.educationList;
  if (Array.isArray(rawEdu) && rawEdu.length > 0) {
    educationList = rawEdu.map((edu: any) => ({
      degree: edu.degree || edu.title || edu.major || edu.course || 'Degree Program',
      institution: edu.institution || edu.school || edu.university || edu.college || 'Institution',
      duration: edu.duration || edu.period || edu.year || (edu.startDate && edu.endDate ? \`\${edu.startDate} - \${edu.endDate}\` : 'Present'),
      grade: edu.grade || edu.gpa || edu.score || edu.status || 'Graduated',
      description: edu.description || edu.details || (Array.isArray(edu.highlights) ? edu.highlights.join(' ') : '') || ''
    }));
  }

  // 5. Normalize Skills — Handle all skills from CampusCV without dropping
  let skillsList: SkillCategory[] = [];
  const rawSkills = data.skills || data.skillCategories || data.skillsList || data.techStack;

  if (Array.isArray(rawSkills) && rawSkills.length > 0) {
    if (typeof rawSkills[0] === 'object' && rawSkills[0] !== null && ('category' in rawSkills[0] || 'title' in rawSkills[0]) && Array.isArray(rawSkills[0].items || rawSkills[0].skills)) {
      skillsList = rawSkills.map((cat: any) => ({
        category: cat.category || cat.title || 'Technical Skills',
        items: (cat.items || cat.skills || []).map((it: any) => ({
          name: typeof it === 'string' ? it : (it.name || it.title || it.skill || ''),
          percentage: typeof it === 'object' && typeof it.percentage === 'number' ? it.percentage : 85
        })).filter((s: any) => s.name)
      })).filter((c: any) => c.items.length > 0);
    } else {
      const categoryMap: Record<string, any[]> = {};

      rawSkills.forEach((sk: any) => {
        let skillName = '';
        let skillCategory = 'Technical Competencies';
        let percentage = 85;

        if (typeof sk === 'string') {
          skillName = sk;
        } else if (typeof sk === 'object' && sk !== null) {
          skillName = sk.name || sk.title || sk.skill || '';
          skillCategory = sk.category || sk.type || sk.group || 'Technical Competencies';
          percentage = typeof sk.percentage === 'number' ? sk.percentage : (typeof sk.level === 'number' ? sk.level : 85);
        }

        if (skillName && skillName.trim()) {
          if (!categoryMap[skillCategory]) {
            categoryMap[skillCategory] = [];
          }
          categoryMap[skillCategory].push({ name: skillName.trim(), percentage });
        }
      });

      const categories = Object.keys(categoryMap);
      if (categories.length > 1) {
        skillsList = categories.map(catName => ({
          category: catName,
          items: categoryMap[catName]
        }));
      } else if (categories.length === 1) {
        const allItems = categoryMap[categories[0]];
        if (allItems.length <= 12) {
          skillsList = [{ category: categories[0], items: allItems }];
        } else {
          const chunkSize = Math.ceil(allItems.length / 3);
          skillsList = [
            { category: 'Frontend & Web Technologies', items: allItems.slice(0, chunkSize) },
            { category: 'Backend, Database & Core', items: allItems.slice(chunkSize, chunkSize * 2) },
            { category: 'Tools, Platforms & Libraries', items: allItems.slice(chunkSize * 2) }
          ].filter(c => c.items.length > 0);
        }
      }
    }
  }

  if (skillsList.length === 0) {
    skillsList = defaultSkills;
  }

  // 6. Normalize Certifications
  let certList = defaultCertifications;
  const rawCerts = data.certifications || data.certificates || data.credentials;
  if (Array.isArray(rawCerts) && rawCerts.length > 0) {
    certList = rawCerts.map((c: any) => ({
      title: c.title || c.name || 'Professional Certification',
      organization: c.organization || c.issuer || c.provider || c.authority || 'Verified Authority',
      date: c.date || c.issueDate || c.year || '2025',
      credentialUrl: c.credentialUrl || c.url || c.link || '#'
    }));
  }

  // 7. Normalize Projects
  let projectsList = defaultProjects;
  const rawProjects = data.projects || data.portfolioProjects || data.works || data.featuredProjects;
  if (Array.isArray(rawProjects) && rawProjects.length > 0) {
    projectsList = rawProjects.map((p: any) => ({
      title: p.title || p.name || 'Featured Project',
      category: p.category || p.type || 'Web',
      description: p.description || p.summary || p.shortDesc || '',
      image: p.image || p.imageUrl || p.thumbnail || p.cover || '',
      techStack: Array.isArray(p.techStack) ? p.techStack : (Array.isArray(p.tags) ? p.tags : (Array.isArray(p.technologies) ? p.technologies : ['React', 'Next.js', 'Tailwind CSS'])),
      liveUrl: p.liveUrl || p.live || p.demo || p.url || '',
      githubUrl: p.githubUrl || p.github || p.repo || ''
    }));
  }

  // 8. Normalize Experience
  let expList = defaultExperiences;
  const rawExp = data.experiences || data.experience || data.workExperience || data.work;
  if (Array.isArray(rawExp) && rawExp.length > 0) {
    expList = rawExp.map((e: any) => {
      let descBullets: string[] = [];
      if (Array.isArray(e.description)) {
        descBullets = e.description;
      } else if (Array.isArray(e.bullets)) {
        descBullets = e.bullets;
      } else if (Array.isArray(e.highlights)) {
        descBullets = e.highlights;
      } else if (typeof e.description === 'string' && e.description.trim()) {
        descBullets = e.description.split('\\n').map((s: string) => s.replace(/^[-*•]\\s*/, '').trim()).filter(Boolean);
      }

      if (descBullets.length === 0) {
        descBullets = [e.summary || e.role || 'Contributed to high-impact development initiatives.'];
      }

      return {
        company: e.company || e.organization || e.client || 'Company',
        role: e.role || e.position || e.title || 'Engineer',
        duration: e.duration || e.period || (e.startDate && e.endDate ? \`\${e.startDate} - \${e.endDate}\` : 'Present'),
        description: descBullets
      };
    });
  }

  // 9. Normalize Testimonials
  let testimonialsList = defaultTestimonials;
  const rawTestimonials = data.testimonials || data.feedback || data.reviews;
  if (Array.isArray(rawTestimonials) && rawTestimonials.length > 0) {
    testimonialsList = rawTestimonials.map((t: any) => ({
      quote: t.quote || t.content || t.message || t.feedback || 'Outstanding collaboration and delivery.',
      author: t.author || t.name || 'Colleague',
      role: t.role || t.title || t.designation || 'Product Lead',
      avatar: t.avatar || t.avatarUrl || t.image || 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=120&h=120&q=80'
    }));
  }

  // 10. Normalize Achievements
  let achievementsList = defaultAchievements;
  const rawAch = data.achievements || data.awards || data.honors || data.milestones;
  if (Array.isArray(rawAch) && rawAch.length > 0) {
    achievementsList = rawAch.map((a: any) => ({
      title: a.title || a.name || 'Excellence Award',
      organization: a.organization || a.issuer || a.event || 'Global Tech Community',
      value: a.value || a.year || a.score || a.place || '2025',
      description: a.description || a.details || a.summary || ''
    }));
  }

  // 11. Normalize Contact & Socials
  const contactRaw = data.contact || {};
  const contact: ContactData = {
    email: contactRaw.email || data.email || data.ownerEmail || data.profile?.email || data.personalInfo?.email || data.basics?.email || '',
    phone: contactRaw.phone || data.phone || data.phoneNumber || data.profile?.phone || data.personalInfo?.phone || data.basics?.phone || '',
    location: contactRaw.location || data.location || data.profile?.location || data.personalInfo?.location || data.basics?.location?.city || '',
    socials: {
      linkedin: contactRaw.socials?.linkedin || data.socials?.linkedin || data.socialLinks?.linkedin || data.profile?.linkedin || '',
      github: contactRaw.socials?.github || data.socials?.github || data.socialLinks?.github || data.profile?.github || '',
      instagram: contactRaw.socials?.instagram || data.socials?.instagram || data.socialLinks?.instagram || data.profile?.instagram || '',
      twitter: contactRaw.socials?.twitter || data.socials?.twitter || data.socialLinks?.twitter || data.profile?.twitter || '',
      behance: contactRaw.socials?.behance || data.socials?.behance || data.socialLinks?.behance || data.profile?.behance || ''
    }
  };

  const navLinks: NavLink[] = [
    { label: "Home", href: "#home" },
    { label: "About", href: "#about" },
    { label: "Skills", href: "#skills" },
    { label: "Projects", href: "#projects" },
    { label: "Experience", href: "#experience" },
    { label: "Contact", href: "#contact" }
  ];

  return {
    name: resolvedName,
    fullName: resolvedName,
    title: resolvedTitle,
    theme: data.theme,
    hero,
    about,
    approachSteps: approachStepsList,
    education: educationList,
    skills: skillsList,
    certifications: certList,
    projects: projectsList,
    experiences: expList,
    testimonials: testimonialsList,
    achievements: achievementsList,
    contact,
    navLinks,
    contentOverrides: data.contentOverrides,
    imageOverrides: data.imageOverrides,
    ...data
  };
}
`;
fs.writeFileSync(path.join(baseDir, 'src/utils/normalizeData.ts'), normalizeDataContent, 'utf8');

// 2. Navbar.tsx
const navbarContent = `"use client";

import React, { useState, useEffect } from "react";
import { Menu, X, ArrowUpRight } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { NavLink } from "@/data/portfolio";
import { cn } from "@/lib/utils";

interface NavbarProps {
  data?: any;
  navLinks?: NavLink[];
  name?: string;
}

export default function Navbar(props: NavbarProps = {}) {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  const rawName = props.name || props.data?.name || props.data?.fullName || props.data?.hero?.name || "PORTFOLIO";
  const brandName = rawName.toUpperCase().endsWith('.') ? rawName.toUpperCase() : \`\${rawName.toUpperCase().split(' ')[0]}.\`;

  const defaultLinks: NavLink[] = [
    { label: "Home", href: "#home" },
    { label: "About", href: "#about" },
    { label: "Skills", href: "#skills" },
    { label: "Projects", href: "#projects" },
    { label: "Experience", href: "#experience" },
    { label: "Contact", href: "#contact" }
  ];

  const links: NavLink[] = Array.isArray(props.navLinks) && props.navLinks.length > 0
    ? props.navLinks.filter(l => !l.label.toLowerCase().includes('service') && !l.label.toLowerCase().includes('tool'))
    : (Array.isArray(props.data?.navLinks) && props.data.navLinks.length > 0
      ? props.data.navLinks.filter((l: any) => !l.label.toLowerCase().includes('service') && !l.label.toLowerCase().includes('tool'))
      : defaultLinks);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 768) {
        setIsOpen(false);
      }
    };
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  return (
    <header
      className={cn(
        "fixed top-0 left-0 right-0 z-50 transition-all duration-300 px-6 sm:px-12 md:px-16 lg:px-24",
        scrolled
          ? "py-4 bg-[#FAF9F6]/95 backdrop-blur-md border-b border-[#111111]/10 shadow-xs"
          : "py-6 bg-transparent"
      )}
    >
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <a
          href="#home"
          data-field="name"
          className="text-xl md:text-2xl font-black tracking-tight text-[#111111] hover:text-[#FFC107] transition-colors duration-200"
        >
          {brandName}
        </a>

        <nav className="hidden md:flex items-center space-x-8">
          {links.map((link: NavLink) => (
            <a
              key={link.label}
              href={link.href}
              className="relative text-base font-bold tracking-wide text-[#111111] hover:text-[#FFC107] transition-colors duration-200 group"
            >
              {link.label}
              <span className="absolute left-0 bottom-[-4px] w-0 h-[2px] bg-[#FFC107] transition-all duration-300 group-hover:w-full" />
            </a>
          ))}
        </nav>

        <div className="hidden md:flex items-center space-x-4">
          <a
            href="#contact"
            className="inline-flex items-center px-5 py-2.5 bg-[#111111] text-[#FAF9F6] text-xs font-black tracking-wider uppercase border-2 border-[#111111] hover:bg-[#FFC107] hover:border-[#FFC107] hover:text-[#111111] transition-colors duration-200 shadow-md hover:shadow-lg rounded-sm cursor-pointer transform-gpu"
          >
            {"Let's Talk"}
            <ArrowUpRight className="w-3.5 h-3.5 ml-1.5 stroke-[3]" />
          </a>
        </div>

        <div className="flex items-center space-x-3 md:hidden">
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="p-2 rounded-full text-[#111111] hover:bg-[#111111]/5 cursor-pointer"
            aria-label="Toggle menu"
          >
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.2 }}
            className="absolute top-full left-0 right-0 bg-[#FAF9F6] border-b border-[#111111]/10 shadow-xl px-6 py-8 flex flex-col space-y-6 md:hidden z-40"
          >
            <div className="flex flex-col space-y-4">
              {links.map((link: NavLink, idx: number) => (
                <motion.a
                  key={link.label}
                  href={link.href}
                  onClick={() => setIsOpen(false)}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.05 }}
                  className="text-lg font-bold text-[#111111] hover:text-[#FFC107] transition-colors"
                >
                  {link.label}
                </motion.a>
              ))}
            </div>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3 }}
              className="pt-4 border-t border-[#111111]/10"
            >
              <a
                href="#contact"
                onClick={() => setIsOpen(false)}
                className="w-full justify-center inline-flex items-center px-6 py-3 bg-[#111111] text-[#FAF9F6] text-sm font-black tracking-wider uppercase border border-[#111111] hover:bg-[#FFC107] hover:text-[#111111] transition-all rounded-sm cursor-pointer"
              >
                {"Let's Talk"}
                <ArrowUpRight className="w-4.5 h-4.5 ml-2 stroke-[3]" />
              </a>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
`;
fs.writeFileSync(path.join(baseDir, 'src/components/Navbar.tsx'), navbarContent, 'utf8');

// 3. Footer.tsx
const footerContent = `"use client";

import React from "react";
import { Linkedin, Github, Instagram, Twitter, ArrowUp, Mail, Phone, MapPin } from "lucide-react";
import { NavLink, ContactData } from "@/data/portfolio";

interface FooterProps {
  data?: any;
  contact?: Partial<ContactData>;
  navLinks?: NavLink[];
  name?: string;
}

export default function Footer(props: FooterProps = {}) {
  const contact = props.contact || props.data?.contact || {};
  const email = contact.email || props.data?.email || props.data?.profile?.email || "";
  const phone = contact.phone || props.data?.phone || props.data?.profile?.phone || "";
  const location = contact.location || props.data?.location || props.data?.profile?.location || "";
  const socials = contact.socials || props.data?.socials || props.data?.socialLinks || {};

  const name = props.name || props.data?.name || props.data?.fullName || "Portfolio";
  const brandName = name.toUpperCase().endsWith('.') ? name.toUpperCase() : \`\${name.toUpperCase().split(' ')[0]}.\`;

  const defaultLinks: NavLink[] = [
    { label: "Home", href: "#home" },
    { label: "About", href: "#about" },
    { label: "Skills", href: "#skills" },
    { label: "Projects", href: "#projects" },
    { label: "Experience", href: "#experience" },
    { label: "Contact", href: "#contact" }
  ];

  const links: NavLink[] = Array.isArray(props.navLinks) && props.navLinks.length > 0
    ? props.navLinks.filter(l => !l.label.toLowerCase().includes('service') && !l.label.toLowerCase().includes('tool'))
    : defaultLinks;

  const handleScrollToTop = () => {
    if (typeof window !== "undefined") {
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  };

  return (
    <footer
      style={{ backgroundColor: "#111111", color: "#ffffff" }}
      className="bg-[#111111] text-white border-t border-white/10 py-16 px-6 sm:px-12 md:px-16 lg:px-24 relative z-10"
    >
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
        <div className="space-y-4">
          <h3 className="text-2xl font-black tracking-tight text-[#FFC107]">{brandName}</h3>
          <p className="text-gray-300 text-xs sm:text-sm leading-relaxed max-w-sm">
            {props.data?.title || props.data?.hero?.title || "Software Developer"} crafting robust, high-performance digital applications.
          </p>
          <div className="flex items-center space-x-3 pt-2">
            {socials.linkedin && (
              <a
                href={socials.linkedin}
                target="_blank"
                rel="noreferrer"
                className="p-2 bg-white/10 hover:bg-[#FFC107] hover:text-[#111111] rounded-full transition-all duration-200"
                aria-label="LinkedIn"
              >
                <Linkedin className="w-4 h-4" />
              </a>
            )}
            {socials.github && (
              <a
                href={socials.github}
                target="_blank"
                rel="noreferrer"
                className="p-2 bg-white/10 hover:bg-[#FFC107] hover:text-[#111111] rounded-full transition-all duration-200"
                aria-label="GitHub"
              >
                <Github className="w-4 h-4" />
              </a>
            )}
            {socials.instagram && (
              <a
                href={socials.instagram}
                target="_blank"
                rel="noreferrer"
                className="p-2 bg-white/10 hover:bg-[#FFC107] hover:text-[#111111] rounded-full transition-all duration-200"
                aria-label="Instagram"
              >
                <Instagram className="w-4 h-4" />
              </a>
            )}
            {socials.twitter && (
              <a
                href={socials.twitter}
                target="_blank"
                rel="noreferrer"
                className="p-2 bg-white/10 hover:bg-[#FFC107] hover:text-[#111111] rounded-full transition-all duration-200"
                aria-label="Twitter"
              >
                <Twitter className="w-4 h-4" />
              </a>
            )}
          </div>
        </div>

        <div>
          <h4 className="text-sm font-black tracking-wider uppercase text-white mb-4">Quick Links</h4>
          <ul className="space-y-2.5">
            {links.map((link: NavLink) => (
              <li key={link.label}>
                <a href={link.href} className="text-gray-300 hover:text-[#FFC107] text-xs sm:text-sm font-semibold transition-colors duration-200">
                  {link.label}
                </a>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h4 className="text-sm font-black tracking-wider uppercase text-white mb-4">Contact</h4>
          <ul className="space-y-3 text-xs sm:text-sm text-gray-300 font-medium">
            {email && (
              <li className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-[#FFC107] shrink-0" />
                <a href={\`mailto:\${email}\`} className="hover:text-[#FFC107] transition-colors">{email}</a>
              </li>
            )}
            {phone && (
              <li className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-[#FFC107] shrink-0" />
                <a href={\`tel:\${phone}\`} className="hover:text-[#FFC107] transition-colors">{phone}</a>
              </li>
            )}
            {location && (
              <li className="flex items-center gap-2.5">
                <MapPin className="w-4 h-4 text-[#FFC107] shrink-0" />
                <span>{location}</span>
              </li>
            )}
            {!email && !phone && !location && (
              <li className="text-gray-400">Reach out via the contact section.</li>
            )}
          </ul>
        </div>
      </div>

      <div className="max-w-7xl mx-auto pt-8 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between text-xs text-gray-400">
        <p>© {new Date().getFullYear()} {name}. All rights reserved.</p>
        <button
          onClick={handleScrollToTop}
          className="mt-4 sm:mt-0 flex items-center space-x-1.5 text-gray-300 hover:text-[#FFC107] transition-colors duration-200 cursor-pointer"
        >
          <span>Back to Top</span>
          <ArrowUp className="w-3.5 h-3.5" />
        </button>
      </div>
    </footer>
  );
}
`;
fs.writeFileSync(path.join(baseDir, 'src/components/Footer.tsx'), footerContent, 'utf8');

// 4. Hero.tsx
const heroContent = `"use client";

import React from "react";
import { ArrowDownRight, ArrowDown, MessageSquare } from "lucide-react";
import { HeroData } from "@/data/portfolio";

interface HeroProps {
  data?: any;
  hero?: Partial<HeroData> & { avatarUrl?: string };
}

export default function Hero(props: HeroProps = {}) {
  const incoming = props.hero || props.data?.hero || props.data || {};
  const rawName = incoming.name || props.data?.name || props.data?.fullName || "Portfolio";
  
  const hero: HeroData & { avatarUrl?: string } = {
    greeting: incoming.greeting || props.data?.greeting || "HEY, I'M",
    name: rawName,
    title: incoming.title || props.data?.title || "SOFTWARE DEVELOPER",
    highlightedTitle: incoming.highlightedTitle || props.data?.highlightedTitle || "",
    description: incoming.description || incoming.intro || incoming.introductionText || props.data?.profile?.summary || props.data?.bio || props.data?.summary || "Builder-focused Developer with hands-on technical skills.",
    primaryCtaText: incoming.primaryCtaText || "VIEW MY WORK",
    primaryCtaHref: incoming.primaryCtaHref || "#projects",
    secondaryCtaText: incoming.secondaryCtaText || "GET IN TOUCH",
    secondaryCtaHref: incoming.secondaryCtaHref || "#contact",
    avatarUrl: incoming.avatarUrl || props.data?.avatarUrl || props.data?.profile?.photo || props.data?.profileImage || props.data?.avatar || "/profile.png"
  };

  const nameWords = (hero.name || "Portfolio").split(" ").filter(Boolean);

  return (
    <section
      id="home"
      data-section="hero"
      className="relative min-h-[90vh] pt-28 pb-16 flex items-center px-6 sm:px-12 md:px-16 lg:px-24 overflow-hidden z-10 bg-[#FAF9F6]"
    >
      <div className="max-w-7xl mx-auto w-full grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
        <div className="lg:col-span-7 flex flex-col justify-center space-y-6">
          <span
            data-field="hero.greeting"
            className="text-xs sm:text-sm font-black tracking-widest text-[#111111]/70 uppercase"
          >
            {hero.greeting}
          </span>

          <h1
            data-field="hero.name"
            className="text-4xl sm:text-6xl md:text-7xl font-black tracking-wide leading-tight text-[#111111]"
          >
            {nameWords.map((word: string, i: number) => (
              <span key={i} className="block">
                {word}
              </span>
            ))}
          </h1>

          <div className="inline-flex">
            <span
              data-field="hero.title"
              className="bg-[#FFC107] text-[#111111] text-xs sm:text-sm font-black tracking-wider uppercase px-4 py-2 shadow-sm rounded-sm"
            >
              {hero.title} {hero.highlightedTitle}
            </span>
          </div>

          <p
            data-field="hero.description"
            className="text-sm sm:text-base leading-relaxed text-[#666666] max-w-xl"
          >
            {hero.description}
          </p>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 pt-4">
            <a
              href={hero.primaryCtaHref || "#projects"}
              data-field="hero.primaryCtaText"
              className="inline-flex items-center justify-center px-8 py-4 bg-[#111111] text-[#FAF9F6] text-xs sm:text-sm font-black tracking-widest uppercase border-2 border-[#111111] hover:bg-[#FFC107] hover:border-[#FFC107] hover:text-[#111111] transition-colors duration-200 shadow-md hover:shadow-lg rounded-sm cursor-pointer transform-gpu will-change-transform"
            >
              {hero.primaryCtaText || "VIEW MY WORK"}
              <ArrowDownRight className="w-4 h-4 ml-2 stroke-[3]" />
            </a>

            <a
              href={hero.secondaryCtaHref || "#contact"}
              data-field="hero.secondaryCtaText"
              className="inline-flex items-center justify-center px-8 py-4 bg-transparent border-2 border-[#111111] text-[#111111] text-xs sm:text-sm font-black tracking-widest uppercase hover:bg-[#111111] hover:text-[#FAF9F6] transition-colors duration-200 rounded-sm cursor-pointer transform-gpu will-change-transform"
            >
              {hero.secondaryCtaText || "GET IN TOUCH"}
              <MessageSquare className="w-4 h-4 ml-2 stroke-[2.5]" />
            </a>
          </div>
        </div>

        <div className="lg:col-span-5 flex justify-center lg:justify-end items-center relative py-12 lg:py-0">
          <div className="relative w-72 h-72 sm:w-96 sm:h-96">
            
            <svg
              className="absolute inset-0 w-full h-full animate-spin pointer-events-none will-change-transform"
              style={{ animationDuration: "35s" }}
              viewBox="0 0 100 100"
            >
              <circle
                cx="50"
                cy="50"
                r="47"
                fill="none"
                stroke="#FFC107"
                strokeWidth="2.5"
                strokeDasharray="6 6"
                strokeOpacity="0.8"
              />
            </svg>

            <div className="absolute top-4 left-4 w-full h-full rounded-full bg-[#111111]/5 border border-[#111111]/10 pointer-events-none" />

            <div className="absolute top-2 left-6 text-[#FFC107] w-8 h-8 stroke-[1.5] pointer-events-none">
              <svg viewBox="0 0 24 24" fill="none" stroke="#FFC107">
                <path d="M12 2v20M2 12h20M5 5l14 14M19 5L5 19" />
              </svg>
            </div>

            <div className="absolute inset-4 rounded-full overflow-hidden border-4 border-[#111111] bg-white shadow-xl">
              <img
                src={hero.avatarUrl}
                alt={hero.name}
                data-field="hero.avatarUrl"
                className="w-full h-full object-cover"
                onError={(e) => {
                  e.currentTarget.src = 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80';
                }}
              />
            </div>
          </div>
        </div>
      </div>

      <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 flex flex-col items-center">
        <a
          href="#about"
          className="flex flex-col items-center text-[10px] sm:text-xs font-black tracking-widest text-[#111111]/50 uppercase hover:text-[#FFC107] transition-colors"
        >
          <span>SCROLL</span>
          <ArrowDown className="w-4 h-4 mt-1 animate-bounce" />
        </a>
      </div>
    </section>
  );
}
`;
fs.writeFileSync(path.join(baseDir, 'src/sections/Hero.tsx'), heroContent, 'utf8');

// 5. Skills.tsx
const skillsContent = `"use client";

import React from "react";
import { CheckCircle2, Sparkles, Layers } from "lucide-react";
import { SkillCategory } from "@/data/portfolio";

interface SkillsProps {
  data?: any;
  skills?: SkillCategory[];
}

export default function Skills(props: SkillsProps = {}) {
  const categories: SkillCategory[] = Array.isArray(props.skills) && props.skills.length > 0
    ? props.skills
    : (Array.isArray(props.data?.skills) && props.data.skills.length > 0 ? props.data.skills : []);

  const totalSkillCount = categories.reduce((sum, cat) => sum + (cat.items?.length || 0), 0);

  return (
    <section
      id="skills"
      data-section="skills"
      className="py-24 px-6 sm:px-12 md:px-16 lg:px-24 border-t border-[#111111]/10 relative z-10 bg-[#FAF9F6]"
    >
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-16 gap-4">
          <div className="flex flex-col space-y-3">
            <span className="text-xs font-black tracking-widest text-[#FFC107] uppercase">
              Expertise
            </span>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-black tracking-wide leading-tight text-[#111111]">
              SKILLS & PROFICIENCY
            </h2>
            <div className="w-12 h-1 bg-[#FFC107] mt-2" style={{ backgroundColor: "#FFC107" }} />
          </div>

          {totalSkillCount > 0 && (
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#111111]/5 border border-[#111111]/10 text-xs font-bold text-[#111111]">
              <Layers className="w-3.5 h-3.5 text-[#FFC107]" />
              <span>{totalSkillCount} Skills Listed</span>
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {categories.map((category: SkillCategory, idx: number) => (
            <div
              key={category.category || idx}
              className="p-6 sm:p-7 bg-white border-2 border-[#111111]/10 rounded-md shadow-sm space-y-5 hover:border-[#FFC107] transition-all duration-300 group flex flex-col justify-between"
            >
              <div className="flex items-center justify-between border-b border-[#111111]/10 pb-4">
                <div className="flex items-center gap-2">
                  <h3 className="text-base sm:text-lg font-black tracking-tight text-[#111111]">
                    {category.category}
                  </h3>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#FFC107]/20 text-[#111111]">
                    {category.items?.length || 0}
                  </span>
                </div>
                <Sparkles className="w-4 h-4 text-[#FFC107] group-hover:scale-110 transition-transform" />
              </div>

              <div className="flex flex-wrap gap-2 pt-1">
                {(category.items || []).map((skill: any, sIdx: number) => {
                  const skillName = typeof skill === "string" ? skill : skill.name;
                  if (!skillName) return null;

                  return (
                    <div
                      key={skillName || sIdx}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#FAF9F6] hover:bg-[#FFC107]/20 border border-[#111111]/10 hover:border-[#FFC107] text-[#111111] rounded-sm text-xs font-bold tracking-wide transition-all duration-200"
                    >
                      <CheckCircle2 className="w-3 h-3 text-[#FFC107] shrink-0 stroke-[2.5]" />
                      <span>{skillName}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
`;
fs.writeFileSync(path.join(baseDir, 'src/sections/Skills.tsx'), skillsContent, 'utf8');

// 6. Projects.tsx
const projectsContent = `"use client";

import React, { useState, useMemo } from "react";
import { ArrowUpRight, Github, Globe, FolderGit2 } from "lucide-react";
import { ProjectItem } from "@/data/portfolio";

interface ProjectsProps {
  data?: any;
  projects?: ProjectItem[];
}

export default function Projects(props: ProjectsProps = {}) {
  const projectsList: ProjectItem[] = Array.isArray(props.projects) && props.projects.length > 0
    ? props.projects
    : (Array.isArray(props.data?.projects) && props.data.projects.length > 0
      ? props.data.projects
      : (Array.isArray(props.data?.portfolio) && props.data.portfolio.length > 0
        ? props.data.portfolio
        : []));

  const [activeFilter, setActiveFilter] = useState<string>("All");

  const filters = useMemo<string[]>(() => {
    const rawCategories = projectsList.map((p: ProjectItem) => p.category).filter(Boolean);
    const unique = Array.from(new Set(rawCategories));
    if (unique.length <= 1) {
      return ["All", "Web", "Full Stack", "Mobile"];
    }
    return ["All", ...unique];
  }, [projectsList]);

  const filteredProjects = projectsList.filter((project: ProjectItem) => {
    if (activeFilter === "All") return true;
    return (project.category || "").toLowerCase().includes(activeFilter.toLowerCase());
  });

  return (
    <section
      id="projects"
      data-section="projects"
      className="py-24 px-6 sm:px-12 md:px-16 lg:px-24 border-t border-[#111111]/10 relative z-10 bg-[#FAF9F6]"
    >
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div className="flex flex-col space-y-3">
            <span className="text-xs font-black tracking-widest text-[#FFC107] uppercase">
              Portfolio
            </span>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-black tracking-wide leading-tight text-[#111111]">
              FEATURED WORK
            </h2>
            <div className="w-12 h-1 bg-[#FFC107] mt-2" style={{ backgroundColor: "#FFC107" }} />
          </div>

          <div className="flex flex-wrap gap-2">
            {filters.map((filter: string) => (
              <button
                key={filter}
                onClick={() => setActiveFilter(filter)}
                className={\`px-4 py-2 text-xs sm:text-sm font-black tracking-wider uppercase border-2 rounded-sm cursor-pointer transition-colors duration-200 \${
                  activeFilter === filter
                    ? "bg-[#FFC107] text-[#111111] border-[#FFC107] shadow-sm"
                    : "border-[#111111]/20 hover:border-[#FFC107] text-[#111111] bg-white"
                }\`}
              >
                {filter}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {filteredProjects.map((project: ProjectItem, idx: number) => {
            const hasImage = Boolean(project.image && project.image.trim() !== '');

            return (
              <div
                key={project.title || idx}
                className="bg-white border-2 border-[#111111]/10 rounded-md overflow-hidden shadow-sm hover:shadow-xl hover:border-[#FFC107] transition-all duration-300 flex flex-col justify-between group"
              >
                <div className="relative aspect-[16/10] w-full overflow-hidden bg-gradient-to-br from-zinc-900 via-neutral-900 to-zinc-800 border-b border-[#111111]/10 flex items-center justify-center">
                  {hasImage ? (
                    <img
                      src={project.image}
                      alt={project.title}
                      className="w-full h-full object-cover scale-100 group-hover:scale-105 transition-transform duration-500"
                      onError={(e) => {
                        e.currentTarget.style.display = 'none';
                      }}
                    />
                  ) : (
                    <div className="flex flex-col items-center justify-center text-zinc-400 space-y-2 p-6 text-center">
                      <FolderGit2 className="w-12 h-12 text-[#FFC107]" />
                      <span className="text-xs font-bold text-white uppercase tracking-wider">{project.title}</span>
                    </div>
                  )}
                  
                  {project.category && (
                    <span
                      className="absolute top-4 left-4 bg-[#111111] text-[#FAF9F6] text-[10px] font-black tracking-wider uppercase px-3 py-1.5 shadow-md rounded-sm"
                    >
                      {project.category}
                    </span>
                  )}

                  <div className="absolute inset-0 bg-[#111111]/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center gap-4">
                    {project.liveUrl && (
                      <a
                        href={project.liveUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="p-3 bg-[#FFC107] text-[#111111] rounded-full hover:scale-110 transition-transform shadow-lg"
                        aria-label="Live Demo"
                      >
                        <Globe className="w-5 h-5 stroke-[2.5]" />
                      </a>
                    )}
                    {project.githubUrl && (
                      <a
                        href={project.githubUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="p-3 bg-white text-[#111111] rounded-full hover:scale-110 transition-transform shadow-lg"
                        aria-label="GitHub Repository"
                      >
                        <Github className="w-5 h-5 stroke-[2.5]" />
                      </a>
                    )}
                  </div>
                </div>

                <div className="p-6 sm:p-8 flex-1 flex flex-col justify-between">
                  <div>
                    <h3 className="text-xl sm:text-2xl font-black tracking-tight text-[#111111]">
                      {project.title}
                    </h3>

                    <p className="text-xs sm:text-sm text-[#666666] leading-relaxed mt-2 mb-6">
                      {project.description}
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center justify-between gap-4 pt-4 border-t border-[#111111]/10">
                    <div className="flex flex-wrap gap-2">
                      {(project.techStack || (project as any).tags || []).map((tag: string) => (
                        <span
                          key={tag}
                          className="px-2.5 py-1 bg-[#111111]/5 text-[#111111] text-[11px] font-bold tracking-wide rounded-sm"
                        >
                          #{tag}
                        </span>
                      ))}
                    </div>

                    {project.liveUrl && (
                      <a
                        href={project.liveUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center text-xs font-black tracking-wider uppercase text-[#111111] hover:text-[#FFC107] transition-colors"
                      >
                        <span>Explore</span>
                        <ArrowUpRight className="w-4 h-4 ml-1 stroke-[3]" />
                      </a>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
`;
fs.writeFileSync(path.join(baseDir, 'src/sections/Projects.tsx'), projectsContent, 'utf8');

// 7. template.tsx (No WhatIDo and No Tools)
const templateContent = `"use client";

import React, { useState, useEffect } from "react";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import BackgroundDecor from "./components/BackgroundDecor";
import ScrollToTop from "./components/ScrollToTop";
import TestimonialCarousel from "./components/TestimonialCarousel";

// Section imports
import Hero from "./sections/Hero";
import About from "./sections/About";
import Approach from "./sections/Approach";
import Education from "./sections/Education";
import Skills from "./sections/Skills";
import Certifications from "./sections/Certifications";
import Projects from "./sections/Projects";
import Experience from "./sections/Experience";
import Achievements from "./sections/Achievements";
import Contact from "./sections/Contact";

import { normalizeData, NormalizedPortfolioData } from "./utils/normalizeData";
import "./styles/index.css";

const CRITICAL_CSS = \`
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Outfit:wght@400;500;600;700;800;900&display=swap');

  :root {
    --brand-yellow: #FFC107;
    --brand-dark: #111111;
    --brand-cream: #FAF9F6;
    --brand-muted: #666666;
    --font-inter: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    --font-outfit: 'Outfit', sans-serif;
  }

  .portfolio-root {
    background-color: #FAF9F6 !important;
    color: #111111 !important;
    font-family: 'Inter', sans-serif;
  }

  .bg-brand-yellow, [data-theme] .bg-brand-yellow {
    background-color: #FFC107 !important;
  }

  .text-brand-yellow, [data-theme] .text-brand-yellow {
    color: #FFC107 !important;
  }

  .border-brand-yellow, [data-theme] .border-brand-yellow {
    border-color: #FFC107 !important;
  }

  .bg-brand-dark, [data-theme] .bg-brand-dark {
    background-color: #111111 !important;
    color: #ffffff !important;
  }

  .text-brand-dark, [data-theme] .text-brand-dark {
    color: #111111 !important;
  }

  .border-brand-dark, [data-theme] .border-brand-dark {
    border-color: #111111 !important;
  }

  .text-brand-muted, [data-theme] .text-brand-muted {
    color: #666666 !important;
  }

  .bg-brand-cream, [data-theme] .bg-brand-cream {
    background-color: #FAF9F6 !important;
  }

  .text-brand-cream, [data-theme] .text-brand-cream {
    color: #FAF9F6 !important;
  }

  footer.bg-brand-dark, footer.bg-\\\\[\\\\#111111\\\\] {
    background-color: #111111 !important;
    color: #ffffff !important;
  }
\`;

export interface TemplateProps {
  data?: any;
  portfolio?: any;
  profile?: any;
  cv?: any;
  resume?: any;
  [key: string]: any;
}

export default function Template(props: TemplateProps = {}) {
  const rawPropsData = props?.data || props?.portfolio || props?.profile || props?.cv || props?.resume || props || {};
  const [liveData, setLiveData] = useState<NormalizedPortfolioData>(() => normalizeData(rawPropsData));

  useEffect(() => {
    setLiveData(normalizeData(props?.data || props?.portfolio || props?.profile || props?.cv || props?.resume || props || {}));
  }, [props?.data, props?.portfolio, props?.profile, props?.cv, props?.resume, props]);

  useEffect(() => {
    if (typeof window === "undefined") return;

    const handleMessage = (event: MessageEvent) => {
      try {
        const payload = event.data;
        if (!payload || typeof payload !== "object") return;

        if (
          payload.type === "CAMPUSCV_SET_DATA" ||
          payload.type === "SET_PORTFOLIO_DATA" ||
          payload.type === "UPDATE_DATA" ||
          payload.type === "CAMPUSCV_UPDATE_DATA" ||
          payload.type === "campuscv_update"
        ) {
          const incoming = payload.data || payload.portfolio || payload.payload;
          if (incoming && typeof incoming === "object") {
            setLiveData(normalizeData(incoming));
          }
        } else if (payload.type === "UPDATE_FIELD" && payload.field) {
          setLiveData((prev) => {
            const copy: any = { ...prev };
            const parts = payload.field.split(".");
            if (parts.length === 1) {
              copy[parts[0]] = payload.value;
            } else if (parts.length === 2) {
              copy[parts[0]] = { ...copy[parts[0]], [parts[1]]: payload.value };
            }
            return normalizeData(copy);
          });
        }
      } catch (err) {
        console.warn("CampusCV postMessage listener notice:", err);
      }
    };

    window.addEventListener("message", handleMessage);

    try {
      if (window.parent && window.parent !== window) {
        window.parent.postMessage({ type: "CAMPUSCV_TEMPLATE_READY", templateId: "stu-creative-bold" }, "*");
      }
    } catch (_) {}

    return () => {
      window.removeEventListener("message", handleMessage);
    };
  }, []);

  const data = liveData;

  const isSectionVisible = (sectionName: string): boolean => {
    if (data[\`\${sectionName}.visible\`] === false || data[\`\${sectionName}.visible\`] === 0) return false;
    if (data[\`\${sectionName}Visible\`] === false || data[\`\${sectionName}Visible\`] === 0) return false;
    if (data[sectionName] && typeof data[sectionName] === "object" && data[sectionName].visible === false) {
      return false;
    }
    return true;
  };

  const primaryAccent = data.theme?.primaryColor || data.accentColor || data.themeColor || "";
  const dynamicStyles: React.CSSProperties = {
    position: "relative",
    minHeight: "100vh",
    overflow: "hidden",
    backgroundColor: "#FAF9F6",
    color: "#111111",
    ...(primaryAccent
      ? {
          "--brand-yellow": primaryAccent,
          "--primary": primaryAccent,
        } as any
      : {})
  };

  return (
    <div
      className="portfolio-root light min-h-screen bg-[#FAF9F6] text-[#111111] font-sans antialiased relative overflow-hidden"
      data-theme="light"
      style={dynamicStyles}
    >
      <style dangerouslySetInnerHTML={{ __html: CRITICAL_CSS }} />

      <BackgroundDecor />

      <Navbar data={data} navLinks={data.navLinks} name={data.name} />

      <main className="relative z-10">
        {/* 1. Hero Section */}
        {isSectionVisible("hero") && <Hero data={data} hero={data.hero} />}

        {/* 2. About Section */}
        {isSectionVisible("about") && <About data={data} about={data.about} />}

        {/* 3. My Approach (Workflow) Section */}
        {isSectionVisible("approach") && <Approach data={data} approachSteps={data.approachSteps} />}

        {/* 4. Education History Section */}
        {isSectionVisible("education") && <Education data={data} education={data.education} />}

        {/* 5. Skills & Proficiency Section */}
        {isSectionVisible("skills") && <Skills data={data} skills={data.skills} />}

        {/* 6. Certifications Section */}
        {isSectionVisible("certifications") && <Certifications data={data} certifications={data.certifications} />}

        {/* 7. Featured Projects Section */}
        {isSectionVisible("projects") && <Projects data={data} projects={data.projects} />}

        {/* 8. Career Work Experience Section */}
        {isSectionVisible("experience") && <Experience data={data} experiences={data.experiences} />}

        {/* 9. Testimonials Section */}
        {isSectionVisible("testimonials") && (
          <section className="py-24 px-6 sm:px-12 md:px-16 lg:px-24 border-t border-[#111111]/10 relative z-10 bg-[#111111]/[0.02]">
            <div className="max-w-7xl mx-auto">
              <div className="flex flex-col mb-16 items-center text-center space-y-3">
                <span className="text-xs font-black tracking-widest text-[#FFC107] uppercase">
                  Feedback
                </span>
                <h2 className="text-3xl sm:text-4xl md:text-5xl font-black tracking-wide leading-tight text-[#111111]">
                  WHAT PEOPLE SAY
                </h2>
                <div className="w-12 h-1 bg-[#FFC107] mt-2" />
              </div>
              <TestimonialCarousel data={data} testimonials={data.testimonials} />
            </div>
          </section>
        )}

        {/* 10. Achievements / Awards Section */}
        {isSectionVisible("achievements") && <Achievements data={data} achievements={data.achievements} />}

        {/* 11. Contact Section */}
        {isSectionVisible("contact") && <Contact data={data} contact={data.contact} />}
      </main>

      <Footer data={data} contact={data.contact} navLinks={data.navLinks} name={data.name} />

      <ScrollToTop />
    </div>
  );
}

export { Template as Portfolio };
`;
fs.writeFileSync(path.join(baseDir, 'src/template.tsx'), templateContent, 'utf8');

// 8. manifest.json
const manifest = {
  id: "stu-creative-bold",
  name: "Creative Bold Student & Developer Portfolio",
  version: "1.0.0",
  category: "Developer & Creative",
  author: "CampusCV",
  description: "High-impact bold creative portfolio template with energetic golden accents, dynamic timeline sections, interactive project showcase, and comprehensive academic credentials for students and frontend engineers.",
  thumbnail: "thumbnail.png",
  preview: "preview.png",
  entry: "src/index.jsx",
  supportsDarkMode: false,
  theme: {
    mode: "light",
    primaryColor: "#FFC107",
    backgroundColor: "#FAF9F6",
    textColor: "#111111"
  },
  sections: [
    {
      id: "hero",
      name: "Hero Section",
      component: "src/sections/Hero.tsx",
      description: "Bold typography hero headline with student portrait, profession badge, and primary action triggers.",
      fields: [
        "name",
        "title",
        "hero.greeting",
        "hero.name",
        "hero.title",
        "hero.highlightedTitle",
        "hero.description",
        "hero.primaryCtaText",
        "hero.primaryCtaHref",
        "hero.secondaryCtaText",
        "hero.secondaryCtaHref",
        "hero.avatarUrl"
      ]
    },
    {
      id: "about",
      name: "About Section",
      component: "src/sections/About.tsx",
      description: "Personal introduction, career objective, and animated quantifiable counters.",
      fields: [
        "about.title",
        "about.subtitle",
        "about.description",
        "about.objective",
        "about.stats"
      ]
    },
    {
      id: "approach",
      name: "Workflow Approach",
      component: "src/sections/Approach.tsx",
      description: "Step-by-step development process and creative delivery methodology.",
      fields: ["approachSteps"]
    },
    {
      id: "education",
      name: "Education History",
      component: "src/sections/Education.tsx",
      description: "Academic degrees, universities, GPA/grades, and coursework honors.",
      fields: ["education"]
    },
    {
      id: "skills",
      name: "Skills & Proficiency",
      component: "src/sections/Skills.tsx",
      description: "Categorized technical and design skill competencies with clean badges.",
      fields: ["skills"]
    },
    {
      id: "certifications",
      name: "Certifications & Credentials",
      component: "src/sections/Certifications.tsx",
      description: "Verified certifications and professional course badges.",
      fields: ["certifications"]
    },
    {
      id: "projects",
      name: "Featured Projects",
      component: "src/sections/Projects.tsx",
      description: "Filterable portfolio cards with screenshots, tech tags, and live links.",
      fields: ["projects"]
    },
    {
      id: "experience",
      name: "Work Experience",
      component: "src/sections/Experience.tsx",
      description: "Career experience timeline with role descriptions and bullet points.",
      fields: ["experiences"]
    },
    {
      id: "testimonials",
      name: "Testimonials & Feedback",
      component: "src/components/TestimonialCarousel.tsx",
      description: "Peer reviews and mentor recommendations carousel.",
      fields: ["testimonials"]
    },
    {
      id: "achievements",
      name: "Honors & Achievements",
      component: "src/sections/Achievements.tsx",
      description: "Milestones, hackathons, and academic honors.",
      fields: ["achievements"]
    },
    {
      id: "contact",
      name: "Contact Information",
      component: "src/sections/Contact.tsx",
      description: "Direct communication suite including email, phone, and location.",
      fields: [
        "contact.email",
        "contact.phone",
        "contact.location",
        "contact.socials"
      ]
    }
  ]
};
fs.writeFileSync(path.join(baseDir, 'manifest.json'), JSON.stringify(manifest, null, 2), 'utf8');

// 9. bindings.json
const bindings = {
  "name": "src/sections/Hero.tsx",
  "title": "src/sections/Hero.tsx",
  "hero.greeting": "src/sections/Hero.tsx",
  "hero.name": "src/sections/Hero.tsx",
  "hero.title": "src/sections/Hero.tsx",
  "hero.highlightedTitle": "src/sections/Hero.tsx",
  "hero.description": "src/sections/Hero.tsx",
  "hero.primaryCtaText": "src/sections/Hero.tsx",
  "hero.primaryCtaHref": "src/sections/Hero.tsx",
  "hero.secondaryCtaText": "src/sections/Hero.tsx",
  "hero.secondaryCtaHref": "src/sections/Hero.tsx",
  "hero.avatarUrl": "src/sections/Hero.tsx",
  "about.title": "src/sections/About.tsx",
  "about.subtitle": "src/sections/About.tsx",
  "about.description": "src/sections/About.tsx",
  "about.objective": "src/sections/About.tsx",
  "about.stats": "src/sections/About.tsx",
  "approachSteps": "src/sections/Approach.tsx",
  "education": "src/sections/Education.tsx",
  "skills": "src/sections/Skills.tsx",
  "certifications": "src/sections/Certifications.tsx",
  "projects": "src/sections/Projects.tsx",
  "experiences": "src/sections/Experience.tsx",
  "testimonials": "src/components/TestimonialCarousel.tsx",
  "achievements": "src/sections/Achievements.tsx",
  "contact.email": "src/sections/Contact.tsx",
  "contact.phone": "src/sections/Contact.tsx",
  "contact.location": "src/sections/Contact.tsx",
  "contact.socials": "src/components/Footer.tsx"
};
fs.writeFileSync(path.join(baseDir, 'bindings.json'), JSON.stringify(bindings, null, 2), 'utf8');

console.log('✓ All core template files successfully rewritten.');
