import React, { useState } from 'react';
import { Camera, Sparkles, Menu, X, ArrowUpRight } from 'lucide-react';
import { photographyProfile } from '../data/photographyDefaults.js';

const _default = photographyProfile || {};

export default function Navbar({ data = {} }) {
  const [mobileOpen, setMobileOpen] = useState(false);

  const name = data?.hero?.name || data?.name || data?.fullName || _default.name || 'Elena Vance';
  const role = data?.hero?.role || data?.role || data?.title || _default.title || 'Visual Artist';

  const dynamicSections = Array.isArray(props?.visibleSections) && props.visibleSections.length > 0
    ? props.visibleSections
    : (Array.isArray(data?.sectionOrder) && data.sectionOrder.length > 0
      ? data.sectionOrder
      : (Array.isArray(data?.sections) && data.sections.length > 0
        ? data.sections
        : ['Hero', 'About', 'Education', 'Experience', 'Projects', 'Skills', 'Certificates', 'Contact']));

  const hasCerts = Array.isArray(data?.certificates) ? data.certificates.length > 0 : (Array.isArray(data?.certifications) && data.certifications.length > 0);
  const hasEdu = Array.isArray(data?.education) ? data.education.length > 0 : (data.education !== undefined ? false : true);
  const hasExp = Array.isArray(data?.experience) ? data.experience.length > 0 : (data.experience !== undefined ? false : true);
  const hasProj = Array.isArray(data?.projects) ? data.projects.length > 0 : (data.projects !== undefined ? false : true);
  const hasSkills = Array.isArray(data?.skills) ? data.skills.length > 0 : (data.skills !== undefined ? false : true);

  const navLinks = dynamicSections
    .filter((sec) => {
      const sName = typeof sec === 'string' ? sec : (sec?.name || sec?.id || '');
      const lower = sName.toLowerCase().trim();
      if (!lower || lower === 'header' || lower === 'footer' || lower === 'navbar') return false;
      if (props?.visibleSections) return true;
      if (lower === 'certificates' || lower === 'certifications') return hasCerts;
      if (lower === 'education') return hasEdu;
      if (lower === 'experience') return hasExp;
      if (lower === 'projects' || lower === 'works' || lower === 'portfolio') return hasProj;
      if (lower === 'skills') return hasSkills;
      return true;
    })
    .map((sec) => {
      const sName = typeof sec === 'string' ? sec : (sec?.name || sec?.id || '');
      const cleanName = sName.charAt(0).toUpperCase() + sName.slice(1);
      let id = sName.toLowerCase().replace(/\s+/g, '-');
      if (id === 'home' || id === 'intro') id = 'hero';
      if (id === 'works' || id === 'projects') id = 'portfolio';
      if (id === 'certifications' || id === 'awards') id = 'certificates';
      const href = `#${id}`;
      return { label: cleanName === 'Hero' ? 'Home' : cleanName, href };
    });

  return (
    <header className="sticky top-0 left-0 right-0 z-50 transition-all duration-300 bg-[#0b0713]/85 backdrop-blur-md border-b border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          
          {/* Brand Logo & Name */}
          <a href="#" className="flex items-center gap-2.5 sm:gap-3 group">
            <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-2xl bg-gradient-to-tr from-purple-600 to-fuchsia-500 p-[1.5px] shadow-lg shadow-purple-500/20 group-hover:scale-105 transition-transform">
              <div className="w-full h-full bg-[#0b0713] rounded-[14px] flex items-center justify-center">
                <Camera className="w-4 h-4 text-purple-400 group-hover:text-white transition-colors" />
              </div>
            </div>
            <div>
              <span className="font-extrabold text-white text-base sm:text-lg tracking-tight group-hover:text-purple-300 transition-colors block">
                {name}
              </span>
            </div>
          </a>

          {/* Desktop Nav Items */}
          <nav className="desktop-nav items-center gap-7">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className="text-xs sm:text-sm font-medium text-zinc-300 hover:text-white transition-colors"
              >
                {link.label}
              </a>
            ))}
          </nav>

          {/* Right Action & Mobile Toggle */}
          <div className="flex items-center gap-3">
            <a
              href="#contact"
              className="hidden sm:inline-flex items-center gap-1.5 px-4 sm:px-5 py-2 sm:py-2.5 rounded-full bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs sm:text-sm shadow-md shadow-purple-600/30 transition-all"
            >
              <span>Book Shoot</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </a>

            {/* Mobile Hamburger Button */}
            <button
              onClick={() => setMobileOpen(!mobileOpen)}
              className="mobile-hamburger-btn p-2 rounded-xl bg-white/10 text-white border border-white/10"
              aria-label="Toggle Navigation Menu"
            >
              {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileOpen && (
        <div className="sm:hidden px-4 pt-2 pb-6 bg-[#0b0713]/95 border-b border-white/10 backdrop-blur-xl space-y-3">
          {navLinks.map((link) => (
            <a
              key={link.label}
              href={link.href}
              onClick={() => setMobileOpen(false)}
              className="block px-3 py-2 rounded-xl text-sm font-medium text-zinc-200 hover:bg-purple-950/60 transition-colors"
            >
              {link.label}
            </a>
          ))}
          <a
            href="#contact"
            onClick={() => setMobileOpen(false)}
            className="block text-center w-full px-4 py-3 rounded-xl bg-purple-600 text-white font-bold text-sm shadow-md"
          >
            Book Shoot & Consultation
          </a>
        </div>
      )}
    </header>
  );
}
